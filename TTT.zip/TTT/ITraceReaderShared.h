//-----------------------------------------------------------------------------
// Copyright (C) 2013 Microsoft Corporation
//
// File name:
//      ITraceReaderShared.h
//
// Abstract:
//      Unified header for v1 and v2.
//
// Description:
//      Definitions for various types and constants which are likely to remain
//      compatible between v1 and v2.
//
// Usage:
//      When linking directly against iDNA v1 or v2, include ITraceReader.h
//      for the desired version and do not include ITraceReaderShared.h
//      directly.
//
//      Code which implements support for both v1 and v2 may include this
//      file directly, since it is not possible to include ITraceReader.h
//      for v1 and v2 simultaneously. WARNING: This file may be removed in
//      the future if and when v1 goes away forever. At that time, code which
//      depends upon this file will need to include ITraceReader.h for v2.
//
// WARNINGS FOR ANYONE EDITING THIS FILE:
//     1) If possible, please avoid changing enum values or structure layout
//        in ways that would break compatibility reading legacy v1 traces.
//     2) When it is not possible to do so, please consider moving constants
//        and type definitions back in to the respective ITraceReader.h
//        headers, and notify consumers of this header so that they can plan
//        accordingly and refactor logic to consume the version specific
//        ITraceReader.h as appropriate.
//     3) If a proposed change to this header breaks the build for any tool
//        (such as TruScan or the debugger), it's a good indication that
//        the tool needs to be updated. However, don't rely on build breaks to
//        identify all breaking changes, since reordering structures or enum
//        values could break compatibility for legacy traces without breaking a
//        build.
//
// Revision History:
//  1   Evan Tice (evant) 10/30/2013
//      Refactored out of ITraceReader.h
//-----------------------------------------------------------------------------

#pragma once

#include <ole2.h>
#include <windows.h>
#include <evntprov.h>
#if !defined(_IMAGEHLP_) && !defined(_DBGHELP_)
#define DBGHELP_TRANSLATE_TCHAR
#include <dbghelp.h>
#endif

#if defined(_STL120_) || defined(_STL140_)
#include <cstdint>
#else
// We need this as long as we keep using old versions of STL.
#include <stl110\stdint.h>
#endif

// Defined in ntdbg.h. Forward-declared here to minimize header churn.
// Use #include <ntdbg.h> if needed.
typedef struct _CROSS_PLATFORM_CONTEXT CROSS_PLATFORM_CONTEXT;
typedef struct _AVX_EXTENDED_CONTEXT   AVX_EXTENDED_CONTEXT;


/* 04737ff3-83c3-4368-86c8-993e4df32fd9 */
DEFINE_GUID(IID_ITREADER,
            0x04737ff3,
            0x83c3,
            0x4368,
            0x86, 0xc8, 0x99, 0x3e, 0x4d, 0xf3, 0x2f, 0xd9);

typedef interface DECLSPEC_UUID("04737ff3-83c3-4368-86c8-993e4df32fd9") ITREADER* PITREADER;


/* {93F82E2F-3A8F-4D4C-9BBE-78575EB7F1B9} */
DEFINE_GUID(IID_ITREADER2,
            0x93f82e2f,
            0x3a8f,
            0x4d4c,
            0x9b, 0xbe, 0x78, 0x57, 0x5e, 0xb7, 0xf1, 0xb9);

typedef interface DECLSPEC_UUID("93F82E2F-3A8F-4D4C-9BBE-78575EB7F1B9") ITREADER2* PITREADER2;


// {CEBC5BE1-5089-4392-B74A-F9E24514A157}
DEFINE_GUID(IID_ITREADER3,
            0xcebc5be1,
            0x5089,
            0x4392,
            0xb7, 0x4a, 0xf9, 0xe2, 0x45, 0x14, 0xa1, 0x57);

typedef interface DECLSPEC_UUID("CEBC5BE1-5089-4392-B74A-F9E24514A157") ITREADER3* PITREADER3;


//
// Return code for IREADER interface
//
const HRESULT TR_ERROR_SUCCESS                    = NO_ERROR;
const HRESULT TR_ERROR_FAILURE                    = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0x1);
const HRESULT TR_ERROR_NOT_IMPLEMENTED            = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0x2);
const HRESULT TR_ERROR_INVALID_POSITION           = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0x3);
const HRESULT TR_ERROR_ADDR_NOT_FOUND             = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0x4);
const HRESULT TR_ERROR_BAD_ALIGNMENT              = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0x5);
const HRESULT TR_ERROR_MODULE_UNKNOWN             = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0x6);
const HRESULT TR_ERROR_MORE_DATA                  = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0x7);
const HRESULT TR_ERROR_FILE_NOT_FOUND             = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0x8);
const HRESULT TR_ERROR_BAD_FILE_FORMAT            = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0x9);
const HRESULT TR_ERROR_TRACEFILE_VERSION_MISMATCH = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0xa);
const HRESULT TR_ERROR_BREAKPOINT_HIT             = MAKE_HRESULT(SEVERITY_SUCCESS,FACILITY_NULL, 0xb);
const HRESULT TR_ERROR_OUTOFMEMORY                = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0xc);
// COM ref count 0 or initialization failed.
const HRESULT TR_ERROR_INVALID_READER             = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0xd);
const HRESULT TR_ERROR_REPLAY_FAILURE             = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0xe);
const HRESULT TR_ERROR_OPEN_PACKET_LOG            = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0xf);
// This error occurs if you try to attach to a trace file and there is another reader
// in the same process that has already started executing.  See CreateITReader() for
// details.
const HRESULT TR_ERROR_TOO_MANY_READERS           = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0xf);
const HRESULT TR_ERROR_BAD_CALLBACK_TYPE          = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0x10);
const HRESULT TR_ERROR_ENDOFTRACE                 = MAKE_HRESULT(SEVERITY_SUCCESS,FACILITY_NULL, 0x11);
const HRESULT TR_ERROR_BREAKPOINT_EXISTS          = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0x12);
const HRESULT TR_ERROR_SEQUENCE_END               = MAKE_HRESULT(SEVERITY_SUCCESS,FACILITY_NULL, 0x13);
const HRESULT TR_ERROR_MEMORY_VALUE_EXISTS        = MAKE_HRESULT(SEVERITY_SUCCESS,FACILITY_NULL, 0x14);
const HRESULT TR_ERROR_PENDING                    = MAKE_HRESULT(SEVERITY_SUCCESS,FACILITY_NULL, 0x15);
const HRESULT TR_ERROR_COMMIT_FAILED              = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0x16);
const HRESULT TR_ERROR_NO_INDEX                   = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0x17);
const HRESULT TR_ERROR_MEMORY_VALUE_OVERWRITE     = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0x18);
const HRESULT TR_ERROR_BAD_INPUT                  = MAKE_HRESULT(SEVERITY_ERROR,FACILITY_NULL, 0x19);
const HRESULT TR_ERROR_BREAKPOINT_ENDOFTRACE      = MAKE_HRESULT(SEVERITY_ERROR, FACILITY_NULL, 0x1A);
const HRESULT TR_ERROR_INCOMPATIBLE_READERS       = MAKE_HRESULT(SEVERITY_ERROR, FACILITY_NULL, 0x1B);
// The reader cannot replay a trace file on a system with a lower processor level
// than the machine that the guest process was recorded on.
const HRESULT TR_ERROR_PROCESSOR_COMPATIBILITY    = MAKE_HRESULT(SEVERITY_ERROR, FACILITY_NULL, 0x1C);
// Log file has no sequence or hard sequence data (i.e. no fixed state to start replay from).
const HRESULT TR_ERROR_NO_SEQUENCE                = MAKE_HRESULT(SEVERITY_ERROR, FACILITY_NULL, 0x1D);
// The trace file is not a TTT trace or it is of the wrong type.  For example you cannot
// open a trace of a 32 bit guest process with the 64 bit reader and visa versa.
const HRESULT TR_ERROR_INCOMPATIBLE_TRACE_FILE    = MAKE_HRESULT(SEVERITY_ERROR, FACILITY_NULL, 0x1E);
// The trace file added to the group reader is not in the correct group.
const HRESULT TR_ERROR_NOT_IN_GROUP               = MAKE_HRESULT(SEVERITY_ERROR, FACILITY_NULL, 0x1F);
// The passed in handle is not valid.
const HRESULT TR_ERROR_INVALID_HANDLE             = MAKE_HRESULT(SEVERITY_ERROR, FACILITY_NULL, 0x20);
// The number of handles needed for threads, module loads, exceptions, or breakpoints exceeds
// the limit.
const HRESULT TR_ERROR_HANDLE_OVERFLOW            = MAKE_HRESULT(SEVERITY_ERROR, FACILITY_NULL, 0x21);
// Cannot evaluate a memory address to a value needed by the Search() API.
const HRESULT TR_ERROR_NO_VALUE                   = MAKE_HRESULT(SEVERITY_ERROR, FACILITY_NULL, 0x22);
// Semantic error in the Search() API expression.
const HRESULT TR_ERROR_EXPRESSION_SEMANTICS       = MAKE_HRESULT(SEVERITY_ERROR, FACILITY_NULL, 0x23);
// The number of sequences the trace holds are too many to process the trace.  The sequence limit
// for each trace when attaching multiple traces to the reader is less than if only reading one
// trace, so just load in one trace to work around this.
const HRESULT TR_ERROR_SEQUENCE_OVERFLOW          = MAKE_HRESULT(SEVERITY_ERROR, FACILITY_NULL, 0x24);
// Not enough privileges to complete the operation.
const HRESULT TR_ERROR_PRIVILEGE                  = MAKE_HRESULT(SEVERITY_ERROR, FACILITY_NULL, 0x25);
// Trying to connect to a debug session that is already active.
const HRESULT TR_ERROR_ALREADY_CONNECTED          = MAKE_HRESULT(SEVERITY_ERROR, FACILITY_NULL, 0x26);
// Result of the operation did not result in a change of state.
const HRESULT TR_ERROR_VALUE_UNCHANGED            = MAKE_HRESULT(SEVERITY_SUCCESS,FACILITY_NULL, 0x27);


//
// Constants
//


//
// TR_MAX_INSTRUCTION_LEN changed between v1 and v2. Code which includes ITraceReader.h
// will pick up the appropriate values from the constants defined below, and code which
// can not include a specific version if ITraceReader.h can instead consume the constants
// below
//

#define TR_MAX_INSTRUCTION_LEN_V1   15
#define TR_MAX_INSTRUCTION_LEN_V2   48

#define TR_MAX_USER_NAME            64
#define TR_MAX_SYSTEM_NAME          64
#define TR_MAX_MARKER_MESSAGE       32

// See GetCodeBytes()
#define TR_DEFAULT_CODEBYTE         0xcc

//
// Forward declare TR_REGISTER_STATE.
// Definitions provided in ITraceReader.h.
//
union TR_REGISTER_STATE;

// Description - SEQUENCES (see the design document for more details):
//  Threads are synchronized using sequence numbers.  If one event has a higher sequence
//  number than another event, that implies that the higher sequence numbered event came later.
//  Sequence numbers cannot be directly used to determine whether one instruction
//  follows another.  Use the ComparePositions method for that.
//
//  A sequence of instructions is the set of instructions on one thread
//  between two sequencing events.
typedef LONGLONG  TR_SEQUENCE;

// All addresses converted to 64bit; 32-bit addresses are NOT sign extended.
// Note on SAFE_TR_ADDRESS: It is designed for dbgeng.  The reason is that
// dbgeng always sign extends 32-bit addresses; defining SAFE_TR_ADDRESS
// enforces proper code to convert between TR_ADDRESSes (not signe-extended)
// and dbgeng's addresses (sign-extended).
#ifdef SAFE_TR_ADDRESS
struct TR_ADDRESS
{
   ULONGLONG Value;
};
#else
typedef ULONGLONG TR_ADDRESS;
#endif

//
// There is one unique position handle for every instruction in the reader.  Positions map instructions.
//
typedef ULONGLONG TR_POSITION_HANDLE;

//
// A ITREADER may contain multiple processes (see AttachTraceFile()).  Each process has a
// unique handle.  The current process is the active process at the current position in
// the trace.
//
typedef ULONG TR_PROCESS_HANDLE;
const TR_PROCESS_HANDLE TR_INVALID_PROCESS_HANDLE = (TR_PROCESS_HANDLE)-1;

//
// There is one unique thread handle per active thread in the reader.
//
typedef ULONG TR_THREAD_HANDLE;

//
// This is one module handle for every unique module loaded in the reader.
//
typedef ULONG TR_MODULE_HANDLE;

//
// There is a unique breakpoint handle for every breakpoint set.
//
typedef ULONG TR_BREAKPOINT_HANDLE;

//
// This handle maps to an exception record corresponding to an
// exception sequencing event.
//
typedef ULONG TR_EXCEPTION_RECORD_HANDLE;

//
// This handle maps a user string marker handle to the
// string.
//
typedef ULONG TR_MARKER_HANDLE;

//
// This handle maps to a logged ETW event.
//
typedef ULONG TR_ETW_EVENT_HANDLE;

//
// Metrics data stored in the trace file.
//
typedef struct TR_METRICS_INFO TR_METRICS_INFO;

typedef struct TR_TIMING_INFO
{
   // GetSystemTime() function timing information.
   FILETIME               SystemTime;
   // GetProcessTimes() function timing information.
   FILETIME               ProcessCreateTime;
   FILETIME               ProcessUserTime;
   FILETIME               ProcessKernelTime;
   // Currently undefined.
   FILETIME               SystemUpTime;
} *PTR_TIMING_INFO;

// NB: For backward compatibility, this structure must NOT be larger than
// MINIDUMP_SYSTEM_INFO, which is 0x38 bytes.
typedef struct KTR_SYSTEM_INFO
{
   USHORT  _ProcessorArchitecture; // 0x02
   USHORT  _ProcessorLevel;        // 0x04

   ULONG   _NtBuildNumber;         // 0x08

   TR_ADDRESS _KernBase;           // 0x10
   TR_ADDRESS _PsLoadedModuleList; // 0x18
   TR_ADDRESS _DebuggerDataList;   // 0x20
} *PKTR_SYSTEM_INFO;

typedef struct TR_SYSTEM_INFO
{
   ULONG                  MajorVersion;   // Log major version
   ULONG                  MinorVersion;   // Log minor version
   ULONG                  BuildNumber;    // Log build version
   // ProcessId is always 0 in kernel-mode.
   ULONG                  ProcessId;      // System Process Id
   TR_TIMING_INFO         Time;
   union
   {
      MINIDUMP_SYSTEM_INFO SystemInfo;    // For user-mode traces.
      KTR_SYSTEM_INFO      KSystemInfo;   // For kernel-mode traces.
   };
   // Name of person that ran the guest process.
   WCHAR                  UserName[TR_MAX_USER_NAME];
   WCHAR                  SystemName[TR_MAX_SYSTEM_NAME];
} *PTR_SYSTEM_INFO;


enum TR_IMAGE_RANGE_TYPE
{
   TR_IMAGE_RANGE_DOS_HEADER,        // Saved IMAGE_DOS_HEADER
   TR_IMAGE_RANGE_FILE_HEADER,       // Saved IMAGE_FILE_HEADER
   TR_IMAGE_RANGE_OPTIONAL_HEADER32, // Saved IMAGE_OPTIONAL_HEADER32
   TR_IMAGE_RANGE_OPTIONAL_HEADER64, // Saved IMAGE_OPTIONAL_HEADER64
   TR_IMAGE_RANGE_DEBUG_DIRECTORY,   // Saved IMAGE_DEBUG_DIRECTORY
   TR_IMAGE_RANGE_DEBUG_DATA,        // Saved debug information from debug directory
   TR_IMAGE_RANGE_VERSION_RESOURCE,  // Saved resource information
};

typedef struct TR_IMAGE_ADDRESS_RANGE
{
   TR_IMAGE_RANGE_TYPE RangeType; // Type of range that has been captured.
   ULONG StartRva;                // The RVA of the range in the original image.
   ULONG Size;                    // Size of the range.
} *PTR_IMAGE_ADDRESS_RANGE;


// When an image is loaded, we capture information from the image that
// is useful to uniquely identify the image and enables loading of
// the matching PDB. This information is the image header (with optional header),
// the debug directories, and the data that is pointed to by the
// debug directories. The HeaderRanges array will describe the type
// of range it is as well as the size and original RVA (offset in the binary).
// The actual data is packed in the HeaderData buffer of the Module.

typedef struct TR_MODULE
{
   TR_SEQUENCE LoadTime;            // 0 indicates no module
   TR_ADDRESS  ModuleBase;
   ULONG       ModuleSize;
   WCHAR       ModuleName[MAX_PATH];
   ULONG       HeaderRangeCount;
   const TR_IMAGE_ADDRESS_RANGE *  HeaderRanges;
   const BYTE * HeaderData;
} *PTR_MODULE;

// On Vista+ systems TTT records an ETW event for all calls to
// EventWrite, EventWriteString, and EventWriteTransfer.  The
// timestamp does not exactly match the timestamp for the
// corresponding event, so given a real ETW timestamp you want
// to find the closest traced ETW timestamp.
typedef struct TR_ETW_EVENT
{
   // QueryPerformanceCounter() and GetSystemTimeAsFileTime().
   LARGE_INTEGER    PerfCounter;
   FILETIME         SystemTime;
   EVENT_DESCRIPTOR Descriptor;
   GUID             ActivityID;
   GUID             RelatedID;
} *PTR_ETW_EVENT;

typedef struct TR_CALLSTACK_POS
{
   TR_POSITION_HANDLE Position; // Trace position
   TR_ADDRESS         ip;       // Call address
} *PTR_CALLSTACK_POS;

//
// A memory value is up to 8 bytes worth of data.  In the case where not all 8
// bytes of data are validly known by the reader, the mask distinguishes
// known bits from unknown ones.  Bits where the mask is set to zero are unknown.
// Values are set on a byte granularity.
typedef struct TR_MEMORY_DATA
{
   TR_POSITION_HANDLE Position;  // Instruction that either read or wrote the value
   TR_ADDRESS         Eip;       // Instruction that references the memory.
   ULONG64            Mask;      // Valid bits within the returned data.
   union {
      ULONG64 Data;         // Value of memory at an address
      BYTE    DataBytes[sizeof(ULONG64)];
   };
} *PTR_MEMORY_DATA;

//
// Breakpoint are used by the TREADER execute operations to stop
// execution when the specified address or position is accessed
// in the specified way.
//
enum TR_BREAKPOINT_TYPE {
   TR_InvalidBP       = 0,
   TR_ExecutionBP     = 1,    // Break at an instruction.
   TR_MemReadBP       = 2,    // Break at next read of a data address.
   TR_MemWriteBP      = 3,    // Break at the next write a data address.
   TR_MemReadWriteBP  = 4,    // Break at the next read or write of a data address.
   TR_PositionBP      = 5,    // Break at an ITraceReader position.
   TR_ExceptionBP     = 6,    // Break at the next exception (any kind).
   TR_ModuleLoadBP    = 7,    // Break at the next module load.
   TR_CreateThreadBP  = 8,    // Start of execution of a thread in the trace.
   TR_DeleteThreadBP  = 9,    // Thread exited.
   TR_MarkerBP        = 10,   // User trace file mark.
   // Note that these events do not necessarily correspond thread creation and
   // deletion events.  They indicate when tracing started and stopped.
   TR_ProcessStartBP  = 11,   // Start of process trace.
   TR_ProcessEndBP    = 12,   // End of process trace.

   // Using these breakpoints, instead of TR_ExceptionBP, allows for more fine grained
   // control of what exceptions the debugger stops at.
   //
   // These breakpoints act to filter out certain types of exceptions.  When a
   // breakpoint is hit, the returned breakpoint type is always TR_ExceptionBP.
   //
   // You can only have one of these breakpoints, including TR_ExceptionBP, defined
   // at once.  SetEventBreakpoint() will return the breakpoint exists error if you
   // define more than one exception breakpoint type at once.
   TR_HardwareExceptionBP = 13, // Break at the next hardware exception.  These types
                                // of exceptions are usually considered debugger
                                // first-chance exceptions.  TTT will not break on
                                // second-chance exceptions, such as C++ EH software
                                // exceptions.
   TR_Reserved1ExceptionBP = 14,
   TR_Reserved2ExceptionBP = 15,
   TR_Reserved3ExceptionBP = 16,
   TR_Reserved4ExceptionBP = 17,
   TR_Reserved5ExceptionBP = 18,

   TR_EtwEventBP           = 19  // ETW Event
};

typedef struct TR_BREAKPOINT
{
   TR_BREAKPOINT_HANDLE Handle;
   TR_BREAKPOINT_TYPE   Type;
   union
   {
      // TR_PosBP
      TR_POSITION_HANDLE Position;
      // TR_ExecutionBP
      TR_ADDRESS         Eip;
      // TR_MemReadBP, TR_MemWriteBP, TR_MemReadWriteBP

#pragma warning(push)
#pragma warning(disable:4201) // allow nameless struct below for compat
      struct {
         TR_ADDRESS  Address;
         ULONG       Range;  // Number of bytes starting at address to watch.
      };
#pragma warning(pop)
      // TR_CreateThreadBP, TR_DeleteThreadBP
      TR_THREAD_HANDLE Thread;
      // TR_ModuleLoadBP
      TR_MODULE_HANDLE Module;
      // TR_ExceptionBP
      TR_EXCEPTION_RECORD_HANDLE ExceptionRecord;
      // TR_MarkerBP
      TR_MARKER_HANDLE Marker;
      // TR_ProcessStartBP, TR_ProcessEndBP
      TR_PROCESS_HANDLE Process;
      // TR_EtwEventBP
      TR_ETW_EVENT_HANDLE EtwEvent;
   };
} *PTR_BREAKPOINT;

typedef struct TR_VERSION_INFO
{
   ULONG32 major;
   ULONG32 minor;
   ULONG32 build;
   ULONG32 log;
} *PTR_VERSION_INFO;

//
// Description (EVENT CALLBACK):
//  The following callback is defined in conjunction with EnumerateEvents() in
//  the ITREADER class.
//
// Parameters:
//  IReader - the reader being enumerated.
//  type    - the event type.
//  pos     - the position of the event.
//  ContextData - data specific to the type of event.  The life time of the
//                context data is until this call returns.
//              - TR_ExceptionBP:    TR_EXCEPTION_RECORD_HANDLE
//              - TR_ModuleLoadBP:   TR_MODULE_HANDLE
//              - TR_CreateThreadBP: TR_THREAD_HANDLE
//              - TR_DeleteThreadBP: TR_THREAD_HANDLE
//              - TR_MarkerBP:       TR_MARKER_HANDLE
//              - TR_EtwEventBP:     TR_ETW_EVENT_HANDLE
//  ClientData - the user value passed in from EnumerateEvents().
//
// Return Value:
//  The search stops if FALSE is returned or continues if TRUE is returned.
typedef BOOL (CALLBACK *TR_EVENT_CALLBACK)(PITREADER IReader,
                                           const TR_BREAKPOINT_TYPE Type,
                                           const TR_POSITION_HANDLE Position,
                                           const ULONG ContextData,
                                           PVOID ClientData);

//
// Description (DATA CALLBACK):
//  The following callback can be defined in conjunction with the search operations in
//  the ITREADER class.  If the callback returns TRUE the search continues or else
//  the search stops and the data is returned to the caller.  You cannot make any assumption
//  about the state of the arguments after the callback exits.
typedef BOOL (CALLBACK *TR_DATA_CALLBACK)(PITREADER IReader,
                                          const TR_ADDRESS Addr,
                                          const ULONG Count,
                                          const TR_MEMORY_DATA Data[],
                                          PVOID UserContext);

//
// Description (EXECUTION CALLBACKS):
//
// The TR_CONTEXT structure contains the state of execution.  It is read-only, except *ClientData.
// *ClientData is valid across multiple execution operations.
//
typedef struct _TR_CONTEXT
{
    PVOID    *ClientData;        // per thread pointer that can be used by the client
    TR_REGISTER_STATE *CpuRegs;  // pointer to the CPU state (see x86state.h/x64state.h)
                                 //  all registers, except eflags are valid.
    PITREADER IReader;
    PVOID     ContextData;  // Event specific data passed back by the reader (Ex. read data in read event)
} TR_CONTEXT, *PTR_CONTEXT;

// ITREADER supported callbacks.
enum TR_CALLBACK_TYPE {
   TR_InvalidEvent = 0,
   TR_TranslationEvent,
      // callback(context, type, eip, nir) Use GetCodeBytes(eip) to get the code.
   TR_RunInstructionStartEvent,
      // callback(context, type, eip, nir)
   TR_RunSequencingEvent,
      // callback(context, type, [optional] , TR_SEQUENCE_TYPE) ContextData points to the sequence number
   TR_RunMemRefEvent,
      // callback(context, type, addr,  )
   TR_RunMemReadEvent,
   TR_RunMemWriteEvent,
   TR_RunMemImplicitReadEvent,
   TR_RunMemImplicitWriteEvent,
      // callback(context, type, addr, datasize) ContextData points to the value at addr
   TR_RunAllFlowChangeEvent,
      // callback(context, type, target-addr, fallthrough-addr)
   TR_RunCallRetsEvent,
      // callback(context, type, target-addr, fallthrough on call AND null on return)
   TR_DllLoadEvent, // Registers module unload event also.
      // callback(context, type,  ,  ) ContextData points to TR_MODULE.
   TR_ThreadEvent,
      // callback(context, type, , TRUE|FALSE) - TRUE is create, FALSE is terminate
      //                                    ContextData points to TR_THREAD_HANDLE.
   TR_RandomSampleEvent,
      // callback(context, type, sample-run-number, TRUE|FALSE)
      //    sample-run-number = unique ULONG for each sample run, 0 for inter-sample
      //    TRUE|FALSE = TRUE for sample start (thread about to enter),
      //                 FALSE for sample finish (thread just exited)
      // Each thread will generate callbacks as a sample run starts, so only after
      // the last one associated with a sample-run-number have all threads been
      // acquired by Nirvana.  All threads that exit at the end of a sample run
      // will also generate callbacks, so as soon as the first finish event is
      // received Nirvana is no longer in control of all threads.
   TR_DllUnloadEvent, // Registers module load event also.
      // callback(context, type,  ,  ) ContextData points to TR_MODULE
   TR_MarkerEvent, // User inserted string marker
      // callback(context, type,  ,  ) ContextData points to the string.

   // While recording a guest process, TTTracer may log parts of the memory state at
   // certain sequences.  While replaying the trace a client can retrieve that memory
   // by registering for this callback.  The memory returned is the current memory
   // state of the guest process at the point in time the callback is made.  Translation
   // and memory event callbacks may update this memory subsequently.  Use
   // GetImageBytes(sequence, addr, size, ...) to retrieve the memory.
   // If you jump backwards in the trace to any position but the first, the behavior
   // of the callback is undefined.  It assumes you start executing at the start of
   // the trace and move forward.
   TR_MemoryBlockEvent,
      // callback(context, type, addr, size) ContextData points to the sequence number
   TR_ProcessEvent,
      // callback(context, type, , TRUE|FALSE) - TRUE is start tracing, FALSE is stop tracing
      //                                    ContextData points to TR_PROCESS_HANDLE.
   TR_BlockTranslationEvent,
      // callback(context, type, eip, nir)
   TR_FullFlushEvent,
      // callback(context, type, , CodeGenerationId)
};

enum TR_SEQUENCE_TYPE {
   TR_InvalidSequence = 0,

   // User-mode sequence types
   TR_EnterThread,           // we are starting simulation at a new thread state;
                             // the [optional] third parameter is a LONGLONG
                             // representing the performance counter value at this
                             // point during recording.  See QueryPerformanceFrequency
                             // in this interface to get the frequency.
   TR_ExitThread,            // we are exiting simulation
   TR_AtomicOp,              // instruction just executed an atomic operation
   TR_RegStateChanged,       // OBSOLETE: non-deterministic register change
   TR_InvalidInstr,          // invalid (or unrecognized) instruction (exits simulation)
   TR_TrapToNative,          // we are about to trap (exits simulation)
   TR_CodeCacheFlush,        // code cache flushed
   TR_EndOfThread,           // Reached the last instruction in the thread in the trace
   TR_Exception,             // Hit an exception.  The [optional] third parameter is the
                             // handle for the exception record.
   TR_Abort,                 // Tracing aborted
   TR_SequenceStart,         // About to execute a new sequence of instructions
   TR_DebugBreak,            // Hit a debug breakpoint (int 3). (exits simulation)
   TR_OpaqueData,            // system-dependent data (CPUID/RDTSC/SGDT/...)
   TR_SequenceEnd,           // Finished executing a sequence of instructions
   TR_LastUserModeSequenceType,

   // Kernel-mode sequence types
   KTR_SequenceStart = TR_SequenceStart,
   KTR_SequenceEnd = TR_SequenceEnd,
   // 1. events that indicate beginning simulation at a new state
   KTR_Interrupt = 0x41,     // interrupt
   KTR_Syscall = 0x42,       // syscall
   // 2. events that occur during simulation
   KTR_AtomicOp = TR_AtomicOp,
   KTR_OpaqueData = TR_OpaqueData,
   KTR_CodeCacheFlush = TR_CodeCacheFlush,
   // 3. events that indicate ending simulation
   KTR_InvalidInstr = TR_InvalidInstr,
   KTR_SwitchToUserMode = 0x61,
   KTR_SwitchToNative = 0x62,// due to change of mode (e.g., into real mode)
   KTR_Halt = 0x63           // Hlt instruction
};

inline bool TrIsUserModeSequenceType(TR_SEQUENCE_TYPE seq)
{
   return (seq > TR_InvalidSequence) && (seq < TR_LastUserModeSequenceType);
}

inline bool TrIsKernelModeSequenceTypeBeginSimulation(TR_SEQUENCE_TYPE seq)
{
   return (seq == KTR_Interrupt) || (seq == KTR_Syscall);
}

inline bool TrIsKernelModeSequenceTypeContinueSimulation(TR_SEQUENCE_TYPE seq)
{
   return (seq == KTR_AtomicOp) ||
          (seq == KTR_OpaqueData) ||
          (seq == KTR_CodeCacheFlush);
}

inline bool TrIsKernelModeSequenceTypeEndSimulation(TR_SEQUENCE_TYPE seq)
{
   return (seq == KTR_InvalidInstr) ||
          (seq == KTR_SwitchToUserMode) ||
          (seq == KTR_SwitchToNative) ||
          (seq == KTR_Halt);
}

inline bool TrIsKernelModeSequenceType(TR_SEQUENCE_TYPE seq)
{
   return (seq == KTR_SequenceStart) ||
          (seq == KTR_SequenceEnd) ||
          TrIsKernelModeSequenceTypeBeginSimulation(seq) ||
          TrIsKernelModeSequenceTypeContinueSimulation(seq) ||
          TrIsKernelModeSequenceTypeEndSimulation(seq);
}

typedef void (__fastcall *TR_EXECUTION_CALLBACK)(struct _TR_CONTEXT const *, TR_CALLBACK_TYPE ,void *,void *);

// Information about how the trace was captured.
enum TR_TRACE_CAPTURE_FLAGS
{
   TR_CaptureRingBuffer        = 0x1, // Full trace if not set.

   // If neither of the next two flags are set, then how tracing
   // attached to the process is unknown.  This is possible with
   // older trace files where this information is not available.
   TR_CaptureAttachRunning     = 0x2, // Tracing started on an already running process.
   TR_CaptureAttachStartup     = 0x4, // Tracing started right when the guest process
                                      // was launched.

   TR_CaptureTraceChildren     = 0x8, // Children of this process are traced too.

   // When you trace managed code a full dump is captured at trace time even if the
   // -DumpFull option isn't used.  If the option is used then the full dump occurs
   // before the first instruction is traced.  If the full dump is implicit, then the
   // dump occurs later in the trace so that memory won't be available until
   // after the CLR (mscorwks) is loaded.  If the full dump is implicit,
   // TR_CaptureDumpModules is not set, while if it is explicit it is set.
   TR_CaptureDumpModules       = 0x10, // Entire binaries are included in the trace.
   TR_CaptureDumpFull          = 0x20, // The snapshot of the process is included in
                                       // this trace (this also implies Peb/Teb and
                                       // module data).
   TR_CapturePebTeb            = 0x40, // Peb and Teb data is in the trace.

   // This trace was captured using group sequencing.  This means that the trace has a
   // group identifier and multiple traces with the same group ID were recorded in a
   // synchronized fashion  (i.e. Their sequence events are interleaved as if the traces'
   // threads were running in a single process).
   TR_CaptureGrouped           = 0x80
};

/* de137e92-952c-4cf7-8836-d9b473c6cafe */
DEFINE_GUID(IID_ITREADER_GROUP,
            0xde137e92,
            0x952c,
            0x4cf7,
            0x88, 0x36, 0xd9, 0xb4, 0x73, 0xc6, 0xca, 0xfe);

typedef interface DECLSPEC_UUID("de137e92-952c-4cf7-8836-d9b473c6cafe") ITREADER_GROUP* PITREADER_GROUP;

//
// The ITREADER interface
//

// The following API creates an ITREADER interface.
// In addition to the defined API return values, all the API's return TR_ERROR_INVALID_READER if
// an internal error in the reader has occurred.  In this case the reader is in an irrecoverable
// state.  You can create multiple readers in a single process or add multiple processes to a
// single reader, with the restrictions that if there is more than one
// reader or process you cannot commit a memory index to any of the open trace files and
// you must create all your readers and attach to all your trace files before calling on any
// other API's in any of those readers.
// See CreateMemoryIndex() AttachTraceFile() for more details.
extern "C" ITREADER* __cdecl CreateITReader();


// Function: CreateDbgCmdTree
// Description:
// Call to generate .cmdtree file for the given ITReader instance.
// Parameters:
// [in]     TracePath: the trace file path cmd file will be based on.
// [out]    CmdFilePath: the full path of Windbg Command File.
// [out]    PathLen: the buffer length of cmdFileName.
// [in]     ForceOverwrite: True for always create command tree file
//                          overwriting the exisiting file.
extern "C" HRESULT   __cdecl CreateDbgCmdTree(
   __in  ITREADER*  pTraceReader,
   _Out_writes_z_(PathLen) WCHAR* CmdTreePath,
   __in  size_t PathLen,
   __in  bool   ForceOverwrite);


#undef INTERFACE
#define INTERFACE ITREADER
DECLARE_INTERFACE_(ITREADER, IUnknown)
{
   // IUnknown.
   STDMETHOD(QueryInterface)(
       __in REFIID InterfaceId,
       __out PVOID* Interface
       ) PURE;

   STDMETHOD_(ULONG, AddRef)() PURE;
   STDMETHOD_(ULONG, Release)() PURE;

   //
   // Description:
   //  Attach a trace file to the reader.  If this is successful, the
   //  position is the first instruction in the trace.  You can attach
   //  multiple trace files to a reader, where each trace file represents
   //  a single traced process.  You must attach all of your trace files
   //  before calling on any other API's in this interface.
   //
   //  NOTE: In the multi-reader scenario, you cannot call this after you
   //  call any other API's in this interface in any of the readers
   //  (i.e. you must attach to all your trace files up front).
   //
   // Parameters:
   //  TraceFile - NULL terminated file name of trace of a program's execution.
   //
   // Return Value:
   //  TR_ERROR_SUCCESS - no problem.
   //  TR_ERRCODE_BAD_FILE_FORMAT - file not a valid application trace.
   //  TR_ERRCODE_FILE_NOT_FOUND - file not found.
   //  TR_ERROR_TRACEFILE_READER_VERSION_MISMATCH - reader and log version do not match.
   //  TR_ERROR_OUTOFMEMORY - client could not be created because of memory issue.
   //  TR_ERROR_TOO_MANY_READERS - Attempt to attach a trace file to a reader after
   //  a reader in the same process has already started execution.
   //  TR_ERROR_SEQUENCE_OVERFLOW - The trace file has too many sequences to process.  The
   //  maximum number of sequences when attaching multiple trace files is less than when
   //  attaching one file, so if this is the second trace file you are attaching the problem
   //  could be with the first one.
   STDMETHOD(AttachTraceFile)(
       __in const PWCHAR TraceFile
       ) PURE;

   //
   // POSITIONING / THREAD STATE
   //   A position is the location of an instruction in the trace.  There is one unique
   //   position per instruction.
   //

   //
   // Description:
   //  The following operation compares how two positions relate in terms of execution time
   //  to each other in a trace.  It is legal to compare positions on different threads or
   //  processes, but comparing positions from two different readers or an invalid position
   //  results in an exception.
   //  To determine if two positions are the same instruction, the position thread and
   //  instruction count must be equal.
   //
   // Parameters:
   //  pos1    - position that is being compared.
   //  pos2    - position that is being compared.
   //
   // Return Value:
   //  On a single thread the results of these operations are simply based on the relative
   //  order of the instructions these position represent.  When comparing positions across
   //  two threads, it may only be possible to know the relative order of a range of instructions
   //  in each thread.  If the range of instructions the two positions are in fall into the same
   //  sequence, those two positions are considered equal.
   //  If pos1 > pos2 it returns > 0
   //  If pos1 < pos2 it returns < 0
   //  If pos1 = pos2 it returns 0
   //
   // If the positions are invalid this throws an exception.
   STDMETHOD_(LONG, ComparePositions)(
      __in const TR_POSITION_HANDLE pos1,
      __in const TR_POSITION_HANDLE pos2) const PURE;

   // Description:
   //  Each position is tied to a particular thread.
   //
   // Return Values:
   //  This either returns TR_ERROR_SUCCESS or TR_ERROR_INVALID_POSITION.
   STDMETHOD(GetThread)(
      __in const TR_POSITION_HANDLE pos,
      __out TR_THREAD_HANDLE & thread) const PURE;

   // Description
   //  This returns a copy of the code bytes at the given IP address and time position
   //  in the reader.  Because of delay loaded modules and self-modifying code, code bytes
   //  may be different at the same IP at different places in the trace.  Any bytes in the range
   //  that are unknown are filled in with the TR_DEFAULT_CODEBYTE opcode.
   //
   // Parameters:
   //  pos - The position in the trace.
   //  ip  - The instruction pointer address.
   //  length - Length of the code bytes buffer.
   //  codeBytes - A copy of the code bytes.
   // Return Value:
   //  Returns TR_ERROR_SUCCESS or it
   //  returns TR_ERROR_INVALID_POSITION if the passed in position is not valid.
   STDMETHOD(GetCodeBytes)(
      __in const TR_POSITION_HANDLE pos,
      __in const TR_ADDRESS         ip,
      __in const ULONG              length,
      __out_ecount(length) BYTE     codeBytes[]) const PURE;

   //
   // Description:
   //  Returns the current register state of the passed in thread.  Event callbacks
   //  (see RegisterEventCallback) should use the register state in the context
   //  whenever possible, since this operation is less efficient.  The only reason
   //  to use this operation within a callback is to get the valid eflags.
   //
   // Parameters:
   //  thread - The handle of the thread to get the registers from.
   //  Regs - The register values.
   //
   // Return Value:
   //  This returns TR_ERROR_SUCCESS or TR_ERROR_FAILURE if called during
   //  execution.
   //
   // Note: this is now deprecated. Used by the debugger only in support of iDNA v1 kernel-mode traces.
   // Use the methods in the new ITREADER3 interface instead to obtain the register context of a thread.
   STDMETHOD(GetRegisters)(
      __in const TR_THREAD_HANDLE thread,
      __out TR_REGISTER_STATE & Regs) PURE;

   //
   // GLOBAL DATA
   //

   // Description:
   //  The following two operations convert reader handles to their appropriate
   //  types.
   //
   // Parameters:
   //  <handle> - The handle.
   //  <type>   - The converted type.
   //
   // Return Values:
   //  If the handle is valid it returns the TR_ERROR_SUCCESS or it returns
   //  TR_ERROR_FAILURE.
   STDMETHOD(ConvertHandleToModule)(
      __in const TR_MODULE_HANDLE Handle,
      __out TR_MODULE & Module
   ) PURE;

   STDMETHOD(ConvertHandleToExceptionRecord)(
      __in const TR_EXCEPTION_RECORD_HANDLE Handle,
      __out EXCEPTION_RECORD64 & ExceptionRecord
   ) PURE;

   //
   // Description:
   //  Returns the first and last sequence number for those
   //  sequences of instructions in the trace(s).
   //
   // Parameters:
   //  FirstSeq  - The first sequence of instructions in the trace.
   //  LastSeq   - The last sequence of instructions in the trace.
   //
   STDMETHOD_(VOID, GetTraceBoundarySequences)(
      __out TR_SEQUENCE & FirstSeq,
      __out TR_SEQUENCE & LastSeq) const PURE;

   // Description:
   //  This operation returns a thread handle for each thread of execution
   //  in the trace associated with the current process.
   //
   // Parameters:
   //  ThreadsLen - The length of Threads[].
   //  Threads - The thread handles; there is one unique thread handle per thread in
   //            the trace.  If this is NULL and ThreadLen is 0, it just
   //            returns the ThreadCount.
   //  ThreadsCount - The number of unique threads in the trace.
   //
   // Return Values:
   //  If the passed in thread count is large enough it returns TR_ERROR_SUCCESS,
   //  the threads, and the actual thread count.  If Threads[] is not large enough
   //  it returns TR_ERROR_MORE_DATA and returns as many thread handles as will fit.
   //  The returned ThreadCount is the length needed in Threads[].
   STDMETHOD(GetThreads)(
      __in const ULONG  ThreadsLen,
      __out_ecount_opt(ThreadsLen) TR_THREAD_HANDLE Threads[],
      __out ULONG      &ThreadsCount
   ) PURE;

   // Description:
   //  This operation returns all the modules loaded into the trace at the time of
   //  the passed in position.  If there are overlapping modules it returns the
   //  module loaded closest to the current position.
   //
   // Parameters:
   //  pos - A reader position.
   //  Length - The length of the passed in module array.
   //  Modules - The module array.
   //  Count - The actual number of modules.  This can be greater than Length if
   //          TR_ERROR_MORE_DATA is returned.
   //
   // Return Values:
   //  If the passed in module count is large enough it returns TR_ERROR_SUCCESS,
   //  the modules, and the actual module count.  If Modules[] is not large enough
   //  it returns TR_ERROR_MORE_DATA and returns as many modules as will fit, and
   //  it returns the size of the array that is needed in Count.  The modules are
   //  returned in ascending address range order.
   STDMETHOD(GetModules)(
      __in const TR_POSITION_HANDLE pos,
      __in const ULONG         Length,
      __out_ecount_opt(Length) TR_MODULE    Modules[],
      __out ULONG          &Count
   ) PURE;

   //
   // Description:
   //  Returns the name of the trace file associated with the currently executing
   //  process.
   //
   // Parameters:
   //
   // Return Values:
   //  Returns the name of the trace file this reader is associated with.
   STDMETHOD(GetTraceFileName)(__out WCHAR file[MAX_PATH]) const PURE;

   //
   // Description:
   //  Retrieves information about the trace file, process, and system
   //  the trace was taken on.  This returns the system information for
   //  the currently executing process.
   //
   // Parameters:
   //  sysinfo - holds all the information.
   STDMETHOD(GetTraceSystemInfo)(
      __out TR_SYSTEM_INFO & sysinfo) const PURE;

   //
   // Description:
   //  Retrieves the unique identifier for the trace file of the currently
   //  executing process.
   //
   // Parameters:
   //  id - the unique guid
   STDMETHOD(GetTraceIdentifier)(
      __out GUID & id) const PURE;

   //
   // THREAD DATA
   //

   // Description:
   //  Returns the threads system id.
   //
   // Parameters:
   //  Thread - the thread.
   //  id     - the thread's system ID.
   STDMETHOD(GetThreadId)(
      __in const TR_THREAD_HANDLE thread,
      __out DWORD & id) const PURE;

   // Description:
   //  Returns the position of the first instruction to execute in the
   //  passed in thread.
   //
   // Parameters:
   //  Thread - the thread.
   //  Pos    - the first position to execute in the thread.
   STDMETHOD(GetThreadStartPosition)(
      __in const TR_THREAD_HANDLE Thread,
      __out TR_POSITION_HANDLE & Pos) const PURE;

   //
   // NAVIGATION
   //

   //
   // Description:
   //  Returns the current position of the reader in the trace.  The current position
   //  after the reader is created is the first instruction in the trace to execute.
   //  The current position is updated when the client executes (see EXECUTION below) forwards
   //  or backwards.
   //
   // Parameters:
   //  Pos    - Returned position.
   //
   // Return Value:
   //  This returns TR_ERROR_FAILURE or TR_ERROR_SUCCESS.
   STDMETHOD(GetCurrentPosition)(
      __out TR_POSITION_HANDLE & Pos) const PURE;

   //
   // Description:
   //  Returns the current position of the reader in the trace on a
   //  thread.  The current position of each thread after the reader
   //  is created is the first instruction of each thread.  The current position
   //  is updated when the client executes (see EXECUTION below) forwards or
   //  backwards.
   //
   // Parameters:
   //  thread - Position in this thread.
   //  Pos    - Returned position.
   //
   // Return Value:
   //  This returns TR_ERROR_FAILURE or TR_ERROR_SUCCESS.
   STDMETHOD(GetCurrentPosition)(
      __in  const TR_THREAD_HANDLE thread,
      __out TR_POSITION_HANDLE & Pos) const PURE;

   //
   // Description:
   //  Returns the instruction sequence the passed in position is in.
   //
   // Parameters:
   //  Pos    - A trace file position.
   //  Seq    - The sequence that position is in.
   //
   // Return Value:
   //  This returns TR_ERROR_FAILURE or TR_ERROR_SUCCESS.
   STDMETHOD(GetPositionSequence)(
      __in const TR_POSITION_HANDLE Pos,
      __out TR_SEQUENCE & Seq) const PURE;

   //
   // EXECUTION (REPLAY)
   //

   //
   // Description:
   //  The execute operations simulate execution from the current position in the trace until
   //  a breakpoint is hit or the trace ends.  If a breakpoint is hit, that breakpoint
   //  is returned and the current position in the trace is the next instruction to execute.
   //
   //  Instructions are executed in the order of their sequences.  For example, all the
   //  instructions in sequence one are executed, then all the instructions in sequence
   //  two are executed, then sequence three, etc...  This is not necessarily the same
   //  order the instructions are executed at recording time, however, if two adjoining
   //  sequences overlap.  The search operations, as opposed to breakpoints, should be used
   //  determine memory access ording, since the search operations indicate whether or
   //  not multiple access happened in overlapping sequences.
   //
   //  The reader maintains the current state of each thread.  When execution ends the state
   //  (or position) is the next instruction to execute on each thread.
   //
   //  When the step argument is used, the reader steps forward the specified number of
   //  instructions in the current thread.  If it hits a sequence of instructions in
   //  another thread, it executes through those instruction until it gets back to the
   //  current thread.  If it hits a breakpoint on the current or a different thread
   //  before it finishes executing the specified number of instructions, it stops
   //  at the breakpoint.  It will only stop at breakpoints in the process owning the
   //  current thread.
   //
   //  The ExecuteForward operation supports registering Nirvana style callbacks.  When a
   //  callback generating event is hit, all the registered callbacks for that event are
   //  called.
   //
   // Parameters:
   //  step        - Number of instructions to execute.  If this is zero it executes to the
   //                next breakpoint.
   //  bphit       - If non-NULL this returns a pointer to the breakpoint from the
   //                breakpoint array that is hit.
   //
   // Return Value:
   //  TR_ERROR_SUCCESS if it executes the number of steps given.
   //  TR_ERROR_BREAKPOINT_HIT if execution stops at a breakpoint.
   //  TR_ERROR_ENDOFTRACE if it executes to the end/start of the trace.
   //  TR_ERROR_INVALID_POSITION if the step goes past the first instruction of the trace (backwards exec).
   STDMETHOD(ExecuteForward)(
      __in  const ULONGLONG        step,
      __out TR_BREAKPOINT        & bphit) PURE;

   // Backwards execution does not support replay callbacks.
   STDMETHOD(ExecuteBackwards)(
      __in  const ULONGLONG        step,
      __out TR_BREAKPOINT        & bphit) PURE;

   // Description:
   //  Sets the execution state of the reader to the passed in position.  No callbacks
   //  are called or breakpoints hit when this operation is used.
   //  If the position passed in is 0 to 100 it treats the position as a percent through
   //  the trace.  For example if you pass in 50, it jumps to a position approximately
   //  50% through the trace.  If you pass in 0 it jumps to the first position in the
   //  trace.
   //
   // Parameters:
   //  position - position to jump to or the percent through the trace.
   //
   // Return Values:
   //  TR_ERROR_SUCCESS if it jumps to the position.
   //  TR_ERROR_INVALID_POSITION if the position not a valid position in this trace.
   STDMETHOD(JumpToPosition)(
      __in const TR_POSITION_HANDLE position) PURE;

   // Description:
   //  Registers a Nirvana style event callback.  These events only occur during
   //  forward execution.  To change a callback simply call this function
   //  again with a different callback operation, and to remove a callback, pass NULL
   //  in as the function pointer.
   //
   //  The reader client can stop forward execution by calling on StopExecution() from any
   //  of these callbacks.  All of the supported events, except for TranslateEvent, occur
   //  at the same point in execution as they occurred during recording.  The translation
   //  event happens when an instruction is JIT'd to the Nirvana code cache at replay time.
   //
   //  The event callback is registered for all processes contained in the reader.
   //
   // NOTE: Replay clients cannot dereference address and IP pointers and expect to get to
   //       anything meaningful.
   //
   // Parameters:
   //  e - The callback event to be registered.
   //  callback - TTT client's callback
   //
   // Return Value:
   //  Returns TR_ERROR_SUCCESS if the callback is registered or removed.
   //  Returns TR_ERROR_FAILURE if the event is unsupported.
   STDMETHOD(RegisterEventCallback)(
      __in TR_CALLBACK_TYPE e,
      __in TR_EXECUTION_CALLBACK callback) PURE;

   // Description:
   //  The following operation sets a breakpoint that is used to stop both
    //  forward and backwards execution at the specified position.
   //
   // Parameters:
   //  pos - position in the trace(s).
   //  bp - breakpoint handle (only set if a new breakpoint is created).
   //
   // Return Value:
   //  Return either TR_ERROR_SUCCESS or TR_ERROR_INVALID_POSITION.  Returns
   //  TR_ERROR_BREAKPOINT_EXISTS if the breakpoint already exists.
   //  The current instruction when the breakpoint is hit (next instruction to execute)
   //  is the instruction at the position in the breakpoint.
   STDMETHOD(SetPositionBreakPoint)(
      __in const TR_POSITION_HANDLE pos,
      __out TR_BREAKPOINT_HANDLE & bp
      ) PURE;

   // Description:
   //  The following operation sets a breakpoint that is used to stop both
   //  forward and backwards execution.  The breakpoint is set in the current
   //  process.
   //
   // Parameters:
   //  eip - instruction in the trace.
   //  bp - breakpoint handle (only set if a new breakpoint is created).
   //
   // Return Value:
   //  Returns TR_ERROR_SUCCESS or TR_ERROR_BREAKPOINT_EXISTS
   //  if the breakpoint already exists.  The current instruction
   //  when the breakpoint is hit (next instruction to execute) is the
   //  instruction at the IP in the breakpoint.
   STDMETHOD(SetExecutionBreakPoint)(
      __in const TR_ADDRESS eip,
      __out TR_BREAKPOINT_HANDLE & bp
      ) PURE;

   // Description:
   //  The following operation sets a breakpoint that is used to stop both
   //  forward and backwards execution.  The breakpoint is set in the current
   //  process.
   //
   // Parameters:
   //  type - read/write/readwrite BP
   //  addr - data address referenced in the trace
   //  range - the reader will break on any address from [address,address+range)
   //  bp - breakpoint handle (only set if a new breakpoint is created).
   //
   // Return Value:
   //  This operation returns TR_ERROR_SUCCESS if it succeeds, TR_ERROR_FAILURE, or
   //  TR_ERROR_BREAKPOINT_EXISTS if exact watchpoint already exists.  The
   //  current instruction when the breakpoint is hit is the instruction following the
   //  instruction that referenced the watched memory.
   STDMETHOD(SetMemoryBreakPoint)(
      __in const TR_BREAKPOINT_TYPE  type,
      __in const TR_ADDRESS          addr,
      __in const ULONG               range,
      __out TR_BREAKPOINT_HANDLE & bp
      ) PURE;

   // Description:
   //  The following operation sets the reader to break on certain
   //  events that occur during execution.  The breakpoint is set
   //  in the current process.
   //
   // Parameters:
   //  type - the supported types are TR_ModuleLoad, TR_Exception (and filters),
   //         TR_Marker, TR_CreateThread, and TR_DeleteThread.
   //  bp - breakpoint handle (only set if a new breakpoint is created).
   //
   // Return Value:
   //  Returns TR_ERROR_SUCCESS or TR_ERROR_BREAKPOINT_EXISTS
   //  if the breakpoint already exists.  It returns TR_ERROR_FAILURE
   //  if an unsupported type is given.
   STDMETHOD(SetEventBreakPoint)(
      __in const TR_BREAKPOINT_TYPE type,
      __out TR_BREAKPOINT_HANDLE & bp
      ) PURE;

   // Description:
   // Query the Memory Breakpoint with the specified type from the current
   // process.
   //
   // Parameters:
   //  type - read/write/readwrite BP
   //  addr - data address referenced in the trace
   //  range - the reader will break on any address from [address,address+range)
   //  bp    - validate breakpoint handle if successful, otherwise NULL.
   //
   // Return:
   // TR_ERROR_SUCCESS if successful.
   STDMETHOD(GetMemoryBreakPoint)(
      __in const TR_BREAKPOINT_TYPE type,
      __in const TR_ADDRESS         addr,
      __in const ULONG              range,
      __out TR_BREAKPOINT_HANDLE &bp
      ) PURE;


   // Description:
   // Query the Execution Breakpoint with the specified type from the current
   // process.
   //
   // Parameter:
   //  eip - instruction in the trace.
   //  bp    - validate breakpoint handle if successful, otherwise NULL.
   //
   // Return:
   // TR_ERROR_SUCCESS if successful.
   STDMETHOD(GetExecutionBreakPoint)(
       __in const TR_ADDRESS eip,
       __out TR_BREAKPOINT_HANDLE &bp
      ) PURE;

   // Description:
   // Query the Position Breakpoint with the specified type.
   //
   // Parameter:
   //  pos - position in the trace.
   //  bp    - validate breakpoint handle if successful, otherwise NULL.
   //
   // Return:
   // TR_ERROR_SUCCESS if successful.
   STDMETHOD(GetPositionBreakPoint)(
       __in const TR_POSITION_HANDLE pos,
       __out TR_BREAKPOINT_HANDLE &bp
      ) PURE;

   // Description:
   // Query the Event Breakpoint with the specified type from the
   // current process.
   //
   // Parameter:
   //  type - event type
   //  bpHandle - returned handle
   //
   // Return:
   // TR_ERROR_SUCCESS if successful.
   STDMETHOD(GetEventBreakPoint)(
      __in const TR_BREAKPOINT_TYPE type,
      __out TR_BREAKPOINT_HANDLE &bpHandle
      ) PURE;

   // Description:
   //  Clears the breakpoint represented by the handle from the process
   //  it exists in.
   //
   // Parameters:
   //  bp - breakpoint handle.
   //
   // Return Value:
   //  Return TR_ERROR_SUCCESS or TR_ERROR_FAILURE if the breakpoint doesn't exist.
   //  After this returns the handle is no longer valid.
   STDMETHOD(ClearBreakPoint)(
      __in const TR_BREAKPOINT_HANDLE bp
      ) PURE;

   // Description:
   //  Clears any active breakpoints from all processes.
   STDMETHOD_(void, ClearAllBreakpoints)() PURE;

   //
   // SEARCH OPERATIONS
   //

   // NOTE: Memory search operations cannot be called from within a registered
   //       callback.  They all return memory values from the current process.

   //
   // Description:
   //  Get the memory data value(s) at the passed in address in the passed in range from
   //  the current position.  Each data value is from 1 to 8 bytes, where the valid parts
   //  of that value are indicated in the TR_MEMORY_DATA structure.  In a
   //  multi-threaded application it may not be possible to know what the one
   //  dereferenced value of an address is, since the true ordering of the instructions
   //  during execution is only partially recorded in the trace.  If this is the case,
   //  the API returns mutliple possible values.
   //
   //  This operation works by searching for accesses to the range back from the
   //  current position.  It is possible that the first access found by the search
   //  will yield only a partial result.  In this case this operation continues
   //  to resolve the unknown bytes in the range by searching back from the initial
   //  access.  The position returned to the caller is the position of the closest
   //  access to any byte in the range, however.  If the search cannot resolve the
   //  full range of bytes, it indicates which bytes are unknown using the mask in
   //  the return data.
   //
   //  There are some cases where this operation can get the memory value, but it cannot
   //  get the location of that value.  In this case it sets the position of the value
   //  to 0.  This happens when the address range is within the code space or the reader
   //  cannot efficiently look up where the value come from.
   //
   //  NOTE: The client of the reader cannot assume that the trace holds a
   //  snapshot of all of memory at every instruction.  Because of this, the
   //  dereferenced values at some addresses are unknown.  Typically the known
   //  values are values that are read or written by the traced process.  Also, if
   //  a secondary process modifies memory in the traced process, the only value
   //  that is guaranteed to be correct is the value read by the current
   //  instruction.
   //
   //  NOTE: The reader only searches back a limited number of instructions when getting
   //  a memory value.  In order to get the value of any memory address accessed before
   //  the current location, the user must create index of the trace file.  See
   //  CreateMemoryIndex() for more details.
   //
   // Parameters:
   //  Address   - Address to start the search from
   //  Range     - Range to search (1 to 8 bytes).
   //  DataCmpProc - Optional (can be NULL) comparison procedure to enable the client
   //                to reject a found value, so that the search can continue
   //                to the next one.  You can set these operations up as iterators by
   //                always returning TRUE.  After the callback returns, the data passed
   //                into that callback is undefined, so save it if you want to keep it.
   //                CALLBACKS ARE CURRENTLY NOT IMPLEMENTED
   //  DataCount - Length of passed in Data array.
   //  Data      - Array of data values.  This can be NULL if the caller just wants
   //              the DataCount.
   //  DataCount - Number of Data items.  This can be greater than DataLen (see Return Values).
   //
   // Return Value:
   //  TR_ERROR_SUCCESS if it succeeds.  DataCount contains the number of returned
   //  data items.
   //  TR_ERROR_MORE_DATA if the Data array is not large enough to hold all the potential
   //  returned values.  In this case DataCount holds the length of the Data array that
   //  it needs to hold all the values, and the Data[] array holds as much as it can.  This
   //  is a potentially expensive operation, so sizing the Data[] array correctly the first
   //  time is recommended.
   //  TR_ERROR_ADDR_NOT_FOUND if the value of this address plus range is unknown by
   //  the reader.
   //  TR_ERROR_FAILURE if the range is not from 1 to 8 bytes.
   STDMETHOD(GetMemoryValue)(
      __in const TR_ADDRESS         Address,
      __in const ULONG              Range,
      __in_opt TR_DATA_CALLBACK     DataCmpProc,
      __in const ULONG              DataLen,
      __out_ecount(DataLen) TR_MEMORY_DATA   Data[],
      __out ULONG                  &DataCount
      ) PURE;

   //
   // Description:
   //  The next four find operations are similar to GetMemoryValue(), except for
   //  that they search for values accessed in a more specific way.  They also
   //  return the value at the first position that hits within the specified
   //  address and range, which may only contain part of the value in the data
   //  range specified in the call.  Use the mask to know which bytes within
   //  the range are valid.

   // Address writes.
   STDMETHOD(FindPrevWrite)(
      __in const TR_ADDRESS        Address,
      __in const ULONG             Range,
      __in_opt TR_DATA_CALLBACK    DataCmpProc,
      __in const ULONG             DataLen,
      __out_ecount(DataLen) TR_MEMORY_DATA   Data[],
      __out ULONG                 &DataCount
   ) PURE;
   STDMETHOD(FindNextWrite)(
      __in const TR_ADDRESS        Address,
      __in const ULONG             Range,
      __in_opt TR_DATA_CALLBACK    DataCmpProc,
      __in const ULONG             DataLen,
      __out_ecount(DataLen) TR_MEMORY_DATA   Data[],
      __out ULONG                 &DataCount
   ) PURE;

   // Address reads
   STDMETHOD(FindPrevRead)(
      __in const TR_ADDRESS        Address,
      __in const ULONG             Range,
      __in_opt TR_DATA_CALLBACK DataCmpProc,
      __in const ULONG             DataLen,
      __out_ecount(DataLen) TR_MEMORY_DATA   Data[],
      __out ULONG              &DataCount
   ) PURE;
   STDMETHOD(FindNextRead)(
      __in const TR_ADDRESS        Address,
      __in const ULONG             Range,
      __in_opt TR_DATA_CALLBACK    DataCmpProc,
      __in const ULONG             DataLen,
      __out_ecount(DataLen) TR_MEMORY_DATA   Data[],
      __out ULONG                 &DataCount
   ) PURE;

   //
   // Description:
   //  The following operation starts up an event enumerator.  The events
   //  that are enumerated are the same set of events that the client
   //  can set an event breakpoint for (see SetEventBreakPoint()).  The events
   //  for all processes are enumerated.
   //
   // Parameters:
   //  EventCallback - The event callback.
   //  UserContext   - Value passed into the callback.
   //
   // Return Value:
   //  The search stops if FALSE is returned or continues if TRUE is returned.
   STDMETHOD(EnumerateEvents)(
      __in TR_EVENT_CALLBACK EventCallback,
      __in PVOID UserContext
   );

   //
   // Description:
   //  Inserts a positional breakpoint at the next instruction to execute, which
   //  effectively stops forward execution at that instruction.  This is called from an
   //  event callback to halt execution.  After this is called the current instruction
   //  is the next instruction to execute.
   //
   // Parameters:
   //
   // Return Value:
   //  TR_ERROR_SUCCESS if it succeeds.
   STDMETHOD(StopExecution)() PURE;

   //
   // INDEXING
   //

   //
   // Description:
   //  To ensure the memory search operations are responsive, the reader only looks back a
   //  limited number of instruction for memory values.  The following operation provides
   //  reader clients with a way to efficiently get all memory values accessed within the
   //  trace file.
   //
   //  This operation crawls through the trace, creating memory snapshots at various points
   //  in time.  After the index is created, the reader uses it to return memory values to
   //  the client that are not within the limited range of the search operations.
   //  TR_MEMORY_DATA positions from values resolved from the index are always 0, and only
   //  a single value is returned based on the sequence execution ordering.
   //
   //  If "commit" is specified, the index is written back into the trace log file, and the
   //  next reader session will use the stored index.
   //
   //  This operation creates the index in the current executing process.
   //
   // Parameters:
   //  commit  - After creating the index, store it away for future reader sessions on
   //            current trace file.  This functionality is disabled if there is more
   //            than one active reader in a single process.
   //  Wait    - If true this operation blocks until the index is created.  If it is
   //            false the indexing is run in a background thread.
   //
   //  LowPri  - If this is true and the indexing is being run in the background,
   //            the thread will run at below normal priority.
   //
   // Return Value:
   //  TR_ERROR_SUCCESS if it finished creating the index.
   //  TR_ERROR_PENDING if it returns before indexing is complete (indexing continues in
   //                   the background).
   //  TR_ERROR_COMMIT_FAILED if it built the index but failed to commit it for another session.
   //  TR_ERROR_FAILURE if it fails to start index creation.
   //  TR_ERROR_OUTOFMEMORY if it fails during a memory allocation.
   STDMETHOD(CreateMemoryIndex)(
      __in const bool Commit,
      __in const bool Wait,
      __in const bool LowPri
   ) PURE;

   //
   // Description:
   //  This operation gets the result of a pending background index.  The user can optionally
   //  specify a period of time to wait for the reader to finish creating the index.
   //
   // Parameters:
   //  Milliseconds - The number of milliseconds to block for the indexing service to complete.
   //                 If INFINITE is specified the time out never elapses.
   //  CurrentSequence - The current sequence being indexed.
   //
   // Return Values:
   //  TR_ERROR_SUCCESS if it successfully created the index.
   //  TR_ERROR_PENDING if it returns before the index is built.
   //  TR_ERROR_COMMIT_FAILED if it built the index but failed to commit it for another session.
   //  TR_ERROR_NO_INDEX if a memory index was never created or committed to this log file.
   //  TR_ERROR_FAILURE or TR_ERROR_OUTOFMEMORY for other types of failure.
   STDMETHOD(GetMemoryIndexResult)(
      __in const DWORD    Milliseconds,
      __out TR_SEQUENCE & CurrentSequence
   ) PURE;

   //
   // Description:
   //  This call queries the index of sample runs for the run numbers of the first and
   //  last runs found in the trace.  This can only be used in single reader single
   //  process scenarios.
   //
   // Parameters:
   //  firstRunNumber - the number of the first sample run found in the trace
   //  lastRunNumber - the number of the last sample run found in the trace
   //
   // Return Values:
   //  TR_ERROR_SUCCESS if the values were found.
   //  TR_ERROR_NO_INDEX if no sample index was created from the log file.
   //  TR_ERROR_FAILURE if no samples were found.
   STDMETHOD(GetSampleRangeFromIndex)(
      __out ULONG & firstRunNumber,
      __out ULONG & lastRunNumber
   ) PURE;

   //
   // Description:
   //  This call queries the index of sample runs for details of a particular run.
   //  This can only be used in single reader single process scenarios.
   //
   // Parameters:
   //  sampleRunNumber - the sample run number to lookup in the index
   //  isValidRun - this run is complete and all sequence numbers are provided
   //    if a run is invalid, then some sequences might be zero or out of order.
   //  firstStartSequence - the sequence number of the first sample start event
   //  lastStartSequence - the sequence number of the last sample start event
   //  firstFinishSequence - the sequence number of the first sample finish event
   //  lastFinishSequence - the sequence number of the last sample finish event
   //
   // Return Values:
   //  TR_ERROR_SUCCESS if the values were found.
   //  TR_ERROR_NO_INDEX if no sample index was created from the log file.
   //  TR_ERROR_FAILURE if the sample run was not found.
   STDMETHOD(GetSampleRunFromIndex)(
      __in const ULONG sampleRunNumber,
      __out bool & isValidRun,
      __out TR_SEQUENCE & firstStartSequence,
      __out TR_SEQUENCE & lastStartSequence,
      __out TR_SEQUENCE & firstFinishSequence,
      __out TR_SEQUENCE & lastFinishSequence
   ) PURE;

   //
   // Description:
   //  Returns the QueryPerformanceFrequence() value from the guest process's
   //  system during record.
   //
   // Parameters:
   //  PerfFreq - The frequency used by the performance counter.
   //
   // Return Values:
   //  TR_ERROR_SUCCESS if the frequency is found.
   //  TR_ERROR_FAILURE if no frequency was recorded.
   STDMETHOD(QueryPerformanceFrequency)(
      __out LARGE_INTEGER & PerfFreq
   ) PURE;

   //
   // Description:
   //  Returns information about how the trace was captured.  See
   //  TR_TRACE_CAPTURE_FLAGS for flags that are set.  The returns
   //  the information for the current process.
   //
   // Parameters:
   //  TraceFlags - Bit mask of TR_TRACE_CAPTURE_FLAGS
   //
   // Return Values:
   //  TR_ERROR_SUCCESS
   STDMETHOD(GetTraceCaptureInfo)(
      __out ULONG & TraceFlags
   ) PURE;

   // Description:
   //  The following operation converts a reader handles to a message.
   //
   // Parameters:
   //  Handle   - The handle.
   //  Message  - The marker string message.
   //
   // Return Values:
   //  If the handle is valid it returns the TR_ERROR_SUCCESS or it returns
   //  TR_ERROR_FAILURE.
   STDMETHOD(ConvertHandleToMarker)(
      __in const TR_MARKER_HANDLE Handle,
      __out WCHAR Message[TR_MAX_MARKER_MESSAGE]
   ) PURE;

   // Description:
   //  The following operation retrieves guest process image bytes from
   //  the trace file.  The parameters to this operation are returned from
   //  TR_MemoryBlock callback.  See TR_MemoryBlock for more details.  This
   //  returns the image bytes from the current process.
   //
   // Parameters:
   //  pos      - The position at which to search for the image bytes.
   //  addr     - Address to start the copy from.
   //  length   - Amount of data to copy.
   //  imageBytes - Passed in buffer to hold the image data.
   //
   // Return Values:
   //  Returns TR_ERROR_SUCCESS if it gets the image bytes.
   //  Return TR_ERROR_ADDR_NOT_FOUND if the data isn't available.
   STDMETHOD(GetImageBytes)(
      __in const TR_POSITION_HANDLE hpos,
      __in const TR_ADDRESS addr,
      __in const ULONG length,
      __out_ecount(length) BYTE imageBytes[]) PURE;

   //
   // Description:
   //  Retrieves the unique trace group identifier.  The group identifier is logged
   //  into the trace file at record time.  If multiple traces have the same group id
   //  than those trace files are synchronized in a way that allows them to be
   //  attached to and replayed in a single reader as one process.
   //
   // Parameters:
   //  id - the unique guid from the currently executing process.
   //
   // Return Value:
   //  This always returns a valid GUID.
   STDMETHOD(GetTraceGroupIdentifier)(
      GUID & id
      ) const PURE;

   //
   // Description:
   //  Retrieves the process handle that owns the thread represented by
   //  the passed in thread handle.
   //
   // Parameters:
   //  thread - thread handle we want the parent process for.
   //  process - the handle of the process owning the thread.
   //
   // Return Value:
   //  Returns TR_ERROR_SUCCESS or TR_ERROR_INVALID_HANDLE.
   STDMETHOD(ConvertThreadToProcess)(
      __in const TR_THREAD_HANDLE thread,
      __out TR_PROCESS_HANDLE & process) const PURE;

   // Description:
   //  The current process is the current process at the currently executing
   //  position.
   //
   // Return Values:
   //  This either returns TR_ERROR_SUCCESS or invalid reader.
   STDMETHOD(GetCurrentProcess)(
      __out TR_PROCESS_HANDLE & process) const PURE;

   // Description:
   //  Each position is tied to a particular process.
   //
   // Return Values:
   //  This either returns TR_ERROR_SUCCESS or TR_ERROR_INVALID_POSITION.
   STDMETHOD(GetProcess)(
      __in const TR_POSITION_HANDLE pos,
      __out TR_PROCESS_HANDLE & process) const PURE;

   //
   // Description:
   //  Returns the first and last sequence number for those
   //  sequences of instructions in the process.
   //
   // Parameters:
   //  process   - The process we want the boundaries for.
   //  FirstSeq  - The first sequence of instructions in the trace.
   //  LastSeq   - The last sequence of instructions in the trace.
   //
   STDMETHOD(GetProcessTraceBoundarySequences)(
      __in  const TR_PROCESS_HANDLE process,
      __out TR_SEQUENCE & FirstSeq,
      __out TR_SEQUENCE & LastSeq) const PURE;

   //
   // Description:
   //  Returns the current position of the process in the trace.
   //
   // Parameters:
   //  process - Position in this process.
   //  Pos    - Returned position.
   //
   // Return Value:
   //  This returns TR_ERROR_FAILURE or TR_ERROR_SUCCESS.
   STDMETHOD(GetProcessCurrentPosition)(
      __in  const TR_PROCESS_HANDLE process,
      __out TR_POSITION_HANDLE & Pos) const PURE;

   // Description:
   //  This operation returns a process handle for each process attached to
   //  the reader.
   //
   // Parameters:
   //  ProcessesLen - The length of Processes[].
   //  Processes - The process handles; there is one unique process handle per process in
   //            in the reader.  If this is NULL and ProcessesLen is 0, it just
   //            returns the ProcessesCount.
   //  ProcessesCount - The number of unique processes in the reader.
   //
   // Return Values:
   //  If the passed in process count is large enough it returns TR_ERROR_SUCCESS,
   //  the processes, and the actual process count.  If Processes[] is not large enough
   //  it returns TR_ERROR_MORE_DATA and returns as many process handles as will fit.
   //  The returned ProcessesCount is the length needed in Processes[].
   STDMETHOD(GetProcesses)(
      __in const ULONG  ProcessesLen,
      __out_ecount_opt(ProcessesLen) TR_PROCESS_HANDLE Processes[],
      __out ULONG      &ProcessesCount
   ) PURE;

   // Description:
   //  This operation returns a thread handle for each thread of execution
   //  in the passed in process.
   //
   // Parameters:
   //  Process - Process to retrieve the threads for.
   //  ThreadsLen - The length of Threads[].
   //  Threads - The thread handles; there is one unique thread handle per thread in
   //            the trace.  If this is NULL and ThreadLen is 0, it just
   //            returns the ThreadCount.
   //  ThreadsCount - The number of unique threads in the trace.
   //
   // Return Values:
   //  If the passed in thread count is large enough it returns TR_ERROR_SUCCESS,
   //  the threads, and the actual thread count.  If Threads[] is not large enough
   //  it returns TR_ERROR_MORE_DATA and returns as many thread handles as will fit.
   //  The returned ThreadCount is the length needed in Threads[].
   STDMETHOD(GetProcessThreads)(
      __in const TR_PROCESS_HANDLE Process,
      __in const ULONG  ThreadsLen,
      __out_ecount_opt(ThreadsLen) TR_THREAD_HANDLE Threads[],
      __out ULONG      &ThreadsCount
   ) PURE;

   //
   // Description:
   //  Returns the name of the trace file associated with the currently executing
   //  process.
   //
   // Parameters:
   //  Process - The trace file name for this process.
   //  file - The trace file name.
   //
   // Return Values:
   //  Returns the name of the trace file this reader is associated with.
   STDMETHOD(GetProcessTraceFileName)(
      __in  const TR_PROCESS_HANDLE Process,
      __out WCHAR file[MAX_PATH]) const PURE;

   //
   // Description:
   //  Retrieves information about the trace file, process, and system
   //  the trace was taken on.  This returns the system information for
   //  the currently executing process.
   //
   // Parameters:
   //  Process - The system information about this process.
   //  sysinfo - holds all the information.
   STDMETHOD(GetProcessTraceSystemInfo)(
      __in  const TR_PROCESS_HANDLE Process,
      __out TR_SYSTEM_INFO & sysinfo) const PURE;

   //
   // Description:
   //  Retrieves the unique identifier for the trace file of the currently
   //  executing process.
   //
   // Parameters:
   //  Process - the unique guid for this process.
   //  id - the unique guid
   STDMETHOD(GetProcessTraceIdentifier)(
      __in  const TR_PROCESS_HANDLE Process,
      __out GUID & id) const PURE;

   //
   // Description:
   //  Returns information about how the trace was captured.  See
   //  TR_TRACE_CAPTURE_FLAGS for flags that are set.  The returns
   //  the information for the current process.
   //
   // Parameters:
   //  Process - The flags for this process.
   //  TraceFlags - Bit mask of TR_TRACE_CAPTURE_FLAGS
   //
   // Return Values:
   //  TR_ERROR_SUCCESS
   STDMETHOD(GetProcessTraceCaptureInfo)(
      __in  const TR_PROCESS_HANDLE Process,
      __out ULONG & TraceFlags
   ) PURE;

   // Description:
   //  The following operation sets the reader to break on certain
   //  events that occur during execution within any process.
   //
   // Parameters:
   //  type - the supported types are TR_ModuleLoad, TR_Exception,
   //         TR_Marker, TR_CreateThread, and TR_DeleteThread.
   //
   // Return Value:
   //  Returns TR_ERROR_SUCCESS if the breakpoint is set in every process
   //  even if it already exists.  It returns TR_ERROR_FAILURE
   //  if an unsupported type is given.
   STDMETHOD(SetGlobalEventBreakPoint)(
      __in  const TR_BREAKPOINT_TYPE type
      ) PURE;

   // Description:
   //  See description of SetExecutionBreakPoint() above.
   STDMETHOD(SetProcessExecutionBreakPoint)(
      __in const TR_PROCESS_HANDLE Process,
      __in const TR_ADDRESS eip,
      __out TR_BREAKPOINT_HANDLE & bp
      ) PURE;

   // Description:
   //  See description of SetMemoryBreakPoint() above.
   STDMETHOD(SetProcessMemoryBreakPoint)(
      __in const TR_PROCESS_HANDLE Process,
      __in const TR_BREAKPOINT_TYPE  type,
      __in const TR_ADDRESS          addr,
      __in const ULONG               range,
      __out TR_BREAKPOINT_HANDLE & bp
      ) PURE;

   // Description:
   //  See description of SetEventBreakPoint() above.
   STDMETHOD(SetProcessEventBreakPoint)(
      __in const TR_PROCESS_HANDLE Process,
      __in const TR_BREAKPOINT_TYPE type,
      __out TR_BREAKPOINT_HANDLE & bp
      ) PURE;

   // Description:
   //  See description of GetExecutionBreakPoint() above.
   STDMETHOD(GetProcessExecutionBreakPoint)(
      __in const TR_PROCESS_HANDLE Process,
      __in const TR_ADDRESS eip,
      __out TR_BREAKPOINT_HANDLE &bp
      ) PURE;

   // Description:
   //  See description of GetMemoryBreakPoint() above.
   STDMETHOD(GetProcessMemoryBreakPoint)(
      __in const TR_PROCESS_HANDLE Process,
      __in const TR_BREAKPOINT_TYPE type,
      __in const TR_ADDRESS         addr,
      __in const ULONG              range,
      __out TR_BREAKPOINT_HANDLE &bp
      ) PURE;

   // Description:
   //  See description of GetEventBreakPoint() above.
   STDMETHOD(GetProcessEventBreakPoint)(
      __in const TR_PROCESS_HANDLE Process,
      __in const TR_BREAKPOINT_TYPE type,
      __out TR_BREAKPOINT_HANDLE &bpHandle
      ) PURE;

   // Description:
   //  See description of GetMemoryValue() above.
   STDMETHOD(GetProcessMemoryValue)(
      __in const TR_PROCESS_HANDLE  Process,
      __in const TR_ADDRESS         Address,
      __in const ULONG              Range,
      __in const ULONG              DataLen,
      __out_ecount(DataLen) TR_MEMORY_DATA   Data[],
      __out ULONG                  &DataCount
      ) PURE;

   //
   // Description:
   //  This utility converts a unique thread handle to a unique index, where all the threads
   //  in all the processes are numbered sequentially from 0 to total number of threads minus
   //  1.
   //
   // Parameters:
   //  Thread - Thread to convert.
   //  Index  - Unique sequential index.
   //
   // Return Values:
   //  TR_ERROR_SUCCESS if it successfully created the index.
   //  It returns a failure code if it cannot convert the thread.
   STDMETHOD(GetUniqueThreadIndex)(
      __in const TR_THREAD_HANDLE  Thread,
      __out ULONG                  &Index
      ) PURE;

   //
   // Description:
   //  Searches for the position where the expression evaluates to true.  The position
   //  returned is not necessarily the exact instruction where the change in state
   //  resulting in the expression evaluating to true occurs.  For example if the change
   //  occurred outside the bounds of the trace, such as in kernel mode in a user mode
   //  trace, the position returned is after the point in execution that the indirect
   //  write happened.  The search will stop when it sees an out of bounds change.
   //
   //  The expression is of the following form with the listed constraints:
   //
   //     * You can only have one $source operator per predicate.
   //     * You can only have one $ip operator per predicate.
   //
   //   search-string := <direction> <predicate>
   //   predicate := ["("] <expression> [ <loper> ["("]<predicate>[")"] ]* [")"]
   //     direction := "[j]+" | "[j]-"   # forwards and backwards, respectively
   //                                    # with optional jump to that position.
   //     loper := "&&" | "||"
   //     expression := <variable> <oper>[(<range|rrange>)] <value> | <special> | <ip>
   //       variable := <register> | <pseudo-register> | <address>
   //         register := @reg            # Ex. rip, eip, eax, etc...
   //         pseudo-register := @gle |   # Resolves to the address of the TEB GetLastError
   //                            @inst    # Resolve to the code bytes of the current instruction
   //                                     # value for every thread.
   //         address := <hex>
   //       value := <decimal> | <hex> | <code-bytes>
   //                                     # All number are read in as 64bit, except code bytes
   //                                     # and registers > 8 bytes.
   //                                     # Hex numbers are assumed unsigned and decimals
   //                                     # are signed.
   //         hex := 0xNNNNNNNNNNNNNNNN |
   //                NNNNNNNN`NNNNNNNN    # DWORD pair
   //                NNNNNNNNNNNNNNNN`NNNNNNNNNNNNNNNN # QWORD pair for numbers > 8 bytes
   //         decimal := [-]N | 0nN
   //         code-bytes := <xx>          # Up to <rrange> number of hex pairs (i.e. 6a0c for push 0c)
   //       oper  := "==" | "!=" | ">" | "<" | ">=" | "<="
   //       special := "$modify"[<range>](<variable>) | # Range ignored for registers
   //                  "$source"[<range>](<variable>) |
   //                  "$write"[<range>](<address> | @gle | <\"value\">)
   //                  "$read"[<range>](<address> | @gle | <\"value\">)
   //       ip := "$ip"[(<address>)]  # If the address is left off it uses the current ip.
   //         range := "1" | "2" | "4" | "8"   # Optional range defaults to 4
   //                                          # Variable is an address
   //         trange := "1" >= <rrange> <= "16" # Optional range defaults to the register size
   //                                           # @inst default size is 1 byte
   //                                           # Variable is a register
   //
   //  Examples:
   //   "+ MyVar >= 3"
   //      Searches for when the value of the address of MyVar is >= 3.
   //   "+ poi(MyVar) ==(2) 0x5"
   //      Searches for when the 2 bytes at the dereferenced address of MyVar equals 0x5.
   //   "- (@eax != 0x3) && (@esp < 0x325ab32a)"
   //      Searches for when the values of eax and esp meet the condition.  For 64bit use
   //      @rsp and @rax.
   //   "+ @gle != 0"
   //      Searches for when the last error value does not equal 0.
   //   "- $modify4(MyVar)"
   //      Searches for when value of MyVar was modified via a direct or indirect
   //      write (4 byte range).
   //   "- $write4(MyVar)"
   //      Searches for the previous direct write to MyVar.
   //   "- $source4(MyVar)"
   //      Searches for the source of the value of MyVar (4 byte range).
   //         mov MyVar eax <--- @eax == 0 This is the $modify
   //         mov MyVar ecx <--- @ecx == 3 This is the $source
   //         push MyVar <--- MyVar == 3
   //      If the value of MyVar is modified indirectly, the position returned
   //      is at the first traced instruction after the change.  This behavior
   //      is similar to $modify.
   //   "j+ ($ip(mydll!MyFunc)) && (@eax == 3)"
   //      Searches for when the execution breakpoint hits mydll!MyFunc and eax equals 3
   //      and jumps to that position when the condition is met.
   //   "j+ @inst ==(1) 0xc2"
   //      Searches for the next near RET instruction.
   //
   // Parameters:
   //  Process - Process is set the breakpoint in.
   //  SearchString - The search-string expression.
   //  Pos - Position where expression evaluates to true.
   //
   // Return Values:
   //  TR_ERROR_SUCCESS if it finds a position where the expression evaluates to
   //  true.
   // TR_ERROR_ADDR_NOT_FOUND if it does not find a position.
   // These next error codes return a FormatErrorIndex.
   //  TR_ERROR_BAD_INPUT if the expression format is bad.
   //  TR_ERROR_NOT_IMPLEMENTED if the legal expression contains a not-yet-implemented feature.
   //  TR_ERROR_NO_VALUE if $modify is used and it cannot evaluate the variable to the
   //  current value.
   STDMETHOD(Search)(
      __in const TR_PROCESS_HANDLE  Process,
      __in const PWCHAR SearchString,
      __out ULONG & FormatErrorIndex,
      __out TR_POSITION_HANDLE & Pos
      ) PURE;

   // Description:
   //  The following operation converts an ETW event handle to an ETW
   //  event record.  See comments above TR_ETW_EVENT for more information.
   //
   // Parameters:
   //  Handle   - The handle.
   //  EtwEvent - The converted type.
   //
   // Return Values:
   //  If the handle is valid it returns the TR_ERROR_SUCCESS or it returns
   //  TR_ERROR_FAILURE.
   STDMETHOD(ConvertHandleToEtwEvent)(
      __in const TR_ETW_EVENT_HANDLE Handle,
      __out TR_ETW_EVENT & EtwEvent
   ) PURE;

   // Description:
   //  Finds the closest position at the passed in timestamp (system time)
   //  on the specified thread.  If the timestamp does
   //  not exactly match a timed event, it returns the closest timed event
   //  before the passed in time.  If more than one event has the same time
   //  stamp, it uses the optional opcode and level arguments to break the
   //  tie.
   //
   //  NOTE: Use this to search for logged ETW events.
   //
   //  No callbacks are called or breakpoints hit when this operation is used.
   //
   // Parameters:
   //  ProcessId - Process to search for the timestamp in.
   //  ThreadId - Thread in the search process.
   //  Opcode - ETW event opcode.  Use (ULONG)-1 to ignore.
   //  Level - ETW event level.  Use (ULONG)-1 to ignore.
   //  TimeStamp - The system time time stamp.
   //  Pos - The position of the timed event.
   //
   // Return Values:
   //  TR_ERROR_SUCCESS if it finds the position.
   //  TR_ERROR_INVALID_POSITION if no event matches the timestamp.
   STDMETHOD(FindTimedEvent)(
      __in const ULONG         ProcessId,
      __in const ULONG         ThreadId,
      __in const ULONG         Opcode,
      __in const ULONG         Level,
      __in const LARGE_INTEGER TimeStamp,
      __out TR_POSITION_HANDLE & Pos
      ) PURE;


   // Description:
   //  Create a command tree in a file that windbg can use to nativigate
   //  through from the current activity to other correlated activities.
   //
   // Parameters:
   //  ActivityGuid - The guid of the activity to build the tree around.
   //                 It uses the activity at the current position if this
   //                 is NULL.  If the value is set to L"all" it dumps the
   //                 whole activity tree.
   //  TreePath - Path to the command file if the operation succeeds.
   //
   // Return Values:
   //  TR_ERROR_SUCCESS if it builds the command tree.
   //  TR_ERROR_INVALID_POSITION if the activity is bad or the position is not within
   //  an activity.
   //  TR_ERROR_FAILURE for all other failures.
   STDMETHOD(CreateActivityCommandTree)(
      __in_opt PWCHAR ActivityGuid,
      __out    WCHAR TreePath[MAX_PATH]
      ) PURE;

};


#undef INTERFACE
#define INTERFACE ITREADER2
DECLARE_INTERFACE_(ITREADER2, ITREADER)
{
    // Description:
    //  Copies the metrics info to the struct specified by the caller
    //
    // Parameters:
    //  pMetricsInfo - A pointer to the TR_METRICS_INFO structure.
    //                 It copies the contents of TR_METRICS_INFO struct
    //                 to the caller-supplied destination.
    //
    // Return Values:
    //  TR_ERROR_SUCCESS.
    STDMETHOD(GetMetricsInfo)(
        __out TR_METRICS_INFO * pMetricsInfo
    ) PURE;

    // Description:
    //  Copies the trace file version info to the struct specified by the caller
    //
    // Parameters:
    //  pVersionInfo - A pointer to the TR_VERSION_INFO structure.
    //                 It copies the contents of TR_VERSION_INFO struct
    //                 to the caller-supplied destination.
    //
    // Return Values:
    //  TR_ERROR_SUCCESS.
    STDMETHOD(GetTraceVersionInfo)(
        __out  TR_VERSION_INFO * pVersionInfo
    ) PURE;

    // Description:
    //  Copies the reader version info to the struct specified by the caller
    //
    // Parameters:
    //  pVersionInfo - A pointer to the TR_VERSION_INFO structure.
    //                 It copies the contents of TR_VERSION_INFO struct
    //                 to the caller-supplied destination.
    //
    // Return Values:
    //  TR_ERROR_SUCCESS.
    STDMETHOD(GetReaderVersionInfo)(
        __out  TR_VERSION_INFO * pVersionInfo
    ) PURE;

};


#undef INTERFACE
#define INTERFACE ITREADER3
DECLARE_INTERFACE_(ITREADER3, IUnknown)
{
    // Description:
    //  Obtains the current program counter stored in the replay engine's guest register context for a thread
    //
    // Parameters:
    //  pProgramCounter - On exit contains the returned program counter value.
    //
    // Return Values:
    //  TR_ERROR_SUCCESS, TR_ERROR_INVALID_HANDLE.
    STDMETHOD(GetProgramCounter)(
        _In_  TR_THREAD_HANDLE hthread,
        _Out_ TR_ADDRESS*      pProgramCounter
    ) PURE;

    // Description:
    //  Obtains the current stack pointer stored in the replay engine's guest register context for a thread
    //
    // Parameters:
    //  pStackPointer - On exit contains the returned stack pointer value.
    //
    // Return Values:
    //  TR_ERROR_SUCCESS, TR_ERROR_INVALID_HANDLE.
    STDMETHOD(GetStackPointer)(
        _In_  TR_THREAD_HANDLE hthread,
        _Out_ TR_ADDRESS*      pStackPointer
    ) PURE;

    // Description:
    //  Obtains the guest address of the TEB for a thread
    //
    // Parameters:
    //  pTebAddress - On exit contains the returned TEB guest address.
    //
    // Return Values:
    //  TR_ERROR_SUCCESS, TR_ERROR_INVALID_HANDLE.
    STDMETHOD(GetTebAddress)(
        _In_  TR_THREAD_HANDLE hthread,
        _Out_ TR_ADDRESS*      pTebAddress
    ) PURE;

    // Description:
    //  Obtains a full copy of the replay engine's current guest register context for a thread
    //
    // Notes:
    //  CROSS_PLATFORM_CONTEXT and AVX_EXTENDED_CONTEXT are platform-defined,
    //  and can be found in the Windows SDK in windbg.h.
    //
    // Parameters:
    //  pContext    - On exit contains the main part of the context.
    //  pAvxContext - On exit contains the extra data of the context (high part of the YMM registers)
    //                if applicable. Filled with zeros if not applicable.
    //
    // Return Values:
    //  TR_ERROR_SUCCESS, TR_ERROR_INVALID_HANDLE.
    STDMETHOD(GetRegisterContext)(
        _In_      TR_THREAD_HANDLE        hthread,
        _Out_     CROSS_PLATFORM_CONTEXT* pContext,
        _Out_opt_ AVX_EXTENDED_CONTEXT*   pAvxContext
    ) PURE;
};



///////////////////////////////////////////////////////////////////
//
// The ITREADER_GROUP interface
//

// The following API creates an ITREADER_GROUP interface.
// In addition to the defined API return values, all the API's return TR_ERROR_INVALID_READER if
// an internal error in the group reader has occurred.  In this case the reader is in an irrecoverable
// state.  The group reader can only be used to ExecuteForward() from the start of the trace.
extern "C" ITREADER_GROUP* __cdecl CreateITReaderGroup();

// Reads the trace guid tag from the given trace file.
// May be used to determine the architecture of the trace prior to opening the trace.
extern "C" HRESULT __cdecl GetTraceGUIDTag(
    _In_z_ LPCWSTR pwcszFileName,
    _Out_ GUID * pGUID
    );

#undef INTERFACE
#define INTERFACE ITREADER_GROUP
DECLARE_INTERFACE_(ITREADER_GROUP, IUnknown)
{
   // IUnknown.
   STDMETHOD(QueryInterface)(
       __in REFIID InterfaceId,
       __out PVOID* Interface
       ) PURE;

   STDMETHOD_(ULONG, AddRef)() PURE;
   STDMETHOD_(ULONG, Release)() PURE;

   //
   // Description:
   //  Add a trace file to the group reader.  All trace files must be from the same
   //  group, and all trace files must be added before execution begins.
   //
   //  You can use the reader returned to set callbacks and breakpoints.  Note that
   //  the registered callbacks cannot be modified after PrepareForExecution() has
   //  been called.
   //
   // Parameters:
   //  TraceFile - NULL terminated file name of trace of a program's execution.
   //  reader    - The reader added to the group.
   //
   // Return Value:
   //  See TREADER::AttachTraceFile for full list of return values.
   //  TR_ERROR_NOT_IN_GROUP - The trace file is not within the same group as the previous
   //  trace files added to the group.
   //  TR_ERROR_TOO_MANY_READERS - You tried to add a trace file after already starting
   //  execution.
   STDMETHOD(AddTraceFile)(
       __in const PWCHAR TraceFile,
       __out PITREADER & reader
       ) PURE;


   // Description:
   //  This operation returns an array containing all the readers in the group.
   //
   // Parameters:
   //  ReadersLen - The length of Readers[].
   //  Readers - The readers.  If this is NULL then ReadersLen is ignored, and it
   //            returns the ReadersCount.
   //  ReadersCount - The number of readers in the group; this can be more than
   //                 ReadersLen.
   //
   // Return Values:
   //  If the passed in reader count is large enough it returns TR_ERROR_SUCCESS,
   //  the readers, and the actual reader count.  If Readers[] is not large enough
   //  it returns TR_ERROR_MORE_DATA and returns as many readers as will fit.
   //  The returned ReaderCount is the length needed in Readers[].
   STDMETHOD(GetReaders)(
      __in const ULONG  ReadersLen,
      __out_ecount_opt(ReadersLen) PITREADER Readers[],
      __out ULONG      &ReadersCount
   ) PURE;

   //
   // Description:
   //  The following operation compares how two positions relate in terms of execution time
   //  to each other in a trace.  This operation is similar to the ITREADER version, except
   //  that it works cross process.
   //  To determine if two positions are the same instruction, the position thread and
   //  instruction count must be equal.
   //
   // Parameters:
   //  pos1    - position that is being compared.
   //  pos2    - position that is being compared.
   //
   // Return Value:
   //  On a single thread the results of these operations are simply based on the relative
   //  order of the instructions these position represent.  When comparing positions across
   //  two threads, it may only be possible to know the relative order of a range of instructions
   //  in each thread.  If the range of instructions the two positions are in fall into the same
   //  sequence, those two positions are considered equal.
   //  If pos1 > pos2 it returns > 0
   //  If pos1 < pos2 it returns < 0
   //  If pos1 = pos2 it returns 0
   //
   // If the positions are invalid this throws and exception.
   STDMETHOD_(LONG, ComparePositions)(
      __in const TR_POSITION_HANDLE pos1,
      __in const TR_POSITION_HANDLE pos2) const PURE;

   //
   // Description:
   //  This must be called before the first call to ExecuteForward() and after all
   //  the trace files are added to the group.  You can also call this at anytime
   //  during execution to reset the group state back to the first instruction to
   //  execute.
   //
   // Parameters:
   //  reader - The reader containing the first sequence of instruction to execute.
   //
   // Return Value:
   //  TR_ERROR_SUCCESS if it succeeds.
   //  TR_ERROR_INVALID_READER if there are no readers in the group.
   STDMETHOD(PrepareForExecution)(
       __out PITREADER & reader
       ) PURE;

   //
   // Description:
   //  Returns the current reader in execution.
   //
   // Parameters:
   //  reader - The reader the is going to execute the next instruction.
   //
   // Return Value:
   //  TR_ERROR_SUCCESS if it succeeds.
   //  TR_ERROR_ENDOFTRACE if there is no reader because execution has finished.
   //  TR_ERROR_INVALID_READER if called in error.
   STDMETHOD(GetCurrentReader)(
       __out PITREADER & reader
       ) PURE;

   //
   // Description:
   //  The group reader's execute forward operation is similar to a reader's execute
   //  forward operation in that it executes forward from the current position to
   //  the next breakpoint, the end of the trace, or the specified number of steps.
   //  The difference is that it uses multiple readers in its execution.  The first
   //  sequence it executes is the sequence of instructions with the lowest sequence
   //  number among all the added trace files.  It gets to the end of the trace when
   //  it has finished executing through all the sequences of all the added trace
   //  files.
   //
   //  In addition it stops execution when it the next instruction to execute
   //  is in a different reader that the last sequence of instructions it was
   //  executing.  In this case it returns the reader owning that next sequence
   //  of instructions to execute.  The caller can then continue execution by
   //  re-calling ExecuteForward.
   //
   //  See ITREADER::ExecuteForward for a more details on forward execution.
   //
   // Parameters:
   //  step        - Number of instructions to execute.  If this is zero it executes to
   //                the next breakpoint.
   //  bphit       - If non-NULL this returns a pointer to the breakpoint from the
   //                breakpoint array that is hit.
   //  reader      - The reader containing the next sequence of instructions to execute.
   //                This reader is released when this ITREADER_GROUP object is release.
   //                Undefined behavior will result if you release a reader returned
   //                by this operation.
   //
   // Return Value:
   //  TR_ERROR_SUCCESS if it executes the number of steps given or returning with the
   //  first reader.
   //  TR_ERROR_BREAKPOINT_HIT if execution stops at a breakpoint.
   //  TR_ERROR_ENDOFTRACE if it executes to the end of the group of traces.
   //  TR_ERROR_SEQUENCE_END if it runs through to the next sequence.
   STDMETHOD(ExecuteForward)(
      __in  const ULONGLONG        step,
      __out TR_BREAKPOINT        & bphit,
      __out PITREADER & reader) PURE;

   //
   // Description:
   //  Returns the first and last sequence number for those
   //  sequences of instructions in the group of traces.
   //
   // Parameters:
   //  FirstSeq  - The first sequence of instructions in the group.
   //  LastSeq   - The last sequence of instructions in the group.
   //
   STDMETHOD(GetGroupBoundarySequences)(
      __out TR_SEQUENCE & FirstSeq,
      __out TR_SEQUENCE & LastSeq) const PURE;

   //
   // Description:
   //  Retrieves the unique group identifier for the trace file.  A trace file
   //  has a group identifier if it has the TR_CaptureGrouped property.
   //
   //  NOTE: This is a utility that can be used on any ITREADER instance.
   //
   // Parameters:
   //  id - the group guid
   //
   // Return Values:
   //  Returns TR_ERROR_SUCCESS if the trace has a group ID.
   //  Returns TR_ERROR_NOT_IN_GROUP if the trace does not have a group ID.
   STDMETHOD(GetTraceGroupIdentifier)(
      __in const PITREADER reader,
      __out GUID & id) const PURE;

};

// iDNAFileOpen.lib public interface.

// Describes a supported version of iDNA.
enum class CpuArchitecture : uint16_t { Invalid, x86, x64, Arm32, Arm64 };
struct IdnaVersion
{
    uint16_t        Generation; // iDNA v1 vs. iDNA v2
    uint16_t        Major;
    uint16_t        Minor;
    CpuArchitecture Cpu;
};

// Description:
//  Returns the base path (TTT, TTT\v2.00, etc...) for a particular version of iDNA.
//
// Parameters:
//  [in]  version:      iDNA version as inferred from the file.
wchar_t const* GetIdnaBasePath(_In_ IdnaVersion const& version);

// Description:
//  Parses the data at the beginning of an iDNA file and identifies the version.
//
//
enum class IdentifyStatus : uint8_t { NotRecognized, NeedMoreBytes, Recognized };
struct IdentifyResult
{
    IdentifyStatus Status       ;
    IdnaVersion    FileVersion  ; // Valid if Status is Recognized
    bool           KernelMode   ; // Valid if Status is Recognized
    uint64_t       RequestedSize; // Valid if Status is NeedMoreBytes
};
IdentifyResult IdentifyIdnaVersionFromFile(
    _In_reads_bytes_(headerSizeInBytes) void const* pHeader,
    _In_                                uint64_t    headerSizeInBytes
);

// Description:
//  Find a module (DLL) belonging to a particular version of iDNA.
//
// Parameters:
//  [in]  version:      iDNA version as inferred from the file.
//  [in]  pRootPath:    Path to the root of the prograsm using iDNA. For instance, c:\debugers.
//  [in]  pModuleName:  Name of the DLL to find. For instance, idna.dll.
//  [out] pModPath:     Fully qualified path of the module for the given version of iDNA.
//  [in]  modPathChars: Capacity of the buffer pointed-to by pModPath, in characters.
//
// Returns:
//  Return S_OK if function succeeds.
HRESULT
GetIDNAModulePath(
    _In_                         IdnaVersion const& version,
    _In_z_                       wchar_t const*     pRootPath,
    _In_z_                       wchar_t const*     pModuleName,
    _Out_writes_z_(modPathChars) wchar_t*           pModPath,
    _In_                         size_t             modPathChars
);

// Description:
//  Dynamically loads iDNA's reader DLL, and allocates a new instance of ITReader object.
//
// Parameters:
//  [in]  version:      iDNA version as inferred from the file.
//  [in]  pRootPath:    Path to the root of the prograsm using iDNA. For instance, c:\debugers.
enum class IdnaReaderStatus { Success, InvalidVersion, InvalidCpu, FailedToLoad };
struct IdnaReaderResult
{
    ITREADER*        pReader;
    IdnaReaderStatus Status;
};
IdnaReaderResult CreateIDNAReader(
    _In_   IdnaVersion const& version,
    _In_z_ wchar_t const*     pRootPath
);

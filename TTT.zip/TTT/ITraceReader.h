//-----------------------------------------------------------------------------
//
// Time Travel Tracing (TTT) Reader Interface
// Copyright (C) Microsoft Corporation.  All Rights Reserved.
//
// Module name:
//
//    ITraceReader.h
//
// Description:
//
// The TTT TREADER is the interface between the stored execution of an
// application (the trace) and the clients seeking information from the stored
// trace.  A client can open as many readers as it wants within one process.
//
// The reader API's do not support concurrent operation (i.e. two threads
// simultaneously calling on the same or two different API's).
//
//-----------------------------------------------------------------------------

#ifndef ITRACEREADER
#define ITRACEREADER

#pragma once

#define NOMINMAX

#include <ole2.h>

#include <windows.h>
#include "evntprov.h"

// allow unnamed structs and unions
#pragma warning(push)
#pragma warning (disable:4201)

#if !defined(_IMAGEHLP_) && !defined(_DBGHELP_)
#define DBGHELP_TRANSLATE_TCHAR
   #include <dbghelp.h>
#endif

#include "x86state.h"
#include "x64state.h"
#include "registers_a32.h"
#include "registers_x86.h"
#include "registers_x64.h"
#include "metrics.h"

#include "ITraceReaderShared.h"
#include <iDNAOldFileHeader.h>

//
// Constants
//

// TODO: Issue callbacks for each load/st exclusive instruction so we can lower this to something reasonable
#define TR_MAX_INSTRUCTION_LEN      TR_MAX_INSTRUCTION_LEN_V2

union TR_REGISTER_STATE
{
   Nirvana::EmulatorRegisters State; // Unified V2 state
};

#pragma warning(pop)

#endif // ITRACEREADER

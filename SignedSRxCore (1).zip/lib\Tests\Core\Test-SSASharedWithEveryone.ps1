<#
.SYNOPSIS 
	Check if the search index contains content shared with Everyone
	
.DESCRIPTION 
	description
		
.NOTES
	=========================================
	Project		: Search Health Reports (SRx)
	-----------------------------------------
	File Name 	: Test-SSASharedWithEveryone.ps1

	Requires	: 
		PowerShell Version 3.0, Search Health Reports (SRx), Microsoft.SharePoint.PowerShell, 
        Patterns and Practices v15 PowerShell

	========================================================================================
	This Sample Code is provided for the purpose of illustration only and is not intended to 
	be used in a production environment.  
	
		THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY
		OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

	We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to 
	reproduce and distribute the object code form of the Sample Code, provided that You agree:
		(i) to not use Our name, logo, or trademarks to market Your software product in 
			which the Sample Code is embedded; 
		(ii) to include a valid copyright notice on Your software product in which the 
			 Sample Code is embedded; 
		and 
		(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against
              any claims or lawsuits, including attorneys' fees, that arise or result from 
			  the use or distribution of the Sample Code.

	========================================================================================
	
.INPUTS
    input1

.EXAMPLE
	Test-SSASharedWithEveryone

#>

function Init
{
    if (!([System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")))
    {
        Write-Error "No SharePoint CSOM libraries (Client) could be located. Does this machine have them installed?"
        return $false
    }
    if (!([System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")))
    {
        Write-Error "No SharePoint CSOM libraries (Runtime) could be located. Does this machine have them installed?"
        return $false
    }
    if (!([System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Search"))) {
        Write-Error "No SharePoint CSOM libraries (Search) could be located. Does this machine have them installed?"
        return $false
    }

    return $true
}

# make sure the the $xSSA has been instantiated
if(-not $xSSA._hasSRx) {
    throw [System.NullReferenceException] "This test requires a valid `$xSSA"
}

$ruleObject = New-Object PSObject
$ruleObject | Add-Member Name "Test-SSASharedWithEveryone"  
$ruleObject | Add-Member ExpectedValue 0 
$ruleObject | Add-Member Category @("query")

$details = $(New-Object System.Collections.ArrayList)

# This test can only be performed if a Search Center URL has been configured
if (!$xSSA.SearchCenterUrl) { 
    $ruleObject | Add-Member ActualValue 0
    $ruleObject | Add-Member Success $false
    $ruleObject | Add-Member Message $(@{
				    level = "Error";
				    headline = "Search Center URL is not configured for the SSA";
                    details = $null;
                    data = $null;
			    })
} 
else
{
    # We need to query the SSA
    if (!(Init))
    {
        return
    }
    $ruleObject | Add-Member ActualValue $(
        # trim /Ppages, some environments have lower case 'p', trim will work for both '/Pages' and '/pages'
        $queryRoot = $xSSA.SearchCenterUrl.TrimEnd("/Ppages")
        if ($xSSA.CloudIndex) {
            $querytext = "docacl:wb103o20onswg4lsnf1hs4dpnnsw332foj2gsy2forzhkzi"
            $storedCredentials =  Get-StoredCredential -Target $xSSA.SearchCenterUrl
            if (!$storedCredentials) {
                if ([Environment]::UserInteractive) {
                    Write-SRx WARNING "Please enter SPO Admin credentials for the SharePoint Online search center URL."
                    Write-SRx INFO "To avoid this in the future, add SPO Admin credentials for $($xSSA.SearchCenterUrl) to the Windows Credential Manager."
                    $storedCredentials = Get-Credential -Message "SPO Admin Credentials for $($xSSA.SearchCenterUrl)"
                }
                else {
                    $message = "Please add valid credentials for the Target $($xSSA.SearchCenterUrl) to the Windows Credential Manager."
                    $details += $message
                    Write-SRx VERBOSE $message
                   @{ 
				        level = "Error";
				        headline = "No valid credentials found for $($xSSA.SearchCenterUrl).";
                        details = $details;
                        data = $data;
			        } 
                }
            }
            $clientContext = New-Object Microsoft.SharePoint.Client.ClientContext($queryRoot)
            $clientContext.Credentials =  New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($storedCredentials.UserName, $storedCredentials.Password) 
            $keywordQuery = New-Object Microsoft.SharePoint.Client.Search.Query.KeywordQuery($clientContext) 
            $keywordQuery.QueryText = $queryText
            $keywordQuery.TrimDuplicates = $false
            $keywordQuery.RowLimit = 1
            $keywordQuery.ClientType = "'CSOM'"
            $searchExecutor = New-Object Microsoft.SharePoint.Client.Search.Query.SearchExecutor($clientContext) 
            $queryURL = New-Object System.Uri($queryRoot + "/_api/search/query?querytext=$querytext&trimduplicates=false&rowlimit=1&clienttype='CSOM'")
            Write-SRx VERBOSE "Sending REST request: $($queryURL.AbsoluteUri)" 
            $result = $searchExecutor.ExecuteQuery($keywordQuery)
            $clientContext.ExecuteQuery()
            $totalRows = $result.Value.TotalRows
        }
        else {
            $querytext = "'docacl:waeaqaaaaaaaacaaaaaaa'"
            [System.Net.ICredentials] $Credentials = [System.Net.CredentialCache]::DefaultNetworkCredentials
            $queryURL = New-Object System.Uri($queryRoot + "/_api/search/query?querytext=$querytext&trimduplicates=false&rowlimit=1&clienttype='CSOM'")
            Write-SRx VERBOSE "Sending REST request: $($queryURL.AbsoluteUri)"
            $req = [System.Net.HttpWebRequest]::Create($queryURL.AbsoluteUri)
            #$req.Method = "POST"
            #$req.Headers.Add("X-HTTP-Method","POST")
            #$req.Accept = "application/json;odata=verbose;charset=utf-8"
            $req.ContentLength = 0
            $req.Credentials = $Credentials
            #$req.Headers.Add("X-FORMS_BASED_AUTH_ACCEPTED", "f")
            $res = $req.GetResponse()
            $stream = $res.GetResponseStream()
            $reader = New-Object System.IO.StreamReader $stream
            [xml] $result = $reader.ReadToEnd()
            $reader.Close()
            $stream.Close()
            $res.Close()
            $reader.Dispose()
            $stream.Dispose()
            $res.Dispose()
	        $totalrows = $result.query.PrimaryQueryResult.RelevantResults.TotalRows.InnerText
        }
        $totalRowsInt = [convert]::ToInt32($totalrows,10)
        $totalRowsInt
    )
    Write-SRx VERBOSE "Found $($ruleObject.ActualValue) search results"
    $ruleObject | Add-Member Success $($ruleObject.ActualValue -le $ruleObject.ExpectedValue)
    $ruleObject | Add-Member Message $(
        if($ruleObject.Success){ 
            @{ 
				    level = "Normal";
				    headline = "'" + $xSSA.Name + "' has no indexed content that is shared with Everyone";
                    data = $data;
			    } 
        } else { 
            @{
				    level = "Info";
				    headline = "'" + $xSSA.Name + "' has $($ruleObject.ActualValue) indexed items that are shared with Everyone";
	         } 
        } 
    ) 

}

#And then just return the object as the last step…
$ruleObject
# SIG # Begin signature block
# MIIjxwYJKoZIhvcNAQcCoIIjuDCCI7QCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB78eQGIM9n9RiJ
# +2FPBrmPnUqbRPoETdAbTt9rDng22qCCDYEwggX/MIID56ADAgECAhMzAAABh3IX
# chVZQMcJAAAAAAGHMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAwMzA0MTgzOTQ3WhcNMjEwMzAzMTgzOTQ3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOt8kLc7P3T7MKIhouYHewMFmnq8Ayu7FOhZCQabVwBp2VS4WyB2Qe4TQBT8aB
# znANDEPjHKNdPT8Xz5cNali6XHefS8i/WXtF0vSsP8NEv6mBHuA2p1fw2wB/F0dH
# sJ3GfZ5c0sPJjklsiYqPw59xJ54kM91IOgiO2OUzjNAljPibjCWfH7UzQ1TPHc4d
# weils8GEIrbBRb7IWwiObL12jWT4Yh71NQgvJ9Fn6+UhD9x2uk3dLj84vwt1NuFQ
# itKJxIV0fVsRNR3abQVOLqpDugbr0SzNL6o8xzOHL5OXiGGwg6ekiXA1/2XXY7yV
# Fc39tledDtZjSjNbex1zzwSXAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhov4ZyO96axkJdMjpzu2zVXOJcsw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU4Mzg1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAixmy
# S6E6vprWD9KFNIB9G5zyMuIjZAOuUJ1EK/Vlg6Fb3ZHXjjUwATKIcXbFuFC6Wr4K
# NrU4DY/sBVqmab5AC/je3bpUpjtxpEyqUqtPc30wEg/rO9vmKmqKoLPT37svc2NV
# BmGNl+85qO4fV/w7Cx7J0Bbqk19KcRNdjt6eKoTnTPHBHlVHQIHZpMxacbFOAkJr
# qAVkYZdz7ikNXTxV+GRb36tC4ByMNxE2DF7vFdvaiZP0CVZ5ByJ2gAhXMdK9+usx
# zVk913qKde1OAuWdv+rndqkAIm8fUlRnr4saSCg7cIbUwCCf116wUJ7EuJDg0vHe
# yhnCeHnBbyH3RZkHEi2ofmfgnFISJZDdMAeVZGVOh20Jp50XBzqokpPzeZ6zc1/g
# yILNyiVgE+RPkjnUQshd1f1PMgn3tns2Cz7bJiVUaqEO3n9qRFgy5JuLae6UweGf
# AeOo3dgLZxikKzYs3hDMaEtJq8IP71cX7QXe6lnMmXU/Hdfz2p897Zd+kU+vZvKI
# 3cwLfuVQgK2RZ2z+Kc3K3dRPz2rXycK5XCuRZmvGab/WbrZiC7wJQapgBodltMI5
# GMdFrBg9IeF7/rP4EqVQXeKtevTlZXjpuNhhjuR+2DMt/dWufjXpiW91bo3aH6Ea
# jOALXmoxgltCp1K7hrS6gmsvj94cLRf50QQ4U8Qwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVnDCCFZgCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAYdyF3IVWUDHCQAAAAABhzAN
# BglghkgBZQMEAgEFAKCB7zAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgkR6B4Znt
# 2DBGxmfjixg73LKZfJ5RUsUE1PmQbmqJLzswgYIGCisGAQQBgjcCAQwxdDByoFaA
# VABTAGgAYQByAGUAUABvAGkAbgB0ACAAUwBlAGEAcgBjAGgAIABIAGUAYQBsAHQA
# aAAgAFIAZQBwAG8AcgB0AHMAIABEAGEAcwBoAGIAbwBhAHIAZKEYgBZodHRwczov
# L21pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEBAQUABIIBAJ1Y2PaOFjhRtL8ViTdj
# WemZYxCnHmL5HkxMmoKE8q35On4WFvduIpZY7XsC6eOL9xNPrfHgbyS0X8LKb+Kl
# OOBF675BzR16ylGi5+ck+eSy88QPZSkzUs3mm5EkAuT3R8VRYi8CEUsTzJsr+oYU
# 7PdFHGyEltK03yAg9d5CddTTkdsqAkn30U4y1enodY9lH87k1TKIb7ENB/mtyjt7
# 4uVJs4bJ0MzynsUAY0quuK/PRGmo3XRMtuv22syYZ9Cq+yibVnxkekycXIDhQse+
# xzYg81orM/MD1jZHzLuFPCBIqszUHeb14pZeyr4gV6yJp665zcfMlu0vArASHN7x
# Bd6hghLlMIIS4QYKKwYBBAGCNwMDATGCEtEwghLNBgkqhkiG9w0BBwKgghK+MIIS
# ugIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYLKoZIhvcNAQkQAQSgggFABIIBPDCC
# ATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQg4FcbfbptMZdu2uBS
# T9Wmthmx3p0yeakvo2JCDk0ujuACBl9FMxdlsRgTMjAyMDA5MjIxMzU0MTguMjI0
# WjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTAr
# BgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQG
# A1UECxMdVGhhbGVzIFRTUyBFU046RTA0MS00QkVFLUZBN0UxJTAjBgNVBAMTHE1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2Wggg48MIIE8TCCA9mgAwIBAgITMwAA
# AQd+N2iYh1o31gAAAAABBzANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDAeFw0xOTEwMDgxNzM4MzVaFw0yMTAxMDMxNzM4MzVaMIHK
# MQswCQYDVQQGEwJVUzELMAkGA1UECBMCV0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0
# IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjpFMDQxLTRCRUUtRkE3RTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgc2VydmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANS6o5SV
# tp5aKuDBsLCGE0g6pOyGmj5B1JjEC30meR66VAV4qtDqs5IQJfHCA6Mv9M0whe2S
# KDUxqJ8U43qyL9GL4CxXwa6tCnh/KUnMsMwV0lwZKlXcIZF2kNvRq7yQ1Auadm7E
# vEAv3VHv//eYfZANAjbTDcbTqz5e/z6Oz3BCSxcB9yVdfVMmgEjHU+LUUaoKdjcq
# VbzX4+WHPRPjJK2bUyCeofhEpjI91x6akJgL8EjTg+HYQkv65BB8B9h1t/28aqkp
# iOy6S2davm6jAPcfkC37HeVgfmvPgkKV4qN4ukH+PvgftVnQjl5MRuWz17aUQppT
# Nv2jTCOeMNz63gECAwEAAaOCARswggEXMB0GA1UdDgQWBBQ04eOXGUglcxw/2f/S
# iBh1fynodzAfBgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8E
# TzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBM
# MEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRz
# L01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQAY3f/tdZLMcYqOTjjj
# D7arUPeTsGH9lqFS9YcUnoRQpTm8vMQax2yAlK9ZcdkNGul/mtxQZDKOeWjWEBjW
# YO140oW6yFLpt53FzE8cmN6VVn03b97n7/vMu7XxiOcrDlsW7t1apgEwjcnQU6vn
# pck4nUpO0yImGnG6Jv4VbL6nKFVWAcZNQe5R1sTT11j1bG5GxulvgN1YBY2s8MHp
# UA47nRB8SP7S1b7MXqHdGEFMjSKWPT4DOBcT7oPInv9uvppW8IS81EnMTpqQmczK
# f+TOYLfYvG9FlYoTBYNHQWfN5ePnKdJK1nqKJ9ME/uCqIOyJ2C7GH4EVfsfGE3V4
# d/uNMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWlj
# cm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAx
# MjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8
# E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3O
# CROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJY
# YEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIa
# IYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo
# 8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhac
# AQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTV
# YzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+ii
# XGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0y
# My5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNy
# dDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEW
# MWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5o
# dG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBT
# AHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbg
# mD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzt
# a1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/y
# N31aPxzymXlKkVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8
# tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpx
# Y517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4
# ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/Dh
# O3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJ
# rDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXA
# L1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8ch
# r1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQ
# NdrvCScc1bN+NR4Iuto229Nfj950iEkSoYICzjCCAjcCAQEwgfihgdCkgc0wgcox
# CzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQg
# SXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1Mg
# RVNOOkUwNDEtNEJFRS1GQTdFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBzZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQDDC761+AbesLtFmvG4U7YKZlJ8+KCB
# gzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEB
# BQUAAgUA4xPypDAiGA8yMDIwMDkyMjExNDg1MloYDzIwMjAwOTIzMTE0ODUyWjB3
# MD0GCisGAQQBhFkKBAExLzAtMAoCBQDjE/KkAgEAMAoCAQACAhl3AgH/MAcCAQAC
# AhHhMAoCBQDjFUQkAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKg
# CjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAFRf/gitt
# 3kk9YQkddbdas05Ah5B695eVxnZFTjAFYFTPcEBpZ1YYa6sCcOrF5cc9KUr0rjvU
# 6vwVbyl/bR06LEMpnJna/Y1J/OESvzj56GjL7v2iG8Gm1f4awu+Y4HngPZQZIF2K
# fiWooIFnrOI2QYR5V/GRAsTHjgSzax9ytt0xggMNMIIDCQIBATCBkzB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAQd+N2iYh1o31gAAAAABBzANBglg
# hkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqG
# SIb3DQEJBDEiBCA/JfxOx053hIEbbjTDwK+ZZfHjvv1mlXVAFC+C80szlzCB+gYL
# KoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIEFi8KPikWTCG6ZqABOfSAuH190M3MiZ
# CQo1461GP8seMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAAEHfjdomIdaN9YAAAAAAQcwIgQgS0Sg0LTTyR6fcasBH4kwHQyRIV0N23/u
# 5eC7N+vgHCowDQYJKoZIhvcNAQELBQAEggEAXqKJvmvP/pZa3Oa6JOcAPMl6Javj
# Zn7ZmH/48rilV/1Farrv5GivsU/QhZiKTlcDF6JAv8fL0DejZYjxsypAgxBBWZSF
# 5SV6mZ1E00bHTo33q0XADWoGJ24JGjzP3DMTxBgS1K+M7hDyYJhPaWl00uCGWXMg
# +FeuFdzz21XJqnis41i/dxjZKvLdm/gm8PSzXRQINkbAXj7OwTYHpZqa89uvCau4
# Q5RBDSL+0UzKx17aYpIzi1nx48RJ0TB+WVjjUn5XiUGzwxkR2sbDReygAX/YIA83
# uf40sGaTnnOPIRJj3eMJUPdNMX9n7rmKjQekX6ekenHDvNTsoHYGlV8hWw==
# SIG # End signature block

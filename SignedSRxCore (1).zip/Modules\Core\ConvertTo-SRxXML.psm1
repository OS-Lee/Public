function ConvertTo-SRxXML 
{
<#
.SYNOPSIS
	Export/Convert any object into an XML representation. 
	
.DESCRIPTION
	This module can be widely used across SRx to generate XML out of objects (custom or not). 

.NOTES
	=========================================
	Project		: Search Health Reports (SRx)
	-----------------------------------------
	File Name 	: ConvertTo-SRxXML.psm1
    Author		: Brian Pendergrass
	Requires	: 
		PowerShell Version 3.0, Search Health Reports (SRx), Microsoft.SharePoint.PowerShell
	
	========================================================================================
	This Sample Code is provided for the purpose of illustration only and is not intended to 
	be used in a production environment.  
	
		THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY
		OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

	We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to 
	reproduce and distribute the object code form of the Sample Code, provided that You agree:
		(i) to not use Our name, logo, or trademarks to market Your software product in 
			which the Sample Code is embedded; 
		(ii) to include a valid copyright notice on Your software product in which the 
			 Sample Code is embedded; 
		and 
		(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against
			  any claims or lawsuits, including attorneys' fees, that arise or result from 
			  the use or distribution of the Sample Code.

	========================================================================================

.INPUTS 
	$incomingObj : object to convert.
	$rootTagName : root tag of the XML output. 
	$itemtTag 
.EXAMPLE

	ConvertTo-SRxXML -maxDepth 8 -incomingObj $documentObj -rootTagName "documents" -itemTag "document"
#>
[CmdletBinding()]
param (
	#---Core Parameters-------
	[parameter(Mandatory=$true,ValueFromPipeline=$true,Position=0)] $incomingObj = $null,
	[string]$itemTag="",
	$elementDepth = 0,
	$maxDepth = 3,
	$rootTagName = "",
	$attributes="",
	$allowRecursion=$true,
	$blockRecursionList = (  #block furthe recursion on the properties or children of these objects
		#Too Verbose
		"DiagnosticsProviders",  "DiagnosticsService", "JobDefinitions", 
		"Claims", "UserClaims", "DeviceClaims",
		#Provides Redundant Info
		"Instances", "ServiceApplicationProxyGroup", "DefaultProxies", "WebApplication", "Sites", 
		"FeatureDefinitions", "Features", "FormTemplates", "ResourceMeasures", "UsageEntryType",
		"Visualizations", "TopAnswerVisualization", "FullVisualization",  "SummaryVisualization",
		"Databases", "ManagedAccount", "SearchApplications", "Components", "WebApplications",
		#Recursively Defined
		"Collection", "Area", "SearchServiceApplication"
	),
	$doNotRenderList = (  #completely ignore these items, which tend to be VERY heavy and/or timely
		"Parent", "Farm", "NeedsUpgradeIncludeChildren", "UpgradedPersistedProperties", "RawData",
		"ManageLink", "ProvisionLink", "UnprovisionLink", "JobHistoryEntries", "HistoryEntries" )
)
	BEGIN {
		if ($elementDepth -eq 0) {
			Write-SRx VERBOSE ("(Start Time: " + $(Get-Date) + " )")
			#$xml = "<?xml version=`"1.0`"?>`n"
			#$foo = New-Object System.Xml.XmlDocument
			if ($rootTagName.Length -gt 0) { $collectionName = $rootTagName }
			else { $collectionName = "collection" }
			$collectionTag = "<$collectionName>`n"
		} else { 
			$xml = "" 
		}
		$elements = 0
	}
	PROCESS 
	{
		try 
		{
			$indentation = $(Get-ElementTabbing $elementDepth)	
			$elements++   #Only increments for members of an array

			if (($itemTag.Length -eq 0) -and ($incomingObj -eq $null)) { $itemTag = "isNull" }
			
			# In this does not have no access to SP classes, exceptions would be thrown 
			if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -ne $null) 
			{
				if ($incomingObj -is [Microsoft.SharePoint.Administration.SPManagedAccount])
				{
					$attributes += $(Get-ElementAttribs $incomingObj)
					if ($itemTag.Length -eq 0) { $itemTag = [System.Xml.XmlConvert]::EncodeName($incomingObj.GetType().Name) }
					if (($incomingObj -ne $null) -and ($incomingObj.length -gt 0)) {
						$xml += $indentation + "<" + $itemTag + $attributes + "><![CDATA[" + $incomingObj + "]]></$itemTag>`n"
					} else { $xml += $indentation + "<" + $itemTag + $attributes + " />`n" }
					Write-SRx VERBOSE ($itemTag)
				}
				else
				{
					if ($incomingObj -is [Microsoft.Office.Server.Search.Administration.LocationConfigurationCollection])
					{
						if ($itemTag.Length -eq 0) { $itemTag = [System.Xml.XmlConvert]::EncodeName($incomingObj.GetType().Name) }
						if ($($incomingObj | Measure).Count -gt 0) { 
							$xml += $indentation + "<" + $itemTag + $attributes + ">`n"
							$i = 0
							foreach ($childItem in $incomingObj) {
								if ($childItem -ne $null) { 
									$childTag = [System.Xml.XmlConvert]::EncodeName($childItem.GetType().Name)
									Write-SRx VERBOSE ($itemTag + "[" + $i + "] : " + $childTag)
									$arrayIndex = " idx=`"" + $i + "`""
									if (($elementDepth -lt $maxDepth) -and $allowRecursion) {
										$xml += $(ConvertTo-SRxXML $childItem -itemTag $childTag -attributes $arrayIndex -elementDepth $($elementDepth + 1) -maxDepth $maxDepth)
									} else {
										$xml += $indentation + "`t"+ "<" + $childTag + $arrayIndex + $(Get-ElementAttribs $childItem) + "><![CDATA[" + $childItem + "]]></" + $childTag + ">`n"
									}
									$i++
								} else {
									$xml += $indentation + "`t"+ "<"+ $childTag + $arrayIndex + " />`n" 
								}
							}
							$xml += $indentation + "</$itemTag>`n"
						} else {
							$xml += $indentation + "<" + $itemTag + " />`n"
						}
					}
				}
			}

			if (($incomingObj -eq $null) -or 
			($incomingObj -is [string]) -or ($incomingObj -is [Uri]) -or ($incomingObj -is [GUID]) -or
			($incomingObj -is [TimeSpan]) -or ($incomingObj -is [DateTime]) -or 
			($incomingObj -is [System.Security.Principal.SecurityIdentifier]) -or
			#($incomingObj -is [Microsoft.SharePoint.Administration.SPManagedAccount]) -or
			$(($incomingObj.GetType()).IsPrimitive) -or 
			$($incomingObj.GetType().BaseType.Name -eq "Enum")) 
			{
				$attributes += $(Get-ElementAttribs $incomingObj)
				if ($itemTag.Length -eq 0) { $itemTag = [System.Xml.XmlConvert]::EncodeName($incomingObj.GetType().Name) }
				if (($incomingObj -ne $null) -and ($incomingObj.length -gt 0)) {
					$xml += $indentation + "<" + $itemTag + $attributes + "><![CDATA[" + $incomingObj + "]]></$itemTag>`n"
				} else { $xml += $indentation + "<" + $itemTag + $attributes + " />`n" }
				Write-SRx VERBOSE ($itemTag)
			} 
			else 
			{
				if ($incomingObj -is [System.Collections.IDictionary]) 
				{ 
					if ($itemTag.Length -eq 0) { $itemTag = [System.Xml.XmlConvert]::EncodeName($incomingObj.GetType().Name) }
					$xml += $indentation + "<" + $itemTag + $attributes + ">`n"
					foreach ($childName in $incomingObj.Keys) {
						$childTag = [System.Xml.XmlConvert]::EncodeName($($incomingObj[$childName]).GetType().Name)
						$keyAttrib = " key=`"" + [System.Xml.XmlConvert]::EncodeName($childName) + "`""
						Write-SRx VERBOSE ($itemTag + "[" + $childName + "]")
						if ($incomingObj[$childName] -ne $null) {
							if (($elementDepth -lt $maxDepth) -and $allowRecursion) {	
								$xml += $(ConvertTo-SRxXML $incomingObj[$childName] -itemTag $childTag -attributes $keyAttrib -elementDepth $($elementDepth + 1) -maxDepth $maxDepth)
							} else {
								$xml += $indentation + "`t"+ "<" + $childTag + $keyAttrib + "><![CDATA[" + $incomingObj[$childName] + "]]></" + $childTag + ">`n"
							}
						} else { $xml += $indentation + "`t"+ "<" + $childTag + $keyAttrib + " />`n" }
					}
					$xml += $indentation + "</$itemTag>`n"
				} 
				else 
				{
					if (($incomingObj -is [System.Collections.ICollection]) -or
					($incomingObj -is [System.Collections.IEnumerable]) -or
					($incomingObj -is [System.Collections.ArrayList]) -or
					($incomingObj -is [System.Collections.IList]) -or
					($incomingObj -is [Array]) -or 
					(($incomingObj.GetType().BaseType.Name) -like "*Array*")
					#($incomingObj -is [Microsoft.Office.Server.Search.Administration.LocationConfigurationCollection])
					) 
					{
						if ($itemTag.Length -eq 0) { $itemTag = [System.Xml.XmlConvert]::EncodeName($incomingObj.GetType().Name) }
						if ($($incomingObj | Measure).Count -gt 0) { 
							$xml += $indentation + "<" + $itemTag + $attributes + ">`n"
							$i = 0
							foreach ($childItem in $incomingObj) {
								if ($childItem -ne $null) { 
									$childTag = [System.Xml.XmlConvert]::EncodeName($childItem.GetType().Name)
									Write-SRx VERBOSE ($itemTag + "[" + $i + "] : " + $childTag)
									$arrayIndex = " idx=`"" + $i + "`""
									if (($elementDepth -lt $maxDepth) -and $allowRecursion) {
										$xml += $(ConvertTo-SRxXML $childItem -itemTag $childTag -attributes $arrayIndex -elementDepth $($elementDepth + 1) -maxDepth $maxDepth)
									} else {
										$xml += $indentation + "`t"+ "<" + $childTag + $arrayIndex + $(Get-ElementAttribs $childItem) + "><![CDATA[" + $childItem + "]]></" + $childTag + ">`n"
									}
									$i++
								} else {
									$xml += $indentation + "`t"+ "<"+ $childTag + $arrayIndex + " />`n" 
								}
							}
							$xml += $indentation + "</$itemTag>`n"
						} else {
							$xml += $indentation + "<" + $itemTag + " />`n"
						}
					} else {
						if ($incomingObj -is [Object]) {
							if ($itemTag.Length -eq 0) { $itemTag = $incomingObj.GetType().Name }
							Write-SRx VERBOSE ($itemTag)
							$attributes += $(Get-ElementAttribs $incomingObj)
							$xml += $indentation + "<" + $itemTag
							if (($elementDepth -lt $maxDepth) -and $allowRecursion) {							
								$propertyBag = $incomingObj | Get-Member -ErrorAction SilentlyContinue | Where {($_.MemberType -eq "Property") -or ($_.MemberType -eq "NoteProperty") -or ($_.MemberType -eq "ScriptProperty")}
								if ($propertyBag -ne $null) {
									$xml += ">`n"
									foreach ($objProperty in $propertyBag) {
										$propertyName = $objProperty.Name
										Write-SRx VERBOSE ($itemTag + "." + $propertyName)
										<# for debugging #>	if ($itemTag -eq "fill-in-your-tag-name") {
																$debugPoint = $true   <# for debugging #>
										<# for debugging #>	}									
										if ($doNotRenderList.Contains($propertyName)) {
											$xml += $indentation + "`t"+ "<$propertyName />  <!-- SRx: Item Skipped --> `n"
										} else {
											if ($incomingObj.$propertyName -eq $null) { 
												$xml += $indentation + "`t"+ "<$propertyName />`n"
											} else {
												if ($blockRecursionList.Contains($propertyName)) { $canRecurse = $false }
												else { $canRecurse = $true }
												switch ($propertyName) {
													"Server"	{ 
														if ($incomingObj.Server.GetType().Name -eq "SPServer") { $childObj = $incomingObj.Server.Address }
														else { 
															$childObj = $incomingObj.Server
															$canRecurse = $false
														}
													}
													"Service"	{
														if ($incomingObj.Parent.GetType().Name -eq "SPServer") { $canRecurse = $false }
													}
													default {
														if ($blockRecursionList.Contains($propertyName)) { 
															$canRecurse = $false
														} else { $canRecurse = $true }
														$childObj = $incomingObj.$propertyName
													}
												}
												if ($childObj -ne $null) {
													$xml += $(ConvertTo-SRxXML $childObj -itemTag $propertyName -elementDepth $($elementDepth + 1) -maxDepth $maxDepth -allowRecursion $canRecurse) 
												} else { $xml += $indentation + "`t"+ "<$propertyName />`n" }
											}
										}
									}
								} else {
									$indentation = ""
								}
							} else {
								if (($incomingObj.GetType().Name -like "SP*") -and
									(
										($incomingObj.GetType().Name -ne "SPFarm") -or 
										($incomingObj.GetType().Name -ne "SPServer") -or
										($incomingObj.GetType().Name -ne "SPServiceApplicationProxyGroup") -or
										($incomingObj.GetType().Name -ne "SPWebApplication") -or
										($incomingObj.GetType().Name -ne "SPSite") -or
										($incomingObj.GetType().Name -ne "SPWeb")
									)) {
									$xml += $attributes + "><![CDATA[" + $( $incomingObj | select * -First 100 ) + "]]> <!-- SRx: $incomingObj | select * -First 100 --> "
								} else { $xml += "><![CDATA[" + $incomingObj + "]]>" }
								$indentation = ""
							}
							$xml += $indentation + "</$itemTag>`n"
						}
					}
				}
			}
		} 
		catch 
		{
			#potentially unsupported type on the running host (laptop vs Content vs Search Farm)
		}
	}
	END {
		if (($elements -gt 1) -or ($rootTagName.Length -gt 0))  {
			$xml = $collectionTag + $xml + "</$collectionName>`n"
		} 
		$xml
	}
}

Export-ModuleMember *SRx*

function Get-ElementTabbing {
	param ([int]$depth=0)
	$tabbedWhiteSpace = ""
	for ($i=0; $i -lt $depth; $i++) { $tabbedWhiteSpace += "`t"}
	$tabbedWhiteSpace
}

function Get-ElementAttribs {
	param ($anObject = $null, $attribList = @("displayName","name") )
	$attribString = ""
	
	foreach ($attribName in $attribList) {
		if (($anObject.$attribName -ne $null) -and (-not [string]::IsNullOrEmpty($($anObject.$attribName).trim()))) {
			$attribString += " $attribName=`"" + [System.Web.HttpUtility]::HtmlAttributeEncode($anObject.$attribName) + "`""	
		}
	}
	$attribString
}

# SIG # Begin signature block
# MIIj0wYJKoZIhvcNAQcCoIIjxDCCI8ACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBUVeK2L+5dpCPE
# gTWWWsqKkvh5qj/2mA3940DCudvOraCCDYEwggX/MIID56ADAgECAhMzAAABh3IX
# chVZQMcJAAAAAAGHMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAwMzA0MTgzOTQ3WhcNMjEwMzAzMTgzOTQ3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOt8kLc7P3T7MKIhouYHewMFmnq8Ayu7FOhZCQabVwBp2VS4WyB2Qe4TQBT8aB
# znANDEPjHKNdPT8Xz5cNali6XHefS8i/WXtF0vSsP8NEv6mBHuA2p1fw2wB/F0dH
# sJ3GfZ5c0sPJjklsiYqPw59xJ54kM91IOgiO2OUzjNAljPibjCWfH7UzQ1TPHc4d
# weils8GEIrbBRb7IWwiObL12jWT4Yh71NQgvJ9Fn6+UhD9x2uk3dLj84vwt1NuFQ
# itKJxIV0fVsRNR3abQVOLqpDugbr0SzNL6o8xzOHL5OXiGGwg6ekiXA1/2XXY7yV
# Fc39tledDtZjSjNbex1zzwSXAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhov4ZyO96axkJdMjpzu2zVXOJcsw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU4Mzg1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAixmy
# S6E6vprWD9KFNIB9G5zyMuIjZAOuUJ1EK/Vlg6Fb3ZHXjjUwATKIcXbFuFC6Wr4K
# NrU4DY/sBVqmab5AC/je3bpUpjtxpEyqUqtPc30wEg/rO9vmKmqKoLPT37svc2NV
# BmGNl+85qO4fV/w7Cx7J0Bbqk19KcRNdjt6eKoTnTPHBHlVHQIHZpMxacbFOAkJr
# qAVkYZdz7ikNXTxV+GRb36tC4ByMNxE2DF7vFdvaiZP0CVZ5ByJ2gAhXMdK9+usx
# zVk913qKde1OAuWdv+rndqkAIm8fUlRnr4saSCg7cIbUwCCf116wUJ7EuJDg0vHe
# yhnCeHnBbyH3RZkHEi2ofmfgnFISJZDdMAeVZGVOh20Jp50XBzqokpPzeZ6zc1/g
# yILNyiVgE+RPkjnUQshd1f1PMgn3tns2Cz7bJiVUaqEO3n9qRFgy5JuLae6UweGf
# AeOo3dgLZxikKzYs3hDMaEtJq8IP71cX7QXe6lnMmXU/Hdfz2p897Zd+kU+vZvKI
# 3cwLfuVQgK2RZ2z+Kc3K3dRPz2rXycK5XCuRZmvGab/WbrZiC7wJQapgBodltMI5
# GMdFrBg9IeF7/rP4EqVQXeKtevTlZXjpuNhhjuR+2DMt/dWufjXpiW91bo3aH6Ea
# jOALXmoxgltCp1K7hrS6gmsvj94cLRf50QQ4U8Qwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVqDCCFaQCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAYdyF3IVWUDHCQAAAAABhzAN
# BglghkgBZQMEAgEFAKCB7zAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgBgfZ6DM1
# lCMVDQnl920ec8e/vk3b2MqKDiRUhq/g3DMwgYIGCisGAQQBgjcCAQwxdDByoFaA
# VABTAGgAYQByAGUAUABvAGkAbgB0ACAAUwBlAGEAcgBjAGgAIABIAGUAYQBsAHQA
# aAAgAFIAZQBwAG8AcgB0AHMAIABEAGEAcwBoAGIAbwBhAHIAZKEYgBZodHRwczov
# L21pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEBAQUABIIBAHyd2QEIihug8DrZvg5I
# A3ObGLyoCEjNtFvVVtPbo3UOxNRYPNObmSsCxlG30nCvdxW0J/OZNrYRB9hm9yrm
# vZenFW9XUZpi/ibPfc2Wipq/YFG8Z4vAD3hEgiC6yVoavWRu+HrHWhd1aWZFMVpo
# p79CzFhcmF41GO0JDxQCecE2hzfVoTgKkBjCkyJEgsL5K372SaEOvhiFaOb3xjEO
# cPN7iHbV/0cro3CbZnSREl2P0i0afFStWwjsGz2EHxHyQwbJPL9VfTtiXWkFFEwD
# JHH2V0g7WQwfLLYUzOGXlfUT34PFoaGBm0/Bz+0MRa5/NtEbVaVRMhA2YgKjFOoU
# rz2hghLxMIIS7QYKKwYBBAGCNwMDATGCEt0wghLZBgkqhkiG9w0BBwKgghLKMIIS
# xgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYLKoZIhvcNAQkQAQSgggFEBIIBQDCC
# ATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQg1MAQEBcgkYzamLfn
# 9tsXesjqA/pic302I9ewxmE5GKwCBl9hCfONRRgTMjAyMDA5MjIxMzU0MTguNjgx
# WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28x
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjMyQkQtRTNENS0zQjFEMSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIORDCCBPUwggPdoAMCAQIC
# EzMAAAEuqNIZB5P0a+gAAAAAAS4wDQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwHhcNMTkxMjE5MDExNTA1WhcNMjEwMzE3MDExNTA1
# WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UE
# CxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOjMyQkQtRTNENS0zQjFEMSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEArtNMolFTX3osUiMxD2r9SOk+HPjeblGceAcBWnZgaeLvj6W2xig7WdnnytNs
# mEJDwZgfLwHh16+Buqpg9A1TeL52ukS0Rw0tuwyvgwSrdIz687drpAwV3WUNHLsh
# As8k0sq9wzr023uS7VjIzk2c80NxEmydRv/xjH/NxblxaOeiPyz19D3cE9/8nvio
# zWqXYJ3NBXvg8GKww/+2mkCdK43Cjwjv65avq9+kHKdJYO8l4wOtyxrrZeybsNsH
# U2dKw8YAa3dHOUFX0pWJyLN7hTd+jhyF2gHb5Au7Xs9oSaPTuqrvTQIblcmSkRg6
# N500WIHICkXthG9Cs5lDTtBiIwIDAQABo4IBGzCCARcwHQYDVR0OBBYEFIaaiSZO
# C4k3u6pJNDVSEvC3VE5sMB8GA1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kv
# Y3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEF
# BQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQC
# MAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggEBAI3gBGqn
# MK6602pjadYkMNePfmJqJ2WC0n9uyliwBfxq0mXX0h9QojNO65JVTdxpdnr9i8wx
# gxxuw1r/gnby6zbcro9ZkCWMiPQbxC3AMyVAeOsqetyvgUEDPpmq8HpKs3f9ZtvR
# BIr86XGxTSZ8PvPztHYkziDAom8foQgu4AS2PBQZIHU0qbdPCubnV8IPSPG9bHNp
# RLZ628w+uHwM2uscskFHdQe+D81dLYjN1CfbTGOOxbQFQCJN/40JGnFS+7+PzQ1v
# X76+d6OJt+lAnYiVeIl0iL4dv44vdc6vwxoMNJg5pEUAh9yirdU+LgGS9ILxAau+
# GMBlp+QTtHovkUkwggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEB
# CwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYD
# VQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAe
# Fw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0N
# vHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycE
# MR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1
# R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxG
# wScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/Q
# S/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38
# vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYD
# VR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1
# AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaA
# FNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8y
# MDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAt
# MDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9Bggr
# BgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9k
# ZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABp
# AGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEA
# B+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9
# x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9C
# EMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP
# 7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoL
# kSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4E
# QoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQ
# zafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5h
# a293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3q
# jeAzLhIp9cAvVCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99j
# e/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8
# z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P3nSISRKhggLSMIICOwIBATCB/KGB
# 1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcG
# A1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsT
# HVRoYWxlcyBUU1MgRVNOOjMyQkQtRTNENS0zQjFEMSUwIwYDVQQDExxNaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQD7X8I3oEgt5TXI
# Maj5vpaSkuhCm6CBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MA0GCSqGSIb3DQEBBQUAAgUA4xQZ+zAiGA8yMDIwMDkyMjEwMzY0M1oYDzIwMjAw
# OTIzMTAzNjQzWjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDjFBn7AgEAMAoCAQAC
# AiZTAgH/MAcCAQACAhGnMAoCBQDjFWt7AgEAMDYGCisGAQQBhFkKBAIxKDAmMAwG
# CisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEF
# BQADgYEAeIW3Y8mQvdY6CceRqDw1poFr2TH+2SQfT+9bE30G4DrsIw2/C1XBYScA
# oHfOTKF6BcETVqp4xDlJrnQPaWgGeu2vV+nQDia0djWtzTQ2Ju16FrE67L4QTrHj
# myoXkjxY2P3ReKjnxI98EJxSDxaKvJkr+ZLGV/5WSgdXzu4MKzkxggMNMIIDCQIB
# ATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAS6o0hkHk/Rr
# 6AAAAAABLjANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3
# DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCAXN4ZqNHTh/1t32IVofZGgNs7FiEWCl/NE
# Lw/VtOt2aDCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EINr+zc7xiFaKqlU3
# SRN4r7HabRECHXsmlHoOIWhMgskpMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgUENBIDIwMTACEzMAAAEuqNIZB5P0a+gAAAAAAS4wIgQgZ4WI82nY7Fs6Y3G8
# iHGYT7bIjBPoI5kyJH85/QajkCcwDQYJKoZIhvcNAQELBQAEggEAg/GpBXT8Zn7I
# 9iEmRbuk8DpmHxaYUEPZCFpNysGLNO2snEbSEdePxJ7CVgqla/+YPgih+I5OUr9k
# 5yTODs2ZCMMWOSDbzwByVnOwk60zFgjWPF6GTBA6HzPLoP/sp93Xtmxpilxlb/5v
# bWDsvXNkDXyGsqbg2JhGbEzmLUr1yJX1jb2DWIvwaHET469sstFxarVCpyUY7b7/
# uWPoKVdkywSadJnghsurDvhnK23SN/JVLTDFKxpC0kktTW2tNF+jccb3k0BK8qnt
# 1//COGP9pkdhkRStShzvQaT0q3jCDJUa3IAJhesKrjTOXWa7e3CIohajslWxnoZs
# nXXQos/X3g==
# SIG # End signature block

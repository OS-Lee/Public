<#
.SYNOPSIS
    When you run this script you onboard your SharePoint Online (SPO) tenant and your SharePoint server cloud SSA to cloud hybrid search.
    This includes setting up server to server authentication between SharePoint Online and SharePoint Server
.PARAMETER PortalUrl
    SharePoint Online portal URL, for example 'https://contoso.sharepoint.com'.
.PARAMETER CloudSsaId
    Name or id (Guid) of the cloud Search service application, created with the CreateCloudSSA script.
.PARAMETER Credential
    Logon credential for tenant admin. Will prompt for credential if not specified.

.NOTES
    TODO
    - Check that SCS URLs are accessible
        need to invoke as service account
    	*.search.msit.us.trafficmanager.net
		*.search.production.us.trafficmanager.net
		*.search.production.emea.trafficmanager.net
		*.search.production.apac.trafficmanager.net
        https://usfrontendexternal.search.production.us.trafficmanager.net/
#>
Param(
    [Parameter(Mandatory=$true, HelpMessage="SharePoint Online portal URL, for example 'https://contoso.sharepoint.com'.")]
    [ValidateNotNullOrEmpty()]
    [string] $PortalUrl,

    [Parameter(Mandatory=$false, HelpMessage="Name or id (Guid) of the cloud Search service application, created with the CreateCloudSSA script.")]
    [ValidateNotNullOrEmpty()]
    [string] $CloudSsaId,
    
    [Parameter(Mandatory=$false, HelpMessage="Logon credential for tenant admin. Will be prompted if not specified.")]
    [PSCredential] $Credential
)

if ($ACS_APPPRINCIPALID -eq $null) {
    New-Variable -Option Constant -Name ACS_APPPRINCIPALID -Value '00000001-0000-0000-c000-000000000000'
    New-Variable -Option Constant -Name ACS_HOST -Value "accounts.accesscontrol.windows.net"
    New-Variable -Option Constant -Name PROVISIONINGAPI_WEBSERVICEURL -Value "https://provisioningapi.microsoftonline.com/provisioningwebservice.svc"
    New-Variable -Option Constant -Name SCS_AUTHORITIES -Value @(
        "*.search.msit.us.trafficmanager.net",
        "*.search.production.us.trafficmanager.net",
        "*.search.production.emea.trafficmanager.net",
        "*.search.production.apac.trafficmanager.net"
    )
}

New-Variable -Option Constant -Name SCS_APPPRINCIPALID -Value '8f0dc9ad-0d19-4fec-a421-6d0279080014'
New-Variable -Option Constant -Name SCS_APPPRINCIPALDISPLAYNAME -Value 'Search Content Service'
New-Variable -Option Constant -Name SP_APPPRINCIPALID -Value '00000003-0000-0ff1-ce00-000000000000'
New-Variable -Option Constant -Name SPO_MANAGEMENT_APPPROXY_NAME -Value 'SPO App Management Proxy'
New-Variable -Option Constant -Name ACS_APPPROXY_NAME -Value 'ACS'
New-Variable -Option Constant -Name ACS_STS_NAME -Value 'ACS-STS'
New-Variable -Option Constant -Name AAD_METADATAEP_FSTRING -Value 'https://{0}/{1}/metadata/json/1'

$SP_VERSION = "15"
$regKey = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Office Server\15.0\Search" -ErrorAction SilentlyContinue
if ($regKey -eq $null) {
    $regKey = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Office Server\16.0\Search" -ErrorAction SilentlyContinue
    if ($regKey -eq $null) {
        throw "Unable to detect SharePoint installation."
    }
    $SP_VERSION = "16"
}

Write-Host "Configuring for SharePoint Server version $SP_VERSION."

function Configure-LocalSharePointFarm
{
    Param(
        [Parameter(Mandatory=$true)][string] $Realm
    )

    # Set up to authenticate as AAD realm
    Set-SPAuthenticationRealm -Realm $Realm

    $acsMetadataEndpoint = $AAD_METADATAEP_FSTRING -f $ACS_HOST,$Realm
    $acsMetadataEndpointUri = [System.Uri] $acsMetadataEndpoint
    $acsMetadataEndpointUriSlash = [System.Uri] "$($acsMetadataEndpoint)/"
    Write-Host "ACS metatada endpoint: $acsMetadataEndpoint"

    # ACS Proxy
    $acsProxy = Get-SPServiceApplicationProxy | ? {
        $_.TypeName -eq "Azure Access Control Service Application Proxy" -and
        (($_.MetadataEndpointUri -eq $acsMetadataEndpointUri) -or ($_.MetadataEndpointUri -eq $acsMetadataEndpointUriSlash))
    }
    if ($acsProxy -eq $null) {
        Write-Host "Setting up ACS proxy..." -Foreground Yellow
        $acsProxy = Get-SPServiceApplicationProxy | ? {$_.DisplayName -eq $ACS_APPPROXY_NAME}
        if ($acsProxy -ne $null) {
            throw "There is already a service application proxy registered with name '$($acsProxy.DisplayName)'. Remove manually and retry."
        }
        $acsProxy = New-SPAzureAccessControlServiceApplicationProxy -Name $ACS_APPPROXY_NAME -MetadataServiceEndpointUri $acsMetadataEndpointUri -DefaultProxyGroup
    } elseif ($acsProxy.Count > 1) {
        throw "Found multiple existing ACS proxies for this metadata endpoint."
    } else {
        Write-Host "Found existing ACS proxy '$($acsProxy.DisplayName)'." -Foreground Green
    }

    # The proxy must be in default group and set as default for authentication to work
    if (((Get-SPServiceApplicationProxyGroup -Default).DefaultProxies | select Id).Id -notcontains $acsProxy.Id) {
        throw "ACS proxy '$($acsProxy.DisplayName)' is not set as the default. Configure manually through Service Application Associations admin UI and retry."
    }

    # Register ACS token issuer
    $acsTokenIssuer = Get-SPTrustedSecurityTokenIssuer | ? {
        (($_.MetadataEndPoint -eq $acsMetadataEndpointUri) -or ($_.MetadataEndPoint -eq $acsMetadataEndpointUriSlash))
    }
    if ($acsTokenIssuer -eq $null) {
        Write-Host "Registering ACS as trusted token issuer..." -Foreground Yellow
        $acsTokenIssuer = Get-SPTrustedSecurityTokenIssuer | ? {$_.DisplayName -eq $ACS_STS_NAME}
        if ($acsTokenIssuer -ne $null) {
            throw "There is already a token issuer registered with name '$($acsTokenIssuer.DisplayName)'. Remove manually and retry."
        }
        try {
            $acsTokenIssuer = New-SPTrustedSecurityTokenIssuer -Name $ACS_STS_NAME -IsTrustBroker -MetadataEndPoint $acsMetadataEndpointUri -ErrorAction Stop
        } catch [System.ArgumentException] {
            Write-Warning "$($_)"
        }
    } elseif ($acsTokenIssuer.Count > 1) {
        throw "Found multiple existing token issuers for this metadata endpoint."
    } else {
        if ($acsTokenIssuer.IsSelfIssuer -eq $true) {
            Write-Warning "Existing trusted token issuer '$($acsTokenIssuer.DisplayName)' is configured as SelfIssuer."
        } else {
            Write-Host "Found existing token issuer '$($acsTokenIssuer.DisplayName)'." -Foreground Green
        }
    }

    # SPO proxy
    $spoProxy = Get-SPServiceApplicationProxy | ? {$_.TypeName -eq "SharePoint Online Application Principal Management Service Application Proxy" -and $_.OnlineTenantUri -eq [System.Uri] $PortalUrl}
    if ($spoProxy -eq $null) {
        Write-Host "Setting up SPO Proxy..." -Foreground Yellow
        $spoProxy = Get-SPServiceApplicationProxy | ? {$_.DisplayName -eq $SPO_MANAGEMENT_APPPROXY_NAME}
        if ($spoProxy -ne $null) {
            throw "There is already a service application proxy registered with name '$($spoProxy.DisplayName)'. Remove manually and retry."
        }
        $spoProxy = New-SPOnlineApplicationPrincipalManagementServiceApplicationProxy -Name $SPO_MANAGEMENT_APPPROXY_NAME -OnlineTenantUri $PortalUrl -DefaultProxyGroup
    } elseif ($spoProxy.Count > 1) {
        throw "Found multiple existing SPO proxies for this tenant URI."
    } else {
        Write-Host "Found existing SPO proxy '$($spoProxy.DisplayName)'." -Foreground Green
    }

    # The proxy should be in default group and set to default
    if (((Get-SPServiceApplicationProxyGroup -Default).DefaultProxies | select Id).Id -notcontains $spoProxy.Id) {
        throw "SPO proxy '$($spoProxy.DisplayName)' is not set as the default. Configure manually through Service Application Associations admin UI and retry."
    }

    return (Get-SPSecurityTokenServiceConfig).LocalLoginProvider.SigningCertificate
}

function Upload-SigningCredentialToSharePointPrincipal
{
    Param(
        [Parameter(Mandatory=$true)][System.Security.Cryptography.X509Certificates.X509Certificate2] $Cert
    )

    $exported = $Cert.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert)
    $certValue = [System.Convert]::ToBase64String($exported)

    $principal = Get-MsolServicePrincipal -AppPrincipalId $SP_APPPRINCIPALID
    $keys = Get-MsolServicePrincipalCredential -ObjectId $principal.ObjectId -ReturnKeyValues $true | ? Value -eq $certValue
    if ($keys -eq $null) {
        New-MsolServicePrincipalCredential -AppPrincipalId $SP_APPPRINCIPALID -Type Asymmetric -Value $certValue -Usage Verify
    } else {
        Write-Host "Signing credential already exists in SharePoint principal."
    }
}

function Add-ScsServicePrincipal
{
    $spns = $SCS_AUTHORITIES | foreach { "$SCS_APPPRINCIPALID/$_" }
    $principal = Get-MsolServicePrincipal -AppPrincipalId $SCS_APPPRINCIPALID -ErrorAction SilentlyContinue

    if ($principal -eq $null) {
        Write-Host "Creating new service principal for $SCS_APPPRINCIPALDISPLAYNAME with the following SPNs:"
        $spns | foreach { Write-Host $_ }
        $scspn = New-MsolServicePrincipal -AppPrincipalId $SCS_APPPRINCIPALID -DisplayName $SCS_APPPRINCIPALDISPLAYNAME -ServicePrincipalNames $spns
    } else {
        $update = $false
        $spns | foreach {
            if ($principal.ServicePrincipalNames -notcontains $_) {
                $principal.ServicePrincipalNames.Add($_)
                Write-Host "Adding new SPN to existing service principal: $_."
                $update = $true
            }
        }
        if ($update -eq $true) {
            Set-MsolServicePrincipal -AppPrincipalId $principal.AppPrincipalId -ServicePrincipalNames $principal.ServicePrincipalNames
        } else {
            Write-Host "Service Principal already registered, containing the correct SPNs."
        }
    }
}

function Prepare-Environment
{
    $MSOIdCRLRegKey = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSOIdentityCRL" -ErrorAction SilentlyContinue
    if ($MSOIdCRLRegKey -eq $null) {
        Write-Host "Online Services Sign-In Assistant required, install from http://www.microsoft.com/en-us/download/details.aspx?id=39267." -Foreground Red
    } else {
        Write-Host "Found Online Services Sign-In Assistant!" -Foreground Green
    }

    $MSOLPSRegKey = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSOnlinePowershell" -ErrorAction SilentlyContinue
    if ($MSOLPSRegKey -eq $null) {
        Write-Host "AAD PowerShell required, install from http://go.microsoft.com/fwlink/p/?linkid=236297." -Foreground Red
    } else {
        Write-Host "Found AAD PowerShell!" -Foreground Green
    }

    if ($MSOIdCRLRegKey -eq $null -or $MSOLPSRegKey -eq $null) {
        throw "Manual installation of prerequisites required."
    }

    Write-Host "Configuring Azure AD settings..." -Foreground Yellow

    $regkey = "HKLM:\SOFTWARE\Microsoft\MSOnlinePowerShell\Path"
    Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSOIdentityCRL" -Name "ServiceEnvironment" -Value "Production"
    Set-ItemProperty -Path $regkey -Name "WebServiceUrl" -Value $PROVISIONINGAPI_WEBSERVICEURL
    Set-ItemProperty -Path $regkey -Name "FederationProviderIdentifier" -Value "microsoftonline.com"

    Write-Host "Restarting MSO IDCRL Service..." -Foreground Yellow

    # Service takes time to get provisioned, retry restart.
    for ($i = 1; $i -le 10; $i++) {
        try {
            Stop-Service -Name msoidsvc -Force -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
            $svc = Get-Service msoidsvc
            $svc.WaitForStatus("Stopped")
            Start-Service -Name msoidsvc
        } catch {
            Write-Host "Failed to start msoidsvc service, retrying..."
            Start-Sleep -seconds 2
            continue
        }
        Write-Host "Service Restarted!" -Foreground Green
        break
    }
}

function Get-CloudSsa
{
    $ssa = $null

    if (-not $CloudSsaId) {
        $ssa = Get-SPEnterpriseSearchServiceApplication
        if ($ssa.Count -ne 1) {
            throw "Multiple SSAs found, specify which cloud SSA to on-board."
        }
    } else {
        $ssa = Get-SPEnterpriseSearchServiceApplication -Identity $CloudSsaId
    }

    if ($ssa -eq $null) {
        throw "Cloud SSA not found."
    }

    # Make sure SSA is created with CreateCloudSSA.ps1
    if ($ssa.CloudIndex -ne $true) {
        throw "The provided SSA is not set up for cloud hybrid search, please create a cloud SSA before proceeding with onboarding."
    }

    Write-Host "Using SSA with id $($ssa.Id)."
    $ssa.SetProperty("IsHybrid", 1)
    $ssa.Update()

    return $ssa
}

$code = @"
using System;
using System.Net;
using System.Security;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.IdentityModel;
using Microsoft.SharePoint.IdentityModel.OAuth2;

static public class ClientContextHelper
{
    public static ClientContext GetAppClientContext(string siteUrl)
    {
        SPServiceContext serviceContext = SPServiceContext.GetContext(SPServiceApplicationProxyGroup.Default, SPSiteSubscriptionIdentifier.Default);
        using (SPServiceContextScope serviceContextScope = new SPServiceContextScope(serviceContext))
        {
            ClientContext clientContext = new ClientContext(siteUrl);
            ICredentials credentials = null;
            clientContext.ExecutingWebRequest += (sndr, request) =>
            {
                    request.WebRequestExecutor.RequestHeaders.Add(HttpRequestHeader.Authorization, "Bearer");
                    request.WebRequestExecutor.WebRequest.PreAuthenticate = true;
            };

            // Run elevated to get app credentials
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
               credentials = SPOAuth2BearerCredentials.Create();
            });

            clientContext.Credentials = credentials;

            return clientContext;
        }
    }
}
"@

$assemblies = @(
"System.Core.dll",
"System.Web.dll",
"Microsoft.SharePoint, Version=$SP_VERSION.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c",
"Microsoft.SharePoint.Client, Version=$SP_VERSION.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c",
"Microsoft.SharePoint.Client.Runtime, Version=$SP_VERSION.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c"
)

Add-Type -AssemblyName ("Microsoft.SharePoint.Client, Version=$SP_VERSION.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c")
Add-Type -AssemblyName ("Microsoft.SharePoint.Client.Search, Version=$SP_VERSION.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c")
Add-Type -AssemblyName ("Microsoft.SharePoint.Client.Runtime, Version=$SP_VERSION.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c")
Add-Type -TypeDefinition $code -ReferencedAssemblies $assemblies

Add-PSSnapin Microsoft.SharePoint.PowerShell

try
{
    Write-Host "Accessing Cloud SSA..." -Foreground Yellow
    $ssa = Get-CloudSsa

    Write-Host "Preparing environment..." -Foreground Yellow
    Prepare-Environment

    Import-Module MSOnline
    Import-Module MSOnlineExtended -force

    Write-Host "Connecting to O365..." -Foreground Yellow
    if ($Credential -eq $null) {
        $Credential = Get-Credential -Message "Tenant Admin credential"
    }
    Connect-MsolService -Credential $Credential -ErrorAction Stop
    $tenantInfo = Get-MsolCompanyInformation
    $AADRealm = $tenantInfo.ObjectId.Guid

    Write-Host "AAD tenant realm is $AADRealm."

    Write-Host "Configuring on-prem SharePoint farm..." -Foreground Yellow
    $signingCert = Configure-LocalSharePointFarm -Realm $AADRealm
    
    Write-Host "Adding local signing credential to SharePoint principal..." -Foreground Yellow
    Upload-SigningCredentialToSharePointPrincipal -Cert $signingCert

    Write-Host "Configuring service principal for the cloud search service..." -Foreground Yellow
    Add-ScsServicePrincipal

    Write-Host "Connecting to content farm in SPO..." -foreground Yellow
    $cctx = [ClientContextHelper]::GetAppClientContext($PortalUrl)
    $pushTenantManager = new-object Microsoft.SharePoint.Client.Search.ContentPush.PushTenantManager $cctx

    # Retry up to 4 minutes, mitigate 401 Unauthorized from CSOM
    Write-Host "Preparing tenant for cloud hybrid search (this can take a couple of minutes)..." -foreground Yellow
    for ($i = 1; $i -le 12; $i++) {
        try {
            $pushTenantManager.PreparePushTenant()
            $cctx.ExecuteQuery()
            Write-Host "PreparePushTenant was successfully invoked!" -Foreground Green
            break
        } catch {
            if ($i -ge 12) {
                throw "Failed to call PreparePushTenant, error was $($_.Exception.Message)"
            }
            Start-Sleep -seconds 20
        }
    }

    Write-Host "Getting service info..." -foreground Yellow
    $info = $pushTenantManager.GetPushServiceInfo()
    $info.Retrieve("EndpointAddress")
    $info.Retrieve("TenantId")
    $info.Retrieve("AuthenticationRealm")
    $info.Retrieve("ValidContentEncryptionCertificates")
    $cctx.ExecuteQuery()

    Write-Host "Registered cloud hybrid search configuration:"
    $info | select TenantId,AuthenticationRealm,EndpointAddress | format-list

    if ([string]::IsNullOrEmpty($info.EndpointAddress)) {
        throw "No indexing service endpoint found!"
    }

    if ($info.ValidContentEncryptionCertificates -eq $null) {
        Write-Warning "No valid encryption certificate found."
    }

    if ($AADRealm -ne $info.AuthenticationRealm) {
        throw "Unexpected mismatch between realm ids read from Get-MsolCompanyInformation ($AADRealm) and GetPushServiceInfo ($($info.AuthenticationRealm))."
    }

    Write-Host "Configuring Cloud SSA..." -foreground Yellow
    $ssa.SetProperty("CertServerURL", $PortalUrl)
    $ssa.SetProperty("HybridTenantID", $info.TenantId)
    $ssa.SetProperty("AuthRealm", $info.AuthenticationRealm)
    $ssa.Update()

    Write-Host "Restarting SharePoint Timer Service..." -foreground Yellow
    Stop-Service SPTimerV4
    Write-Host "Restarting SharePoint Server Search..." -foreground Yellow
    if ($SP_VERSION -eq "15") {
        Restart-Service OSearch15
    } else {
        Restart-Service OSearch16
    }
    Start-Service SPTimerV4

    Write-Host "All done!" -foreground Green
}
catch
{
    Write-Error -ErrorRecord $_
    Write-Host "It is safe to re-run onboarding if you believe this error is transient." -Foreground Yellow
    return
}

# SIG # Begin signature block
# MIIj0wYJKoZIhvcNAQcCoIIjxDCCI8ACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAQUlMbu/E/C+ZX
# e+HCh8TNhhw7u51NvArv33Ob8KpI76CCDYEwggX/MIID56ADAgECAhMzAAABh3IX
# chVZQMcJAAAAAAGHMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAwMzA0MTgzOTQ3WhcNMjEwMzAzMTgzOTQ3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOt8kLc7P3T7MKIhouYHewMFmnq8Ayu7FOhZCQabVwBp2VS4WyB2Qe4TQBT8aB
# znANDEPjHKNdPT8Xz5cNali6XHefS8i/WXtF0vSsP8NEv6mBHuA2p1fw2wB/F0dH
# sJ3GfZ5c0sPJjklsiYqPw59xJ54kM91IOgiO2OUzjNAljPibjCWfH7UzQ1TPHc4d
# weils8GEIrbBRb7IWwiObL12jWT4Yh71NQgvJ9Fn6+UhD9x2uk3dLj84vwt1NuFQ
# itKJxIV0fVsRNR3abQVOLqpDugbr0SzNL6o8xzOHL5OXiGGwg6ekiXA1/2XXY7yV
# Fc39tledDtZjSjNbex1zzwSXAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhov4ZyO96axkJdMjpzu2zVXOJcsw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU4Mzg1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAixmy
# S6E6vprWD9KFNIB9G5zyMuIjZAOuUJ1EK/Vlg6Fb3ZHXjjUwATKIcXbFuFC6Wr4K
# NrU4DY/sBVqmab5AC/je3bpUpjtxpEyqUqtPc30wEg/rO9vmKmqKoLPT37svc2NV
# BmGNl+85qO4fV/w7Cx7J0Bbqk19KcRNdjt6eKoTnTPHBHlVHQIHZpMxacbFOAkJr
# qAVkYZdz7ikNXTxV+GRb36tC4ByMNxE2DF7vFdvaiZP0CVZ5ByJ2gAhXMdK9+usx
# zVk913qKde1OAuWdv+rndqkAIm8fUlRnr4saSCg7cIbUwCCf116wUJ7EuJDg0vHe
# yhnCeHnBbyH3RZkHEi2ofmfgnFISJZDdMAeVZGVOh20Jp50XBzqokpPzeZ6zc1/g
# yILNyiVgE+RPkjnUQshd1f1PMgn3tns2Cz7bJiVUaqEO3n9qRFgy5JuLae6UweGf
# AeOo3dgLZxikKzYs3hDMaEtJq8IP71cX7QXe6lnMmXU/Hdfz2p897Zd+kU+vZvKI
# 3cwLfuVQgK2RZ2z+Kc3K3dRPz2rXycK5XCuRZmvGab/WbrZiC7wJQapgBodltMI5
# GMdFrBg9IeF7/rP4EqVQXeKtevTlZXjpuNhhjuR+2DMt/dWufjXpiW91bo3aH6Ea
# jOALXmoxgltCp1K7hrS6gmsvj94cLRf50QQ4U8Qwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVqDCCFaQCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAYdyF3IVWUDHCQAAAAABhzAN
# BglghkgBZQMEAgEFAKCB7zAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgAGCQmEpl
# Gg3tF46CMH5cyVGtsjiPia37kv+6dQjud+kwgYIGCisGAQQBgjcCAQwxdDByoFaA
# VABTAGgAYQByAGUAUABvAGkAbgB0ACAAUwBlAGEAcgBjAGgAIABIAGUAYQBsAHQA
# aAAgAFIAZQBwAG8AcgB0AHMAIABEAGEAcwBoAGIAbwBhAHIAZKEYgBZodHRwczov
# L21pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEBAQUABIIBAIrzCIA5gULyI63hEgZN
# AeDQN4c0HEZ4e3186R3t/lP5WbwtW5Ap1pVdamHBthDBjCrTvYADEz9V+blrcADk
# hJi99RlrRv5f76NThbZTpyRbZOxW+u2SDlYBgODas1Da7YdRgX42rV4orEqeB8YT
# LZ/xTyPdwuxmEknqi8Ksg5dEgOuzsDddbPQy0JytJ/EDbqq19K4JGa6Pcu2CXMSH
# J8TNlGuUuJP2kyk7UJXgqLB19kcWrKNH37YhFxRvG4oGtPV4ZTy/sNQV2LiRyHQd
# t56pwZ2jtywxebdKRwO+PKGI3Z5VyWovc/VWQJI1GrBRlNntJk6luM/1leBd3E8i
# stKhghLxMIIS7QYKKwYBBAGCNwMDATGCEt0wghLZBgkqhkiG9w0BBwKgghLKMIIS
# xgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYLKoZIhvcNAQkQAQSgggFEBIIBQDCC
# ATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQgivGZs94jZh7x89x3
# HZ63iEceK8VzJVoF00Td2tPl1m4CBl9hGpL65RgTMjAyMDA5MjIxMzU0MTguNTgy
# WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28x
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjQ2MkYtRTMxOS0zRjIwMSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIORDCCBPUwggPdoAMCAQIC
# EzMAAAEky80CoRdwXJoAAAAAASQwDQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwHhcNMTkxMjE5MDExNDU3WhcNMjEwMzE3MDExNDU3
# WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UE
# CxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOjQ2MkYtRTMxOS0zRjIwMSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEAkJsqOA2eGO8yWdE0C3Htfc3llmRJ9QVQvJaxUnWmfIyxIhOKaDWrc5DUiR/T
# /eCDxQblMhGbvAfyyMG2gHee7MXPXUJ6AgVxqdie3TnQm+etRMp4A9RHmkulN4/d
# ASAv4JY5ziVOD9fGOdC/TUUPtNOf0MS47eSnQZDzsyN3myzErQrWrghY0UDJGnHm
# fxWbdWbWKJUvkUwNQqyXkb9KpB2IQOfxyphupYxXNYf3g90p3DWYgdOgFEI2xH0E
# cdbM2RJL5HRZGKkFJKispPty4uUQFiEOjwBje4waW/SQtEscBJn6zPad+SlbYJW3
# 5seFWYzr/mqK7Z/t5ihNgm5wUQIDAQABo4IBGzCCARcwHQYDVR0OBBYEFLsd0XKs
# YoiEPG/KksDWUP/AZFKwMB8GA1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kv
# Y3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEF
# BQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQC
# MAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggEBAGjdDM24
# 1GDN1+XADhTt/d7YJwaXB2DqKLj3xwGJKtOlYo7eqrPmm+AcCTiGHrL8UtjzRHn2
# KcvBxW7IPbhLckR1KJ7jLW0Lkmm3B5HWqXFEkJEzi8buc+0gLh4AwpxeCi+7SZMW
# /vGkUBWlG6+56lH3WAh17fbyW/UdNMkJX8sEGTzdeLucIY8Xn0XF4itwTfbG3hgm
# ASkQCKR4yq9YJMzI+qWa/H0n3Z/FTdxBzDaPYRbCo4PlPc3PYdZ89XzSyKEPUDpj
# keGOlL21oM+zsIjnwjbXUXfKx6A3I56wbcxOtIkfI8wspgUPFwbWd5XSWKS2/5Nb
# 3buxQ5VzNxJSFAswggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEB
# CwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYD
# VQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAe
# Fw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0N
# vHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycE
# MR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1
# R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxG
# wScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/Q
# S/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38
# vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYD
# VR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1
# AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaA
# FNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8y
# MDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAt
# MDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9Bggr
# BgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9k
# ZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABp
# AGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEA
# B+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9
# x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9C
# EMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP
# 7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoL
# kSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4E
# QoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQ
# zafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5h
# a293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3q
# jeAzLhIp9cAvVCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99j
# e/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8
# z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P3nSISRKhggLSMIICOwIBATCB/KGB
# 1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcG
# A1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsT
# HVRoYWxlcyBUU1MgRVNOOjQ2MkYtRTMxOS0zRjIwMSUwIwYDVQQDExxNaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQCXA+U0Kr5SfnhR
# /Et7/ApLVdzieqCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MA0GCSqGSIb3DQEBBQUAAgUA4xQqjjAiGA8yMDIwMDkyMjExNDcyNloYDzIwMjAw
# OTIzMTE0NzI2WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDjFCqOAgEAMAoCAQAC
# AiGUAgH/MAcCAQACAhBSMAoCBQDjFXwOAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwG
# CisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEF
# BQADgYEAcLxgbuGxPAgfTcoYg3v8tUI1EjAg7P1rzGW5YFzMp126b0zgURzjrFf8
# CzjGcYS04M/PC+EVqQziCNSeHAq7bZgttYbkNmLWSseWIcqvJVKf+T/69SBW3ZVv
# fk2LdAF0LS+6ai0Ln+i1CrXax5lv3SkpY73KRmp5Jgxr7BUFwmAxggMNMIIDCQIB
# ATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAASTLzQKhF3Bc
# mgAAAAABJDANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3
# DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCD5nA/Dqra3lACpaBjkos4zRa9b6AG07XIZ
# HSdtc+dYOjCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIGI44eiiGov5ftdr
# /bmOnXBOtDFiVgYuzOKz+cBOKuMgMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgUENBIDIwMTACEzMAAAEky80CoRdwXJoAAAAAASQwIgQgFAFpI5CTPOaLBjXz
# 5MJtN5PFHRKzmZ0RKDVEwaLxJWYwDQYJKoZIhvcNAQELBQAEggEAdxeed0aZtM0V
# 8crS7pvrmaPHvy3kvSBMRvpe0Xl52lwsnh68hEYykPbCxf8wsC8V/IpyqrfAt/4c
# 6fX8ypW1KPtdh2oXyvuvEtt7h92TYRkrMbapbbWcwICX+XbOGQ091/8euiU3bv0R
# /5mnj2GAINiliaEo55Y1OsR3PEtEmEz0TQZiX4frIEyWZ0zXiGo0UCUObXfoz13q
# CZhO1W1JF+aHSyvvATitbK2bvVfGPH9yp6mzVB438AEMKv4muuADYRc79OqsfUzN
# HSXZ8mrBUouWvggW/GmPFO48ua/UuYSjm3Pu/nhY/Pj9K97BWoG4Zpb1mhHj/9b7
# T+XieWnMgA==
# SIG # End signature block

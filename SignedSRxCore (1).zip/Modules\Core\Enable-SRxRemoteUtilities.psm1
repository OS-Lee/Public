#=============================================
# Project		: Search Health Reports (SRx)
#---------------------------------------------
# File Name 	: Enable-SRxRemoteUtilities.psm1
# Author		: Eric Dixon, Brian Pendergrass
# Requires: 
#	PowerShell Version 3.0, Search Health Reports (SRx), Microsoft.SharePoint.PowerShell
#
#==========================================================================================
# This Sample Code is provided for the purpose of illustration only and is not intended to 
# be used in a production environment.  
#
#	THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY
#	OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
#	WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
#
# We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to 
# reproduce and distribute the object code form of the Sample Code, provided that You agree:
#	(i) to not use Our name, logo, or trademarks to market Your software product in 
#		which the Sample Code is embedded; 
#	(ii) to include a valid copyright notice on Your software product in which the 
#		 Sample Code is embedded; 
#	and 
#	(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against
#		  any claims or lawsuits, including attorneys' fees, that arise or result from 
#		  the use or distribution of the Sample Code.
#
#==========================================================================================

function Enable-SRxRemoteTool 
{
<#
.SYNOPSIS

.DESCRIPTION

.INPUTS
	
.NOTES

#>
[CmdletBinding()]
param ( 
    [parameter(Mandatory=$true,ValueFromPipeline=$true)]
    $TargetServer,
    [parameter(Mandatory=$true)]
    $ToolName,
    $ToolExe,
    [Object[]]$ToolSupportFiles=@()
)

BEGIN {
    if(-not $global:SRxEnv.RemoteUtilities) {
        $global:SRxEnv.PersistCustomProperty("RemoteUtilities", $(New-Object PSObject))
    }

    $global:OldDriveLetter = $null
    if(AddRemoteTool -ToolName $ToolName) {
        $TargetDrive = GetToolDriveLetter -ToolName $ToolName
	    $status = $true
    } else {
		$status = $false
		return $status
	}

    # add tool to handle map
    if(-not $global:SRxEnv.RemoteUtilities.$ToolName) {
        $o = New-Object PSObject -Property @{
            Initialized=$false;
            Exe=$ToolExe;
            SupportFiles=$ToolSupportFiles;
            Drive=$TargetDrive;
            Servers=@();
        }
        $global:SRxEnv.PersistCustomProperty("RemoteUtilities.$ToolName", $o)
    }

    $serversToAdd = New-Object System.Collections.ArrayList
}

PROCESS {
	if($status -eq $false) {
		return
	}
    # todo: create function member on object
    Write-SRx INFO ("Enabling Remote Utility $ToolName on $($TargetServer.Name)...") -ForegroundColor Cyan 

    $serversToAdd.Add($TargetServer.name) | Out-Null

    try {
        # create folders on target server
        $ScriptBlock = { 
            param([string]$newToolPath)
            New-Item -Path (Join-Path $newToolPath "bin") -type directory -Force | Out-Null
            New-Item -Path (Join-Path $newToolPath "var") -type directory -Force | Out-Null
        }

        $toolPath = GetToolPath -ToolName $ToolName
        Write-SRx INFO ("Copying $ToolName executables to '$toolPath' on $($TargetServer.Name)...") -ForegroundColor Cyan 
        if($env:COMPUTERNAME -eq $TargetServer.Name){
            Invoke-Command -ScriptBlock $ScriptBlock -ArgumentList(,$toolPath)
        } else {
            try{
                Invoke-Command -ComputerName $TargetServer.Name -ScriptBlock $ScriptBlock -ArgumentList(,$toolPath) -ErrorAction Stop
            }catch{
                # connect to the computer from client using kerberos as the current user:
                Invoke-Command -ComputerName $TargetServer.Name -ScriptBlock $ScriptBlock -ArgumentList(,$toolPath) -Authentication NegotiateWithImplicitCredential �
            }
        }

        $toolPath = (GetToolPath -ToolName $ToolName).Replace(":","$")
        $toolPathBin = (Join-Path $toolPath "bin") 
        $destPath = Join-Path "\\$($TargetServer.Name)" $toolPathBin

        # copy files to target server
        Copy-Item (Join-Path $global:SRxEnv.Paths.Tools  $global:SRxEnv.RemoteUtilities.$ToolName.Exe) $destPath -Force -Recurse
        foreach($supportFile in $global:SRxEnv.RemoteUtilities.$ToolName.SupportFiles){
            Copy-Item (Join-Path $global:SRxEnv.Paths.Tools $supportFile) $destPath -Force -Recurse
        }
        $global:SRxEnv.PersistCustomProperty("RemoteUtilities.$ToolName.Initialized", $true)
    } catch {
        Write-SRx ERROR "Failed to create folders and copy files for $ToolName on $($TargetServer.Name)"
        Write-SRx DEBUG "Caught Exception"
        Write-SRx DEBUG "$_"
        $global:SRxEnv.PersistCustomProperty("RemoteUtilities.$ToolName.Initialized", $false)
        $status = $false
    }
}

END {
	if($status) {
        Write-SRx INFO ("Completed enabling $ToolName.") -ForegroundColor Cyan 

        $servers = $global:SRxEnv.RemoteUtilities.$ToolName.Servers
        $newServers = New-Object System.Collections.ArrayList

        foreach($s in $serversToAdd){
            if(-not ($servers -contains $s)) {
                $newServers.Add($s) | Out-Null
            }
        }
        $newServers.AddRange($servers) | Out-Null
        $global:SRxEnv.PersistCustomProperty("RemoteUtilities.$ToolName.Servers", $newServers)
	}

    return $status
}
}



function AddRemoteTool 
{
[CmdletBinding()]
param ( 
    [parameter(Mandatory=$true)]
    $ToolName
)

	if($global:SRxEnv.RemoteUtilities.$ToolName.Initialized)
	{
        Write-SRx VERBOSE "$ToolName is initialized."
	}
    else
    {
		$yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes","Copy $ToolName to servers."
		$no = New-Object System.Management.Automation.Host.ChoiceDescription "&No","Do not copy $ToolName."
		$options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)

        Write-Host "The SRx Dashboard can run utilites on remote servers." -BackgroundColor DarkCyan -ForegroundColor White
        Write-Host "Enabling $ToolName implies you accept the EULA for this tool." -BackgroundColor DarkCyan -ForegroundColor White
		$title = "" 
		$message = "Do you want to enable $ToolName for SRx Dashboard?"
		$result = $host.ui.PromptForChoice($title, $message, $options, 1)
		switch ($result) 
		{
			0 { Write-Host "Yes";}
			1 { Write-Host "No"; return $false }
		}

		$yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes","Copy $ToolName to servers."
		$no = New-Object System.Management.Automation.Host.ChoiceDescription "&No","Do not copy $ToolName."
		$options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)

        Write-Host "The $ToolName utility needs to be copied to each server in the search farm." -BackgroundColor DarkCyan -ForegroundColor White
		$title = "" 
		$message = "Do you want to copy the $ToolName utility to each server in the farm?"
		$result = $host.ui.PromptForChoice($title, $message, $options, 1)
		switch ($result) 
		{
			0 { Write-Host "Yes";}
			1 { Write-Host "No"; return $false }
		}

    }

    return $true
}



function GetToolDriveLetter
{
[CmdletBinding()]
param ( 
    [parameter(Mandatory=$true)]
    $ToolName
)
    $done = $false
    while(-not $done)
    {
	    Write-Host "Please specify a drive letter that exists on all search servers in the farm" -BackgroundColor DarkCyan -ForegroundColor White
	    Write-Host "where SRx will do all remote utilite file operations for $ToolName." -BackgroundColor DarkCyan -ForegroundColor White
	    while(-not ($driveLetter -match '^[a-zA-Z][:(:\\)]*$'))
	    {
		    Write-Host "Specify an existing drive." -BackgroundColor DarkCyan -ForegroundColor White
		    $driveLetter = Read-Host ">> Drive letter"
	    }
        $driveLetter = ($driveLetter.trim().ToUpper())[0]

	    $yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes","Accept"
	    $no = New-Object System.Management.Automation.Host.ChoiceDescription "&No","Re-enter"
	    $options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
	    $title = "" 
	    $message = "You have entered '$driveLetter'. Is this correct?"
	    $result = $host.ui.PromptForChoice($title, $message, $options, 0)
	    switch ($result) 
	    {
		    0 { Write-Host "Yes"; return $driveLetter}
		    1 { Write-Host "No"; $driveLetter = "";$done = $false }
	    }
    }
}


function GetToolPath
{
    param([string]$ToolName)
    return "$($global:SRxEnv.RemoteUtilities.$ToolName.Drive):\SRx\RemoteUtilities\$ToolName"
}

function IsEnabledRemoteTool {
[CmdletBinding()]
param ( 
    [parameter(Mandatory=$true)]
    $ToolName,
    [parameter(Mandatory=$true)]
    $TargetServer
)
    if($global:SRxEnv.RemoteUtilities.$ToolName.Initialized) {
        $servers = $global:SRxEnv.RemoteUtilities.$ToolName.Servers
        # check for .exe, .dll files and bin, var dirs
        $utilitiesFolder = Join-Path $("\\" + $TargetServer.Name) (GetToolPath -ToolName $ToolName)
        $utilitiesFolder = $utilitiesFolder.Replace(':','$')
        $binFolder = Join-Path $utilitiesFolder "bin"
        $varFolder = Join-Path $utilitiesFolder "var"

        $enable = $false
        if(-not ($servers -contains $TargetServer.Name)) {
            Write-SRx Verbose ("[IsEnabledRemoteTool] Server Not Initialized " + $TargetServer.Name) -ForegroundColor Magenta
            $enable = $true
        } elseif(-not (Test-Path (Join-Path $binFolder ($global:SRxEnv.RemoteUtilities.$ToolName.Exe)))) {
            Write-SRx Verbose ("[IsEnabledRemoteTool] " + $global:SRxEnv.RemoteUtilities.$ToolName.Exe + " not found on " + $TargetServer.Name) -ForegroundColor Magenta
            $enable = $true    
        } elseif(-not (Test-Path $varFolder)) {
            Write-SRx Verbose ("[IsEnabledRemoteTool] var folder not found on " + $TargetServer.Name) -ForegroundColor Magenta
            $enable = $true    
        } else {
            $supportFiles = $global:SRxEnv.RemoteUtilities.$ToolName.SupportFiles
            foreach($f in $supportFiles){
                if(-not (Test-Path (Join-Path $binFolder $f))) {
                    Write-SRx Verbose ("[IsEnabledRemoteTool] Support file " + $f + " not found on " + $TargetServer.Name) -ForegroundColor Magenta
                    $enable = $true
                    break
                }
            }
        }

        if($enable){
			Write-SRx Verbose "[IsEnabledRemoteTool] Enabling $ToolName on $($TargetServer.Name)..."-ForegroundColor Magenta
            $TargetServer | Enable-SRxRemoteTool -ToolName $ToolName
        }

        return $true
    }

    return $false
}

function Invoke-SRxRemoteTool 
{
<#
.SYNOPSIS

.DESCRIPTION

.INPUTS
	
.NOTES

#>
[CmdletBinding()]
param ( 
    [parameter(Mandatory=$true,ValueFromPipeline=$true,Position=0)]
    $TargetServer,
    [parameter(Mandatory=$true)]
    $ToolName,
    [parameter(Mandatory=$true)]
    [Scriptblock]$CmdBlock,
    [parameter(Mandatory=$true)]
	[Hashtable]$InputParams=@{},
    [parameter(Mandatory=$false)]
	[Object[]]$OutputParams
)
    BEGIN {
        if(-not $SRxEnv.RemoteUtilities.$ToolName){
            throw [System.NullReferenceException] "RemoteUtilities configuration for '$ToolName' not found in `$SRxEnv"
        }

        # to be tricky like Brian
        $HasDebugFlag = ($PSCmdlet.MyInvocation.BoundParameters["Debug"].IsPresent -or $global:SRxEnv.Log.Level -eq "Debug")

        $startTime = Get-Date

        # job list
        $jobList = New-Object System.Collections.ArrayList

        # if utf 8 is enabled, it will put a BOM on the script block input for Start-Job and break it
        # this is not a problem with the ISE, check our host name
	    if ($Host.Name -eq "ConsoleHost") {
            if([system.console]::InputEncoding -is [Text.UTF8Encoding]){
		        [system.console]::InputEncoding= New-Object Text.UTF8Encoding $false
            }
        }
        $jobGUID = [guid]::NewGuid()
        $destPath = New-Item -Path (Join-Path $global:SRxEnv.Paths.Tmp $jobGUID) -type directory -Force
        Write-SRx INFO "[Invoke-SRxRemoteTool][$ToolName] Invoking command with JobId: $($jobGUID)" -ForegroundColor Cyan

        $ToolPath = GetToolPath -ToolName $ToolName
    }
    PROCESS{
        if (-not $TargetServer.canPing()) {
            Write-SRx ERROR "[Invoke-SRxRemoteTool][$ToolName] Unable to ping $($TargetServer.Name)"
        } elseif (IsEnabledRemoteTool -Tool $ToolName -TargetServer $TargetServer) {
            $jobBlock = {
                param([string]$ToolName,[string]$ToolPath,[string]$TargetServerName,[string]$ToolNameExe,[string]$jobGUID,[string]$destPath,[string]$cmdBlock,[Hashtable]$inParams,[Object[]]$outParams,[bool]$HasDebugFlag)

                $logfile = Join-Path $destPath "job-$TargetServerName-debug.log"
			    if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Entered Job block." | Add-Content -Path $logfile }

                $cmdBlock2 = {
                    param([string]$varpath,[string]$guid,[bool]$debug)
                    $zipfile = Join-Path $varpath "$($env:COMPUTERNAME)-$guid.zip"
                    $outpath = Join-Path $varpath $guid
                    if($debug) {
                        $logfile = Join-Path $varPath "$guid.log"
        			    "Creating zip file $zipfile from $outpath" | Add-Content -Path $logfile
                    }
                    Add-Type -Assembly System.IO.Compression.FileSystem
                    $compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
                    [System.IO.Compression.ZipFile]::CreateFromDirectory($outpath, $zipfile, $compressionLevel, $false)
                }

                $cmdBlock3 = {
                    param([string]$varpath,[string]$guid,[bool]$debug)
                    $zipfile = Join-Path $varpath "$($env:COMPUTERNAME)-$guid.zip"
                    if (-not $debug) {
                        $outpath = Join-Path $varpath $guid
                        Remove-Item $outpath -Recurse -Confirm:$false -Force
                        Remove-Item $zipfile -Confirm:$false -Force
                    } 
                }


                try{
                    $binPath = Join-Path $ToolPath "bin"
                    $exefile = Join-Path $binPath $ToolNameExe
                    $varPath = Join-Path $ToolPath "var"
                    $outpath = Join-Path $varpath $jobGUID
                    $zipfile = Join-Path $varpath "$($TargetServerName)-$jobGUID.zip"
                    $zipPath = (Join-Path "\\$($TargetServerName)" $zipfile).Replace(':','$')

					if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Invoking command on $($TargetServerName)..." | Add-Content -Path $logfile }
					if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Invoking command block: $cmdBlock" | Add-Content -Path $logfile }
                    $cmdBlock1 = [Scriptblock]::Create($cmdBlock)

                    if ($TargetServerName -eq $ENV:ComputerName) {
                        $job1Obj = Invoke-Command -ScriptBlock $cmdBlock1 -ArgumentList($TargetServerName,$ToolName,$exefile,$varpath,$jobGUID,$inParams,$outParams,$HasDebugFlag) 
                        
					    if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Compressing files on $($TargetServerName)..." | Add-Content -Path $logfile }
                        $job2Obj = Invoke-Command -ScriptBlock $cmdBlock2 -ArgumentList($varPath,$jobGUID,$HasDebugFlag) 

					    if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Copying files from $($TargetServerName)..." | Add-Content -Path $logfile }
                        Copy-Item -Path $zipPath -Destination $destPath

					    if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Done copying files from $($TargetServerName)." | Add-Content -Path $logfile }
                        if(-not $HasDebugFlag) {
                            #clean up files on remote servers
                            $job3Obj = Invoke-Command -ScriptBlock $cmdBlock3 -ArgumentList($varPath,$jobGUID,$HasDebugFlag) 
                        }
                    } else {
                        try{
                            $job1Obj = Invoke-Command -ComputerName $TargetServerName -ScriptBlock $cmdBlock1 -ArgumentList($TargetServerName,$ToolName,$exefile,$varpath,$jobGUID,$inParams,$outParams,$HasDebugFlag)  -ErrorAction Stop
                            
					        if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Compressing files on $($TargetServerName)..." | Add-Content -Path $logfile }
                            $job2Obj = Invoke-Command -ComputerName $TargetServerName -ScriptBlock $cmdBlock2 -ArgumentList($varPath,$jobGUID,$HasDebugFlag) 

					        if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Copying files from $($TargetServerName)..." | Add-Content -Path $logfile }
                            Copy-Item -Path $zipPath -Destination $destPath

                            if(-not $HasDebugFlag) {
                                $job3Obj = Invoke-Command -ComputerName $TargetServerName -ScriptBlock $cmdBlock3 -ArgumentList($varPath,$jobGUID,$HasDebugFlag)
                            } else {
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Did not clean up working files on $($TargetServerName)" | Add-Content -Path $logfile }
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Files:" | Add-Content -Path $logfile }
						        $tPath = Join-Path "\\$($TargetServerName)" (Join-Path $varpath $jobGUID)
						        $tPath = $tPath.Replace(":","$")
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool]    $tPath"  | Add-Content -Path $logfile }
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool]    $zipPath" | Add-Content -Path $logfile }
                            }
					        if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Done copying files from $($TargetServerName)." | Add-Content -Path $logfile }
                        } catch {
                            if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Caught exception.  Attempting command with Kerberos authentication..." | Add-Content -Path $logfile }

                            # connect to the computer from client using kerberos as the current user:
                            $job1Obj = Invoke-Command -ComputerName $TargetServerName -ScriptBlock $cmdBlock1 -ArgumentList($TargetServerName,$ToolName,$exefile,$varpath,$jobGUID,$inParams,$outParams,$HasDebugFlag) -Authentication NegotiateWithImplicitCredential

					        if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Compressing files on $($TargetServerName)..." | Add-Content -Path $logfile }
                            $job2Obj = Invoke-Command -ComputerName $TargetServerName -ScriptBlock $cmdBlock2 -ArgumentList($varPath,$jobGUID,$HasDebugFlag) -Authentication NegotiateWithImplicitCredential

					        if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Copying files from $($TargetServerName)..." | Add-Content -Path $logfile }
                            Copy-Item -Path $zipPath -Destination $destPath

                            if(-not $HasDebugFlag) {
                                $job3Obj = Invoke-Command -ComputerName $TargetServerName -ScriptBlock $cmdBlock3 -ArgumentList($varPath,$jobGUID,$HasDebugFlag) -Authentication NegotiateWithImplicitCredential
                            } else {
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Did not clean up working files on $($TargetServerName)" | Add-Content -Path $logfile }
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Files:" | Add-Content -Path $logfile }
						        $tPath = Join-Path "\\$($TargetServerName)" (Join-Path $varpath $jobGUID)
						        $tPath = $tPath.Replace(":","$")
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool]    $tPath"  | Add-Content -Path $logfile }
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool]    $zipPath" | Add-Content -Path $logfile }
                            }
					        if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Done copying files from $($TargetServerName)." | Add-Content -Path $logfile }

                        }
                    }

                    if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Completed invoked $ToolName command on $($TargetServerName) with job id $($jobGUID)." | Add-Content -Path $logfile }

                } catch {
                    $errorfile = Join-Path $destPath "error.log"
                    "[Invoke-SRxRemoteTool] Caught exception while invoking $ToolName command on $($TargetServerName)" | Add-Content -Path $errorfile
                    "Exception:" | Add-Content -Path $errorfile 
                    "$_" | Add-Content -Path $errorfile 
                }
            }

            Write-SRx INFO "[Invoke-SRxRemoteTool][$ToolName] Invoking tool on $($TargetServer.Name)."
            if($HasDebugFlag) {Write-Host "Creating debug file in $destPath"}
            try {
                    $job = Start-Job -Name $TargetServer.Name -ScriptBlock $jobBlock -ArgumentList $($ToolName,$ToolPath,$TargetServer.Name,$global:SRxEnv.RemoteUtilities.$ToolName.Exe,$jobGUID,$destPath,$CmdBlock.ToString(),$InputParams,$OutputParams,$HasDebugFlag)
#                    $job = Start-Job -Name $TargetServer.Name -ScriptBlock $jobBlock -ArgumentList $($jobGUID,$destPath,$InputParams,$HasDebugFlag)
                    $jobList.Add($job) | Out-Null
            } catch {
                Write-SRx ERROR "[Invoke-SRxRemoteTool][$ToolName] Caught exception when starting job."
                Write-SRx ERROR "$job"
                Write-SRx ERROR "[Invoke-SRxRemoteTool][$ToolName] Exception:"
                Write-SRx ERROR "$_"
            }
        } else {
            Write-SRx ERROR "[Invoke-SRxRemoteTool][$ToolName] Unable to invoke tool. The Remote Utility '$ToolName' is not enabled."
        }
    }
    END {
        WaitForJobs -Jobs $jobList

        Write-SRx VERBOSE "[Invoke-SRxRemoteTool][$ToolName] Done collecting data. Extracting..." 
        Add-Type -Assembly System.IO.Compression.FileSystem
        $zipfiles = Get-ChildItem $destPath -Filter "*.zip"
        foreach($f in $zipfiles) {
            [System.IO.Compression.ZipFile]::ExtractToDirectory($f.FullName, $destPath)
            if(-not $HasDebugFlag) {
                $f.Delete()
            }
        }

#        $files = Get-ChildItem $destPath -Filter "$ToolName-*.log"
        $files = Get-ChildItem $destPath 
        $sum = $files | Measure-Object -Property Length -Sum
        $t = $(Get-Date) - $startTime
        if($sum.Sum -gt 1GB) {
            $size = "$("{0:N2}" -f ($sum.Sum/1GB)) GB"
        } elseif($sum.Sum -gt 1MB) { 
            $size = "$("{0:N2}" -f ($sum.Sum/1MB)) MB"
        } else{ 
            $size = "$("{0:N2}" -f ($sum.Sum/1KB)) KB"
        }
        Write-SRx INFO "[Invoke-SRxRemoteTool][$ToolName] Collected $($files.Count) files totaling $size in $("{0:N2}" -f $t.TotalMinutes) minutes." -ForegroundColor DarkGray


        # if this is a console (not ISE) reset input encoding back to utf8
        # if utf 8 is enabled, it will put a BOM on the script block input for Start-Job and break it
	    if ($Host.Name -eq "ConsoleHost") {
            if([system.console]::InputEncoding -isnot [Text.UTF8Encoding]) {
                [system.console]::InputEncoding=[System.Text.Encoding]::UTF8
            }
        }

        return $files
    }
}

Function WaitForJobs
{
    param(
        [parameter(Mandatory=$true)]
	    [Object[]]$Jobs,
        [switch]$DoNotRemoveJobs
    )

    if($Jobs.Count -eq 0) {
        Write-SRx VERBOSE "[Invoke-SRxRemoteTool][$ToolName] No Jobs found." 
        return
    } else {
        Write-SRx VERBOSE "[Invoke-SRxRemoteTool][$ToolName] Waiting for Jobs..." 
    }

    Write-SRx INFO "[Invoke-SRxRemoteTool][$ToolName] Created $($jobs.Count) Jobs to collect data. Waiting..." -ForegroundColor Cyan 

    $done = $false
    while(-not $done)
    {
        $completed = $jobs | ? { $_.State -eq "Completed" -or $_.State -eq "Failed" } 
        $count = $completed.Count
        $p = [System.Convert]::ToInt32(($count/$($jobs.Count) * 100))
        Write-Progress -Id 2 -Activity "Waiting for remote jobs... This will take a few minutes." -Status "[$ToolName] - $count of $($jobs.Count) jobs complete"  -PercentComplete $p
        Start-Sleep -Seconds 1
        if($count -ge $jobs.Count){$done = $true}
    }
    Write-Progress -Id 2 -Activity "Waiting for remote jobs... This will take a few minutes." -Completed

    $failedJobs = $jobs | ? { $_.State -eq "Failed" } 
    $failedJobs | % { Write-SRx WARNING "[Invoke-SRxRemoteTool][$ToolName] Job failed on server $($_.Name)"; if($HasDebugFlag){Write-SRx ERROR "$(Receive-Job $_)" }}
    if($failedJobs.Count -eq 0) {
        Write-SRx INFO "[Invoke-SRxRemoteTool][$ToolName] All Jobs completed successfully." -ForegroundColor Green
    }
    if(-not $DoNotRemoveJobs){
        Write-SRx INFO " * [Invoke-SRxRemoteTool][$ToolName] Keeping jobs." -ForegroundColor DarkGray
        $jobs | Remove-Job
    }
}


function Remove-SRxRemoteTool 
{
<#
.SYNOPSIS

.DESCRIPTION

.INPUTS
	
.NOTES

#>
[CmdletBinding()]
param ( 
    [parameter(Mandatory=$true,ValueFromPipeline=$true)]
    $TargetServer,
    [parameter(Mandatory=$true)]
    $ToolName
)
}

function Invoke-SRxRemotePowerShellJobs
{
    [CmdletBinding()]
    param ( 
        [parameter(Mandatory=$true,ValueFromPipeline=$true)]
        $TargetServer,
        [parameter(Mandatory=$true)]
        $Cmdlet
    )
    BEGIN {
        # to be tricky like Brian
        $HasDebugFlag = ($PSCmdlet.MyInvocation.BoundParameters["Debug"].IsPresent -or $global:SRxEnv.Log.Level -eq "Debug")

        $ToolName = $Cmdlet
        Write-SRx INFO "[Invoke-SRxRemotePowerShellJobs][$ToolName] Invoking commands" -ForegroundColor Cyan

        $startTime = Get-Date

        # job list
        $jobList = New-Object System.Collections.ArrayList

        # if utf 8 is enabled, it will put a BOM on the script block input for Start-Job and break it
        # this is not a problem with the ISE, check our host name
	    if ($Host.Name -eq "ConsoleHost") {
            if([system.console]::InputEncoding -is [Text.UTF8Encoding]){
		        [system.console]::InputEncoding= New-Object Text.UTF8Encoding $false
            }
        }
    }
    PROCESS {
        if (-not $TargetServer.canPing()) {
            Write-SRx ERROR "[Invoke-SRxRemotePowerShellJobs][$ToolName] Unable to ping $($TargetServer.Name)"
        } else {
            Write-SRx INFO "[Invoke-SRxRemotePowerShellJobs][$ToolName] Invoking command on $($TargetServer.Name)."
            if($TargetServer.Name -eq $env:COMPUTERNAME){
                $job = Start-Job -ScriptBlock {param($cmd); . $cmd} -ArgumentList ($Cmdlet) -Name $TargetServer.Name;
                $jobList.Add($job) | Out-Null
            } else {
                $job = Invoke-Command -ComputerName $TargetServer.Name -ScriptBlock {param($cmd);. $cmd} -ArgumentList ($Cmdlet) -AsJob -JobName $TargetServer.Name
                $jobList.Add($job) | Out-Null
            }
        }
    }
    END {
        WaitForJobs -Jobs $jobList -DoNotRemoveJobs

        $jobData = $jobList | % { New-Object PSObject -Property @{
            Name = $_.Name;
            Data = Receive-Job -Job $_ ;
        } }
        $jobList | Remove-Job | Out-Null

        $t = $(Get-Date) - $startTime
        Write-SRx INFO "[Invoke-SRxRemotePowerShellJobs][$ToolName] Ran commands on $($jobList.Count) servers in $("{0:N2}" -f $t.TotalMinutes) minutes." -ForegroundColor DarkGray

        # if this is a console (not ISE) reset input encoding back to utf8
        # if utf 8 is enabled, it will put a BOM on the script block input for Start-Job and break it
	    if ($Host.Name -eq "ConsoleHost") {
            if([system.console]::InputEncoding -isnot [Text.UTF8Encoding]) {
                [system.console]::InputEncoding=[System.Text.Encoding]::UTF8
            }
        }

        return $jobData
    }
}


Export-ModuleMember Invoke-SRxRemoteTool
Export-ModuleMember Enable-SRxRemoteTool
Export-ModuleMember Remove-SRxRemoteTool
Export-ModuleMember Invoke-SRxRemotePowerShellJobs

# SIG # Begin signature block
# MIIjxwYJKoZIhvcNAQcCoIIjuDCCI7QCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCaL/4zlUkR6Qtd
# u6tr+pdfFatIrapD5KO3dFF3untgbKCCDYEwggX/MIID56ADAgECAhMzAAABh3IX
# chVZQMcJAAAAAAGHMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAwMzA0MTgzOTQ3WhcNMjEwMzAzMTgzOTQ3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOt8kLc7P3T7MKIhouYHewMFmnq8Ayu7FOhZCQabVwBp2VS4WyB2Qe4TQBT8aB
# znANDEPjHKNdPT8Xz5cNali6XHefS8i/WXtF0vSsP8NEv6mBHuA2p1fw2wB/F0dH
# sJ3GfZ5c0sPJjklsiYqPw59xJ54kM91IOgiO2OUzjNAljPibjCWfH7UzQ1TPHc4d
# weils8GEIrbBRb7IWwiObL12jWT4Yh71NQgvJ9Fn6+UhD9x2uk3dLj84vwt1NuFQ
# itKJxIV0fVsRNR3abQVOLqpDugbr0SzNL6o8xzOHL5OXiGGwg6ekiXA1/2XXY7yV
# Fc39tledDtZjSjNbex1zzwSXAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhov4ZyO96axkJdMjpzu2zVXOJcsw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU4Mzg1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAixmy
# S6E6vprWD9KFNIB9G5zyMuIjZAOuUJ1EK/Vlg6Fb3ZHXjjUwATKIcXbFuFC6Wr4K
# NrU4DY/sBVqmab5AC/je3bpUpjtxpEyqUqtPc30wEg/rO9vmKmqKoLPT37svc2NV
# BmGNl+85qO4fV/w7Cx7J0Bbqk19KcRNdjt6eKoTnTPHBHlVHQIHZpMxacbFOAkJr
# qAVkYZdz7ikNXTxV+GRb36tC4ByMNxE2DF7vFdvaiZP0CVZ5ByJ2gAhXMdK9+usx
# zVk913qKde1OAuWdv+rndqkAIm8fUlRnr4saSCg7cIbUwCCf116wUJ7EuJDg0vHe
# yhnCeHnBbyH3RZkHEi2ofmfgnFISJZDdMAeVZGVOh20Jp50XBzqokpPzeZ6zc1/g
# yILNyiVgE+RPkjnUQshd1f1PMgn3tns2Cz7bJiVUaqEO3n9qRFgy5JuLae6UweGf
# AeOo3dgLZxikKzYs3hDMaEtJq8IP71cX7QXe6lnMmXU/Hdfz2p897Zd+kU+vZvKI
# 3cwLfuVQgK2RZ2z+Kc3K3dRPz2rXycK5XCuRZmvGab/WbrZiC7wJQapgBodltMI5
# GMdFrBg9IeF7/rP4EqVQXeKtevTlZXjpuNhhjuR+2DMt/dWufjXpiW91bo3aH6Ea
# jOALXmoxgltCp1K7hrS6gmsvj94cLRf50QQ4U8Qwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVnDCCFZgCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAYdyF3IVWUDHCQAAAAABhzAN
# BglghkgBZQMEAgEFAKCB7zAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgeugJgnqb
# g24+vvHHSd8YwGWfgyEUiQr0NfM394iby4EwgYIGCisGAQQBgjcCAQwxdDByoFaA
# VABTAGgAYQByAGUAUABvAGkAbgB0ACAAUwBlAGEAcgBjAGgAIABIAGUAYQBsAHQA
# aAAgAFIAZQBwAG8AcgB0AHMAIABEAGEAcwBoAGIAbwBhAHIAZKEYgBZodHRwczov
# L21pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEBAQUABIIBAKlKeSI+IANmdDojIrj8
# BqYI0/n27EMvf1fTB7eplpYCMa6sysReDXbgouIu9JM9TZNELsa8zkOvKmPI9Gxz
# Szs29gT0/yr2yhPqaACd8I1O53go/H/BDvv9PM697HQhqkip0MDpvDNLrR5kjlSb
# OCq/zJ+pIxcbCgx2vzqhe6qUayR6yq82Y3n1cou5XB6l0Rppo5fETtYTKowYXZit
# lY3tlR+l8E+Ica0Dtkmp1Ujpr6LRN7FQz7soT/AjobOcN/cNR6pYrAnDkBwWAAYZ
# AO//2DQfGePbSMEYDrpgJHocID06yIETO8OzSVg0hA6IJNXlIE58gignrSTheawP
# 6gihghLlMIIS4QYKKwYBBAGCNwMDATGCEtEwghLNBgkqhkiG9w0BBwKgghK+MIIS
# ugIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYLKoZIhvcNAQkQAQSgggFABIIBPDCC
# ATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQgBmQSoJC/NchJo3UH
# RZnTiBFI2sdgpi/m09OnbzDeAwkCBl9ieoCHwRgTMjAyMDA5MjIxMzU0MTguNDcy
# WjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTAr
# BgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQG
# A1UECxMdVGhhbGVzIFRTUyBFU046OEQ0MS00QkY3LUIzQjcxJTAjBgNVBAMTHE1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wggg48MIIE8TCCA9mgAwIBAgITMwAA
# AQpSyDkBUtFwSwAAAAABCjANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDAeFw0xOTEwMjMyMzE5MTVaFw0yMTAxMjEyMzE5MTVaMIHK
# MQswCQYDVQQGEwJVUzELMAkGA1UECBMCV0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0
# IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjo4RDQxLTRCRjctQjNCNzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALs+G62U
# oXDFn4Z49T9XSkyR7bXkdJfw9wtfWGNhRvIIREEWzv/ATCtvAwhl06js0OpwhSFd
# e3eTGDU6oEnG6jNVwInwnBHL9Ujv2nVl4ttK/dowzGi47Oipo0v8OZvwJP1QRyqr
# c8XXy8y/Vxl+TxmmG5VIY8zR5awm8TWR89cImxjOxm26urSMQjpcGH2Gm4pCrwpJ
# e+ioITfsRlathbLe6FEmeyt3hOrZiBizJZD9pAXbR1vvdlbAi1cbhNSXLghDSlxC
# L39Qfd+xW7Tqrz/I29zsx8hyadg5Q87IUwGHQRbnX0r+aD/FiAyG2ZmWfOa8eevm
# enMlOLBsG6GfBScCAwEAAaOCARswggEXMB0GA1UdDgQWBBT4RJSl/TpMTVDekfg6
# rQGikXGFKDAfBgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8E
# TzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBM
# MEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRz
# L01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQBUl6581BXy3dNzJarR
# K7edVhl91FxXqKxOnRmPmCMEpnxUSkTcBHvHJi7dBDsXs8k1evv33WE8qz3Dw74E
# d5OhebB3ihMaIY66nI8QGt8lUPUiWWpF2VSs2h1s27zLgPJHJs49Cf2Ov6ZOe2hb
# Kf5K/pbuWjXcOVd1oIrSWKcBOn6GULAa00zzUYSF1TB5zxJOrNvu5wuk8vWSyCYW
# HjMqi7orSRirxIkYQ/D2M5BiZy5I6etSAg5P9NGVWb75Vy6J7Yd9maKHmff/u+tK
# PYNpVIRfKGixwgdYvNnVAoV3c2bpVBMEOQmVofFiI0GUlLrzjtb1dBXzqnTcHA8l
# 7hXSMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWlj
# cm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAx
# MjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8
# E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3O
# CROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJY
# YEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIa
# IYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo
# 8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhac
# AQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTV
# YzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+ii
# XGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0y
# My5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNy
# dDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEW
# MWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5o
# dG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBT
# AHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbg
# mD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzt
# a1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/y
# N31aPxzymXlKkVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8
# tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpx
# Y517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4
# ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/Dh
# O3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJ
# rDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXA
# L1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8ch
# r1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQ
# NdrvCScc1bN+NR4Iuto229Nfj950iEkSoYICzjCCAjcCAQEwgfihgdCkgc0wgcox
# CzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQg
# SXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1Mg
# RVNOOjhENDEtNEJGNy1CM0I3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQA5vXalcdF/7lGtFXJFduIaaGPe+aCB
# gzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEB
# BQUAAgUA4xQ5EDAiGA8yMDIwMDkyMjE2NDkyMFoYDzIwMjAwOTIzMTY0OTIwWjB3
# MD0GCisGAQQBhFkKBAExLzAtMAoCBQDjFDkQAgEAMAoCAQACAhdkAgH/MAcCAQAC
# AhHeMAoCBQDjFYqQAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKg
# CjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAG7+IP7r+
# vDKIPmIkTgNOeJYgyVvuIG6zgw31YYkk/iaHuHI0tLRdYvGYwR3sFoimk2uGatk0
# G6SQmsqoiPi/x1WrHoAzpQ2ZR1wsNbTeW6YX02iYYWNJb6Q3xWgnzcS1fODv27z/
# 7As01qwAb+8dL4K6ShN+rycc68AfBGeaje8xggMNMIIDCQIBATCBkzB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAQpSyDkBUtFwSwAAAAABCjANBglg
# hkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqG
# SIb3DQEJBDEiBCDClDRJ/UgpSk3RStqMqUQnlSAbXic7kqWOw9oJDG6yCTCB+gYL
# KoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIFcDNiQzuqEMKA3oRvFdtm1Hcc2Q1loZ
# IxgfN8vk0qyqMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAAEKUsg5AVLRcEsAAAAAAQowIgQgvFtjukRmRLnx0grJSP69g5b0AsY2Ifkj
# ZKH/lheMI2gwDQYJKoZIhvcNAQELBQAEggEABmz4k0DZ+XWGgF+VrXkM9DlNFz3g
# 4l0euU2Co56WWAyK7/WPIrnTClAOI7xQ2SBhAB16NbRKDozBhJl5RdlWbY35NBOs
# XjaqpO4JwBR/okxbbd6cO4d3lh4OC6VLaGzK6mKsRSYQdHrrH6usmP1aMXKBqLcR
# Mvcx8FTIEdP5UJ5teR6l3SLyqKdxJgD2UcOxhAoZo/IrXjGzLVupVtBoyhR0jz2a
# oH+BeZ+w427S3O5a2YywOCgADyGtx5hIZ8cKmBybIJLe6KqkJt7eGf1rv4+KQ2TW
# +HRmekSPW2K6kW/vvhv5Okf+eXq73oxsdUp8N4XnS6l/e7X5d0BbN9YadA==
# SIG # End signature block

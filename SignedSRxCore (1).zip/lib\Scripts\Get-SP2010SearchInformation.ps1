<# =====================================================================
## Title       : Get-SPSearchInformation
## Description : This script will collect information regarding Search and the SSA's in the Farm.
## Author      : Anthony Casillas | Brian Pendergrass
## Date        : 08-16-2016
## Input       : 
## Output      : 
## Usage       : .\Get-SPSearchInformation_v1-5_1.ps1
## Notes       : 
## Tag         : Search, Sharepoint, Powershell
##
## Change log  : 1.1 [Jwaite]
##             :   - Added listing for crawl rules, site hit rules and server name mappings.
##             :   - Added a limit/counter for crawl rules. only list for 10 or less.
## Change log  : 1.3 [Acasilla]
##             :   - Added an WebClient Invoacation to check to see if the MicrosoftSharePointTeamServices IIS Response Header is present.. 
## Change log  : 1.4 [bspender]
##             :   - Added check to compare ServerId
##             :   - Fixed some Web App User Policy Settings
##             :   - Added in Start Addresses for a Remote Farm
##             :   - Checked SearchService Web Proxy Settings
##
## Change log  : 1.5 [acasilla]
##             :   - Added functions to get Servers in Farm and ServiceInstances
## Change log  : 1.6 [acasilla]
##             :   - Added Content Source SharePointCrawlBehavior type / If the Behavior is not CrawlVirtualServers, then the report will state the Start addresses are not local to the farm ( this is normal )
## =====================================================================
#>

$output = Read-Host "Enter a location for the output file (For Example: C:\Temp)" 
$outputfile = $output + "\SP2010SearchInfo_" + $timestamp +".txt"

function GetServersInFarm()
{
    "#########################################################################################"
    "   Servers in the Farm "
    "#########################################################################################"

    foreach($svr in Get-SPServer | Select DisplayName, Id, Status, Role)
    {
    $svr.DisplayName + " -- " + $svr.Id + " -- " + $svr.Role + " -- " + $svr.Status
    }
    ""
}

function GetServiceInstances()
{
    "#########################################################################################"
    "   What Service Instanes are running and on what Server? "
    "#########################################################################################"
    ""
     $serviceInstances = Get-SPServiceInstance |?{$_.Status -ne "Disabled"}
     foreach ($si in $serviceInstances)
     {
       $si.Server.Address + " -- "  + $si.TypeName + " -- " + $si.Status
     }
     ""
}


function displayGlobalInfo {
    "###################################################################################### "
    "  Search Service "
    "###################################################################################### "
    Get-SPEnterpriseSearchService
    $searchAdminProxy = (Get-SPEnterpriseSearchService).WebProxy
        if($searchAdminProxy.Address -ne $null)
        {
            " The Search Service has a Web Proxy defined. This will impact ALL SSA's and route crawl traffic to the Proxy regardless if the IE settings are set to NO PROXY"
            $searchAdminProxy
        }
    
    ""
    "###################################################################################### "
    "  Search Service Instance(s)"
    "###################################################################################### "
    ""
    "====================================================================================== "
    "  SharePoint Server Search"
    "====================================================================================== "
    ""
    $instances = Get-SPEnterpriseSearchServiceInstance | where {$_.Status -eq "Online"} | select Server,Id,Status,DefaultIndexLocation
    if ($instances -ne $null) {
      "Online Instance(s)"
      "-------------------"
      $instances
      ""
    }
    $instances = Get-SPEnterpriseSearchServiceInstance | where {$_.Status -ne "Online"} | select Server,Id,Status
    if ($instances -ne $null) {
      "Disabled Instance(s)" 
      "---------------------"
      $instances
      ""
    }
    "====================================================================================== "
    "  Search Query and Site Settings (SQSS)"
    "====================================================================================== "
    ""
    $instances = Get-SPServiceInstance | where {$_.TypeName -like "Search Query*"} | where {$_.Status -eq "Online"} | select Server,Id,Status
    if ($instances -ne $null) {
      "Online Instance(s)"
      "-------------------"
      $instances
      ""
    }
    $instances = Get-SPServiceInstance | where {$_.TypeName -like "Search Query*"} | where {$_.Status -ne "Online"} | select Server,Id,Status
    if ($instances -ne $null) {
      "Disabled Instance(s)" 
      "---------------------"
      $instances
      ""
    } 


	"###################################################################################### " 
	" Alternate Access Mappings" 
	"###################################################################################### " 
	    foreach($wa in Get-SPWebApplication){
        "-----------------------------------------------------------------"
        $wa.Name
        "-----------------------------------------------------------------"
        Get-SPAlternateURL -WebApplication $wa | Select IncomingUrl, Zone, PublicUrl
        ""
        }
    "###################################################################################### " 
	" Site Hit Frequency Rules"  #jwaite
	"###################################################################################### " 
	Get-SPEnterpriseSearchSiteHitRule
}

    

function displaySSAInfo ($SSA) {
  $crawlAccount = (New-Object Microsoft.Office.Server.Search.Administration.Content $SSA).DefaultGatheringAccount;
  "###################################################################################### "
  "  *** " + $SSA.Name + " ***" + "  | " + "  (Crawl Account: " + $crawlAccount + ")"
  "###################################################################################### "
  $SSA.ApplicationName
  $SSA
  "";
  "====================================================================================== "
  "  *** Admin Component (" + $SSA.Name + ") ***"
  "====================================================================================== "
  $SSA.AdminComponent; ""; 
  foreach ($ct in $SSA.CrawlTopologies) {
    "====================================================================================== "
    "  *** Crawl Topology (" + $SSA.Name + ") ***"
    "====================================================================================== "
    $ct; "";
    foreach ($cc in $ct.CrawlComponents){
      "---------------------------------------------------------------------------------- "
      "  *** Crawl Component (" + $cc.Name + ") ***"
      "---------------------------------------------------------------------------------- "
      $cc; "";
	  $farmServerId = $(Get-SPServer $cc.ServerName).Id;
	  if ($farmServerId -eq $null) {
		"******************************************************************"
		"[" + $cc.Name + "] ServerId mismatch found"; 
		"    - " + $cc.ServerName + " was removed from the farm"
		"******************************************************************"; "";	  	
	  } 
	  else { 
	  	if ($cc.ServerId -ne $farmServerId) {
			"******************************************************************"
			"[" + $cc.Name + "] ServerId mismatch found"; 
			"    - ServerId Per the Farm: " + $farmServerId 
			"    - And per the Component: " + $cc.ServerId 
			"******************************************************************"; "";
		}
	  }	
    }
  }
  foreach ($qt in $SSA.QueryTopologies){
    "====================================================================================== "
    "  *** Query Topology (" + $SSA.Name + ") ***"
    "====================================================================================== "
    $qt; "";
    foreach ($qc in $qt.QueryComponents){
      "---------------------------------------------------------------------------------- "
      "  *** Query Component (" + $qc.Name + ") ***"
      "---------------------------------------------------------------------------------- "
      $qc; "";
	  $farmServerId = $(Get-SPServer $qc.ServerName).Id;
	  if ($farmServerId -eq $null) {
		"******************************************************************"
		"[" + $qc.Name + "] ServerId mismatch found"; 
		"    - " + $qc.ServerName + " was removed from the farm"
		"******************************************************************"; "";	  	
	  } 
	  else { 
	  	if ($qc.ServerId -ne $farmServerId) {
			"******************************************************************"
			"[" + $qc.Name + "] ServerId mismatch found"; 
			"    - ServerId Per the Farm: " + $farmServerId 
			"    - And per the Component: " + $qc.ServerId 
			"******************************************************************"; "";
		}
	  } 
    }
  }; "";
  
  "====================================================================================== "
  "  *** Web Service EndPoints (" + $SSA.Name + ") ***"
  "====================================================================================== "
  "" 
  $adminSvc = (Get-SPServiceApplication) | where {$_.DisplayName -like "Search Admin*"+$SSA.Name}
  $adminSvc.DisplayName; 
  "---------------------------------------------------------------------------------- "
  foreach ($endPt in $adminSvc.Endpoints) { 
    foreach ($listenUri in $endPt.listenUris) {
      "  Uri: " + $listenUri.AbsoluteUri
    } 
    ""
  } 
  "";
  $SSA.Name
  "---------------------------------------------------------------------------------- "
  foreach ($endPt in $SSA.Endpoints) { 
    foreach ($listenUri in $endPt.listenUris) {
      "  Uri: " + $listenUri.AbsoluteUri
    } 
    ""
  } 
  "";
  "====================================================================================== "
  "  *** Databases (" + $SSA.Name + ") ***"
  "====================================================================================== "
  ""
  "Admin Database" 
  "---------------------------"
  $SSA.SearchAdminDatabase | select Name, Id, Server, DatabaseConnectionString
  ""
  "Crawl Store Database(s)" 
  "---------------------------"
  $SSA.CrawlStores
  ""
  "Property Store Database(s)" 
  "---------------------------"
  $SSA.PropertyStores
  ""
  "====================================================================================== "
  "  *** Server Name Mappings (" + $SSA.Name + ") ***"
  "====================================================================================== "  
  $SSA | Get-SPEnterpriseSearchCrawlMapping

  "====================================================================================== "
  "  *** Crawl Rules (" + $SSA.Name + ") ***"
  "====================================================================================== "  
  $Rules = $SSA | Get-SPEnterpriseSearchCrawlRule 
  if ($Rules.count -lt 11) { $Rules }
  else {
    ""
    "Top 10 (of " + $Rules.count + ") Crawl Rules"
    "---------------------------------------------"
    for ($i = 0; $i -le 11; $i++) { $Rules[$i]; }
  }

  "====================================================================================== "
  "  *** Content Sources (" + $SSA.Name + ") ***"
  "====================================================================================== "
  $contentSources = Get-SPEnterpriseSearchCrawlContentSource -SearchApplication $SSA;
  foreach ($contentSrc in $contentSources) {
    ""
		"------------------------------------------------------------------------------------------------------- "
		$contentSrc.Name + " | ( ID:" + $contentSrc.ID + " TYPE:" + $contentSrc.Type + "  Behavior:" + $contentSrc.SharePointCrawlBehavior + ")"
		"------------------------------------------------------------------------------------------------------- "
    foreach ($startUri in $contentSrc.StartAddresses) { 
      if ($contentSrc.Type.toString() -ieq "SharePoint") {
        $spSrc = @{}
        if ($startUri.Scheme.toString().toLower().startsWith("http")) {
          $isRemoteFarm = $true ## Assume Remote Farm Until Proven Otherwise ##
          foreach ($altUrl in Get-SPAlternateUrl) {
            if ($startUri.AbsoluteUri.toString() -ieq $altUrl.Uri.toString()) {
              $isRemoteFarm = $false                
              if ($altUrl.UrlZone -ieq "Default") {
                "  Start Address: " + $startUri
                "  AAM Zone: [" + $altUrl.UrlZone + "]" 
                $inUserPolicy = $false;    #assume crawlAccount not inUserPolicy until verified
                $webApp = Get-SPWebApplication $startUri.AbsoluteUri;
                $IIS = $webApp.IisSettings[[Microsoft.SharePoint.Administration.SPUrlZone]::($altUrl.UrlZone)]
                $isClaimsBased = $true
                if ($webApp.UseClaimsAuthentication) { 
                    "  Authentication Type: [Claims]"
                    if (($IIS.ClaimsAuthenticationProviders).count -eq 1) {
                       "  Authentication Provider: " + ($IIS.ClaimsAuthenticationProviders[0]).DisplayName
                    } else {
                      "  Authentication Providers: "
                      foreach ($provider in ($IIS.ClaimsAuthenticationProviders)) {
                        "     - " + $provider.DisplayName
                      }
                    }
                }
                else {
                  $isClaimsBased = $false
                  "  Authentication Type: [Classic]"                  
                  if ($IIS.DisableKerberos) { "  Authentication Provider: [Windows:NTLM]" }
                  else { "  Authentication Provider:[Windows:Negotiate]" }
                }
                foreach ($userPolicy in $webApp.Policies) {
                  if($isClaimsBased){
                   $claimsPrefix = "i:0#.w|" 
                  }
                  if ($userPolicy.UserName.toLower().Equals(($claimsPrefix + $crawlAccount).toLower())) {
                    $inUserPolicy = $true;
                    "  Web App User Policy: {" + $userPolicy.PolicyRoleBindings.toString() + "}";
                  }
                }
                if (!$inUserPolicy) {
                  "  ---"  + $crawlAccount + " is NOT defined in the Web App's User Policy !!!";
                }
              }
              else { 
                "    [" + $altUrl.UrlZone + "] " + $startUri;
                "  --- Non-Default zone may impact Contextual Scopes (e.g. This Site)" 
              }
            }
          }
          
          if($isRemoteFarm)
          {
            "  This Start Address is NOT local to the Farm"
            "  Start Address: " + $startUri
          } 
            
        } 
        else {
          if ($startUri.Scheme.toString().toLower().startsWith("sps")) { "  " + $startUri + " [Profile Crawl]" }
          else {
            if ($startUri.Scheme.toString().toLower().startsWith("bdc")) { "  URL: " + $startUri + " [BDC Content]" }
            else { "    -" + $startUri; }
          }
        }
      }
      else { "  Web Address: " + $startUri; }
      "  ---------------------------------------------"
    }
    ""
  }
  $queryString = "SELECT TOP 10 CrawlID,ProjectID,CrawlType,ContentSourceID,Status,SubStatus,Request,StartTime,EndTime FROM MSSCrawlHistory WHERE ( [CrawlID] NOT IN (SELECT [CrawlID] FROM MSSCrawlHistory WHERE ((Status = 11) OR ((Status = 4) AND (SubStatus = 1))))) ORDER BY CrawlID DESC"
  $dataSet = New-Object System.Data.DataSet "CrawlHistory"
  if ((New-Object System.Data.SqlClient.SqlDataAdapter($queryString, $SSA.SearchAdminDatabase.DatabaseConnectionString)).Fill($dataSet)) {
    "====================================================================================== "
    " *** Incomplete Crawl History ***"  
    "====================================================================================== "
    $dataSet.Tables[0] | SELECT *
  }
  "====================================================================================== "
  "";
}

############################################### 
# Set the Output File Variable\Path           # 
###############################################
#$outputfile = ""
#$outputfile = Read-Host "Enter a location and filename for the output(Example: C:\Temp\SearchInfo.txt)"
#if($outputfile -ne $null){
#	" Writing output to " + $outputfile
#} else {
    $timestamp = $(Get-Date -format "yyyyMMdd_HHmmss")
	$outputfile = $output + "\SP2010SearchInfo_" + $timestamp +".txt"
	"Writing output to " + $outputfile
#}

############################################### 
# Send the Output to the OutputFile           # 
###############################################
"[SharePoint Farm Build:" + (Get-SPFarm).BuildVersion + "]" | Out-File $outputfile
"" | Out-File $outputfile  -Append
Get-Date | Out-File $outputfile -Append
GetServersInFarm | ft -auto | Out-File $outputfile -Append
GetServiceInstances | Out-File $outputfile -Append
foreach ($SearchSvcApp in Get-SPEnterpriseSearchServiceApplication) { 
  displaySSAInfo($SearchSvcApp) | Out-File $outputfile -Append
  "" | Out-File $outputfile -Append
  "" | Out-File $outputfile -Append
}
displayGlobalInfo "" | Out-File $outputfile -Append
# SIG # Begin signature block
# MIIj0wYJKoZIhvcNAQcCoIIjxDCCI8ACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDVUGJsQp/uqXn/
# KAZuywpSPtkQvAte/qpRePglelyv2aCCDYEwggX/MIID56ADAgECAhMzAAABh3IX
# chVZQMcJAAAAAAGHMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAwMzA0MTgzOTQ3WhcNMjEwMzAzMTgzOTQ3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOt8kLc7P3T7MKIhouYHewMFmnq8Ayu7FOhZCQabVwBp2VS4WyB2Qe4TQBT8aB
# znANDEPjHKNdPT8Xz5cNali6XHefS8i/WXtF0vSsP8NEv6mBHuA2p1fw2wB/F0dH
# sJ3GfZ5c0sPJjklsiYqPw59xJ54kM91IOgiO2OUzjNAljPibjCWfH7UzQ1TPHc4d
# weils8GEIrbBRb7IWwiObL12jWT4Yh71NQgvJ9Fn6+UhD9x2uk3dLj84vwt1NuFQ
# itKJxIV0fVsRNR3abQVOLqpDugbr0SzNL6o8xzOHL5OXiGGwg6ekiXA1/2XXY7yV
# Fc39tledDtZjSjNbex1zzwSXAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhov4ZyO96axkJdMjpzu2zVXOJcsw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU4Mzg1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAixmy
# S6E6vprWD9KFNIB9G5zyMuIjZAOuUJ1EK/Vlg6Fb3ZHXjjUwATKIcXbFuFC6Wr4K
# NrU4DY/sBVqmab5AC/je3bpUpjtxpEyqUqtPc30wEg/rO9vmKmqKoLPT37svc2NV
# BmGNl+85qO4fV/w7Cx7J0Bbqk19KcRNdjt6eKoTnTPHBHlVHQIHZpMxacbFOAkJr
# qAVkYZdz7ikNXTxV+GRb36tC4ByMNxE2DF7vFdvaiZP0CVZ5ByJ2gAhXMdK9+usx
# zVk913qKde1OAuWdv+rndqkAIm8fUlRnr4saSCg7cIbUwCCf116wUJ7EuJDg0vHe
# yhnCeHnBbyH3RZkHEi2ofmfgnFISJZDdMAeVZGVOh20Jp50XBzqokpPzeZ6zc1/g
# yILNyiVgE+RPkjnUQshd1f1PMgn3tns2Cz7bJiVUaqEO3n9qRFgy5JuLae6UweGf
# AeOo3dgLZxikKzYs3hDMaEtJq8IP71cX7QXe6lnMmXU/Hdfz2p897Zd+kU+vZvKI
# 3cwLfuVQgK2RZ2z+Kc3K3dRPz2rXycK5XCuRZmvGab/WbrZiC7wJQapgBodltMI5
# GMdFrBg9IeF7/rP4EqVQXeKtevTlZXjpuNhhjuR+2DMt/dWufjXpiW91bo3aH6Ea
# jOALXmoxgltCp1K7hrS6gmsvj94cLRf50QQ4U8Qwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVqDCCFaQCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAYdyF3IVWUDHCQAAAAABhzAN
# BglghkgBZQMEAgEFAKCB7zAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg+Q138Q+C
# LOKsvH2cTsoMb4bdm5C237SYzqgTbD+p4bYwgYIGCisGAQQBgjcCAQwxdDByoFaA
# VABTAGgAYQByAGUAUABvAGkAbgB0ACAAUwBlAGEAcgBjAGgAIABIAGUAYQBsAHQA
# aAAgAFIAZQBwAG8AcgB0AHMAIABEAGEAcwBoAGIAbwBhAHIAZKEYgBZodHRwczov
# L21pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEBAQUABIIBAIZUAanibIPeI6uuQrLB
# Anm/QuTCrkZ5y1PqvyoU851f3pYIIXLgh4uz2EhmhoFrLKzs19owuccyRkSjy5zN
# HcG/wdrErMVrVZFyCbl9lALxE22fyYhG42ucHgMWKjqMzjxyjQYKH1DhqhGp666d
# E0gTGLzqG2AzFioYoBRqTVHDCpRX9q1NynhTM7X2HUZQrttaXRb4sBETOfAnF9jf
# uT7iXNS42C+eDKakma/hNA19XDAsQd1VlW3QYp2NvNHqbIj53qgyyEYoGMxDJxgL
# tzhAC5fR6BO7cpmStfCPRTcFLNpkZEBqfpwUw5dbPONIrSZd3oBnsIoRe8qRDX/v
# oOahghLxMIIS7QYKKwYBBAGCNwMDATGCEt0wghLZBgkqhkiG9w0BBwKgghLKMIIS
# xgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYLKoZIhvcNAQkQAQSgggFEBIIBQDCC
# ATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQg+2IE6t6UqLtAia2Y
# rFSlq22v3Cj+XiTDJLESJYj/jYsCBl9g+ahcGRgTMjAyMDA5MjIxMzU0MTcuMjk4
# WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28x
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3QTYtRTI1MS0xNTBBMSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIORDCCBPUwggPdoAMCAQIC
# EzMAAAEli96LbHImMd0AAAAAASUwDQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwHhcNMTkxMjE5MDExNDU4WhcNMjEwMzE3MDExNDU4
# WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UE
# CxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOkY3QTYtRTI1MS0xNTBBMSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEA0HsfY3ZgW+zhycEmJjFKK2TcAHL/Fct+k5Sbs3FcexvpRards41jjJUjjJJt
# V6ALifFWeUoQXnQA1wxgysRzWYS7txFvMeaLfyDpOosy05QBbbyFzoM17Px2jjO9
# lxyspDGRwHS/36WbQEjOT2pZrF1+DpfJV5JvY0eeSuegu6vfoQ1PtrYxh2hNWVpW
# m5TVFwYWmYLQiQnetFMmb4CO/7jc3Gn49P1cNm2orfZwwFXduMrf1wmZx2N8l+2b
# B4yLh6bJfj6Q12otQ8HvadK8gmbJfUjjB3sbSB3vapU27VmCfFrVi6B/XRDEMVS5
# 5jzwzlZgY+y2YUo4t/DfVac/xQIDAQABo4IBGzCCARcwHQYDVR0OBBYEFPOqyuUH
# JvkBOTQVxgjyIggXQyT4MB8GA1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kv
# Y3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEF
# BQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQC
# MAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggEBAJMcWTxh
# ICIAIbKmTU2ZOfFdb0IieY2tsR5eU6hgOh8I+UoqC4NxUi4k5hlfgbRZaWFLZJ3g
# eI62bLjaTLX20zHRu6f8QMiFbcL15016ipQg9U/S3K/eKVXncxxicy9U2DUMmSQa
# Lgn85IJM3HDrhTn3lj35zE4iOVAVuTnZqMhz0Fg0hh6G6FtXUyql3ibblQ02Gx0y
# rOM43wgTBY5spUbudmaYs/vTAXkY+IgHqLtBf98byM3qaCCoFFgmfZplYlhJFcAr
# Uxm1fHiu9ynhBNLXzFP2GNlJqBj3PGMG7qwxH3pXoC1vmB5H63BgBpX7QpqrTnTi
# 3oIS6BtFG8fwe7EwggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEB
# CwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYD
# VQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAe
# Fw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0N
# vHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycE
# MR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1
# R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxG
# wScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/Q
# S/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38
# vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYD
# VR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1
# AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaA
# FNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8y
# MDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAt
# MDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9Bggr
# BgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9k
# ZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABp
# AGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEA
# B+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9
# x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9C
# EMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP
# 7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoL
# kSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4E
# QoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQ
# zafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5h
# a293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3q
# jeAzLhIp9cAvVCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99j
# e/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8
# z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P3nSISRKhggLSMIICOwIBATCB/KGB
# 1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcG
# A1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsT
# HVRoYWxlcyBUU1MgRVNOOkY3QTYtRTI1MS0xNTBBMSUwIwYDVQQDExxNaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQBF0y/hUG3Nhvtz
# F17yESla9qFwp6CBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MA0GCSqGSIb3DQEBBQUAAgUA4xQJjTAiGA8yMDIwMDkyMjA5MjYzN1oYDzIwMjAw
# OTIzMDkyNjM3WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDjFAmNAgEAMAoCAQAC
# AiO5AgH/MAcCAQACAhHbMAoCBQDjFVsNAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwG
# CisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEF
# BQADgYEATQMb89CmIXNVNwsh0sOVKFAUMFazRpJ9PMXKNToPdbbhb5fPDJCxBW7y
# Ey9BAwq9M8BqqqBkumiSdv03c4IBCYIlAuMMA03RS2ppj+ftr3ybYwlnZO7nr6ls
# lO/708BIIfzhN5BlWZEAW3wlUBvMRFwXDe986Yc+EtLqxjjbHZAxggMNMIIDCQIB
# ATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAASWL3otsciYx
# 3QAAAAABJTANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3
# DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCCTCUAnmpCCbhmFBvl54MOULmouEizkkTlb
# J1dJZpYHhjCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIF3fxrIubzBf+ol9
# gg4flX5i+Ub6mhZBcJboso3vQfcOMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgUENBIDIwMTACEzMAAAEli96LbHImMd0AAAAAASUwIgQgW5tDcBbD1Bxle8W4
# oZMKRx1jPsEFFgGFLGVyCiRiiR8wDQYJKoZIhvcNAQELBQAEggEAt05zwvIxvT89
# vtucdvhYrDInyuuZ9dfbLdBaW+X/vF4PovaHLcQNKSgge19fEcVjNffL4XI/v0AD
# Mr0lmUnpCgnIp7Bu57Mx9OOvjLa6GHExqUxyGe/1cbMxbHghjpdGOBhHz5SzNXSD
# 0/rBaHRK31D4x3iAvK8zvzwBUa9nfOEPCWU6tjIk7gCCeEHfQWTyJ1pdmHzTqTw5
# fDHRdr6qXXHyVgN0D991AHtTEg+dM3IjJCWCrCO1WCpBkCwf6YDrS78ezI7k/VjP
# S/qs3CE2PO2C2I1fAcdA+dbw4MlAE2RJyXmdpyTQgWsVy0raw3Rj8+b+YMIRcWpF
# iNTdbWI0+Q==
# SIG # End signature block

<#
.SYNOPSIS 
    SRx Legacy Config Cleanup Script
    	
.DESCRIPTION 
	Internal script for cleaning up prior configuration from previous versions that has since been refactored
		
.NOTES
	=========================================
	Project		: Search Health Reports (SRx)
	-----------------------------------------
	Requires	: 
		PowerShell Version 3.0, Search Health Reports (SRx), Microsoft.SharePoint.PowerShell, 
        Patterns and Practices v15 PowerShell

	========================================================================================
	This Sample Code is provided for the purpose of illustration only and is not intended to 
	be used in a production environment.  
	
		THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY
		OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

	We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to 
	reproduce and distribute the object code form of the Sample Code, provided that You agree:
		(i) to not use Our name, logo, or trademarks to market Your software product in 
			which the Sample Code is embedded; 
		(ii) to include a valid copyright notice on Your software product in which the 
			 Sample Code is embedded; 
		and 
		(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against
              any claims or lawsuits, including attorneys' fees, that arise or result from 
			  the use or distribution of the Sample Code.

	========================================================================================
	
.INPUTS
    input1

.EXAMPLE
	Module-Name

#>
if($global:SRxEnv.Exists)
{
    #---[ Re-factoring logging variables to a consolidated structure
    if ($global:SRxEnv.Override -eq $null) { 
        $overrideObj = New-Object PSObject -Property @{ 
            "CrawlVisualizationQueryLimit" = $( if ((-not $global:SRxEnv.h.isNumeric($global:SRxEnv.CrawlVisualizationQueryLimit)) -or ($global:SRxEnv.CrawlVisualizationQueryLimit -le 0)) {100} else { $global:SRxEnv.CrawlVisualizationQueryLimit}  );
        }
        $global:SRxEnv.PersistCustomProperty("Override", $overrideObj) 
    }

    #and then purge the old properties from the custom config
    if ((-not [String]::IsNullOrEmpty($global:SRxEnv.LogLevel)) -or
        (-not [String]::IsNullOrEmpty($global:SRxEnv.EnableLogToFile)) -or
        (-not [String]::IsNullOrEmpty($global:SRxEnv.LogRetensionBytes)) -or
        (-not [String]::IsNullOrEmpty($global:SRxEnv.LogRetensionDays)))
    {
        if ($global:SRxEnv.CustomConfigIsReadOnly) {
            Write-SRx Warning $("~~~ Unable to purge the deprecated properties (the custom config file is read only or inaccessible) - skipping...")
        } else { 
            #-- ensure the Log object gets pushed to custom config...
            $logObj = New-Object PSObject -Property @{
                "Level" = "INFO";
                "ToFile" = $true;
                "RetentionBytes" = $(if ((-not [string]::isNullOrEmpty($global:SRxEnv.LogRetensionBytes)) -and 
                                        ($global:SRxEnv.h.isNumeric($global:SRxEnv.LogRetensionBytes))) { $global:SRxEnv.LogRetensionBytes } else { 1000MB });
                "RetentionDays" = $(if ((-not [string]::isNullOrEmpty($global:SRxEnv.LogRetensionDays)) -and 
                                        ($global:SRxEnv.h.isNumeric($global:SRxEnv.LogRetensionDays))) { $global:SRxEnv.LogRetensionDays } else { 90 });
            }
            $global:SRxEnv.PersistCustomProperty("Log", $logObj)

            #-- ensure the Cache object gets pushed to custom config...
            if ([string]::isNullOrEmpty($global:SRxEnv.Tmp)) {
                $tmpObj = New-Object PSObject -Property @{
                    "RetentionBytes" = 1000MB;
                    "RetentionDays" = 8;
                }
                $global:SRxEnv.PersistCustomProperty("Tmp", $tmpObj)
            }

            #-- purge the deprecated properties from $SRxEnv.CustomConfig (e.g. custom.config.json)
            $readlockRetries = 40
            $persistFailure = $false
            $customConfig = $null
            do {
                try {
                    Write-SRx VERBOSE $("<-Reading-from- '" + $global:SRxEnv.CustomConfig + "'") -ForegroundColor Yellow
			        $customConfig = Get-Content $($global:SRxEnv.CustomConfig) -Raw -ErrorAction Stop
                    if ([string]::isNullOrEmpty($customConfig)) {
                        $persistFailure = $true
                        Write-SRx Warning $("~~~ Unable to purge the deprecated properties (the custom config file is null or empty) - skipping...")
                    } else {
                        $tmpSRxEnv = ConvertFrom-Json $customConfig -ErrorAction SilentlyContinue
                        $propertyBag = $tmpSRxEnv | Get-Member -MemberType NoteProperty -ErrorAction SilentlyContinue | % {$_.name.toLower()}
                        if (($propertyBag -ne $null) -and ($propertyBag.count -gt 0)) {
                            $toPurge = @("loglevel", "enablelogtofile", "logretensionbytes", "logretensiondays")
                            foreach ($propertyName in $toPurge) {
                                if ($propertyBag -contains $propertyName) {
                                    Write-SRx VERBOSE $("<-Purging- '" + $propertyName + "' to " + $global:SRxEnv.CustomConfig) -ForegroundColor Yellow                        
                                    $tmpSRxEnv.PSObject.Properties.Remove($propertyName)
                                }
                            }
                        }
                        $jsonConfig = ConvertTo-Json $tmpSRxEnv -Depth 12
                    }
                } catch [System.IO.IOException] {
                    if ($readlockRetries -eq 40) { Write-SRx INFO " --> Unable to read " + $global:SRxEnv.CustomConfig + " - Retrying up to 10s" -NoNewline -ForegroundColor Yellow }
                    elseif ($($readlockRetries % 4) -eq 0) {  Write-SRx INFO "." -NoNewline }
                    Start-Sleep -Milliseconds 250
                    $readlockRetries--
                } catch {
                    $persistFailure = $true
                    Write-Error $(" --> Caught exception reading `$global:SRxEnv.CustomConfig when purging deprecated properties - skipping")
                }
            } while (($readlockRetries -gt 0) -and ([string]::isNullOrEmpty($jsonConfig)) -and (-not $persistFailure))
			
            if ([string]::isNullOrEmpty($jsonConfig) -and ($readlockRetries -lt 1)) {
                Write-SRx Warning $("~~~ Timed out waiting for a read/write lock on `$global:SRxEnv.CustomConfig to purge deprecated properties - skipping")
            } elseif (-not [string]::isNullOrEmpty($jsonConfig)) {
                try {
                    $jsonConfig | Set-Content $($global:SRxEnv.CustomConfig) -ErrorAction Stop
                } catch {
                    Write-SRx Warning $("~~~ Unable to obtain a read/write lock on `$global:SRxEnv.CustomConfig to purge deprecated properties - skipping")
                }
            }
        }
    }
    #---
    if ([String]::IsNullOrEmpty($global:SRxEnv.Log.RetentionBytes)) {
		$global:SRxEnv.PersistCustomProperty("Log.RetentionBytes", 1000MB)  #...then persist Log.RetentionBytes to 1000MB
    }
    #-- if the Log.RetentionDays does not exist...
	if ([String]::IsNullOrEmpty($global:SRxEnv.Log.RetentionDays)) {
		$global:SRxEnv.PersistCustomProperty("Log.RetentionDays", 90)     #...then set LogRetentionDays to 90
    }
}

#            	   ___ ___         
# [oo]   Search | / __| _ \__ __
#/|##|\  Health | \__ \   /\ \ /
# d  b  Reports | |___/_|_\/_\_\

# SIG # Begin signature block
# MIIjxwYJKoZIhvcNAQcCoIIjuDCCI7QCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAnzM8jk4xLrd9a
# 3TqP2dNcDXPnp+4XWBghR8jMKRtlKKCCDYEwggX/MIID56ADAgECAhMzAAABh3IX
# chVZQMcJAAAAAAGHMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAwMzA0MTgzOTQ3WhcNMjEwMzAzMTgzOTQ3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOt8kLc7P3T7MKIhouYHewMFmnq8Ayu7FOhZCQabVwBp2VS4WyB2Qe4TQBT8aB
# znANDEPjHKNdPT8Xz5cNali6XHefS8i/WXtF0vSsP8NEv6mBHuA2p1fw2wB/F0dH
# sJ3GfZ5c0sPJjklsiYqPw59xJ54kM91IOgiO2OUzjNAljPibjCWfH7UzQ1TPHc4d
# weils8GEIrbBRb7IWwiObL12jWT4Yh71NQgvJ9Fn6+UhD9x2uk3dLj84vwt1NuFQ
# itKJxIV0fVsRNR3abQVOLqpDugbr0SzNL6o8xzOHL5OXiGGwg6ekiXA1/2XXY7yV
# Fc39tledDtZjSjNbex1zzwSXAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhov4ZyO96axkJdMjpzu2zVXOJcsw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU4Mzg1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAixmy
# S6E6vprWD9KFNIB9G5zyMuIjZAOuUJ1EK/Vlg6Fb3ZHXjjUwATKIcXbFuFC6Wr4K
# NrU4DY/sBVqmab5AC/je3bpUpjtxpEyqUqtPc30wEg/rO9vmKmqKoLPT37svc2NV
# BmGNl+85qO4fV/w7Cx7J0Bbqk19KcRNdjt6eKoTnTPHBHlVHQIHZpMxacbFOAkJr
# qAVkYZdz7ikNXTxV+GRb36tC4ByMNxE2DF7vFdvaiZP0CVZ5ByJ2gAhXMdK9+usx
# zVk913qKde1OAuWdv+rndqkAIm8fUlRnr4saSCg7cIbUwCCf116wUJ7EuJDg0vHe
# yhnCeHnBbyH3RZkHEi2ofmfgnFISJZDdMAeVZGVOh20Jp50XBzqokpPzeZ6zc1/g
# yILNyiVgE+RPkjnUQshd1f1PMgn3tns2Cz7bJiVUaqEO3n9qRFgy5JuLae6UweGf
# AeOo3dgLZxikKzYs3hDMaEtJq8IP71cX7QXe6lnMmXU/Hdfz2p897Zd+kU+vZvKI
# 3cwLfuVQgK2RZ2z+Kc3K3dRPz2rXycK5XCuRZmvGab/WbrZiC7wJQapgBodltMI5
# GMdFrBg9IeF7/rP4EqVQXeKtevTlZXjpuNhhjuR+2DMt/dWufjXpiW91bo3aH6Ea
# jOALXmoxgltCp1K7hrS6gmsvj94cLRf50QQ4U8Qwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVnDCCFZgCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAYdyF3IVWUDHCQAAAAABhzAN
# BglghkgBZQMEAgEFAKCB7zAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgbziZHznH
# 6JH4x9vXwvIQWp7B58r7868ZtxsJWH9nnO8wgYIGCisGAQQBgjcCAQwxdDByoFaA
# VABTAGgAYQByAGUAUABvAGkAbgB0ACAAUwBlAGEAcgBjAGgAIABIAGUAYQBsAHQA
# aAAgAFIAZQBwAG8AcgB0AHMAIABEAGEAcwBoAGIAbwBhAHIAZKEYgBZodHRwczov
# L21pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEBAQUABIIBAK3hkq6aL2PQj9VQJO7V
# 6oW+8EVdBdP/Qy7kyA6azyzOQM4SWyls/5A4sFEIDo/YJ82byvyD78j1hlgq9lPx
# nukyjjmFdbKusNS6abg2peymS/lRIqCzsd9YlSJtEuUsq/i6UnpyWFAxRrsybPbo
# WLba9Wuz9co45byPTAyiUVYdtZOT55apcj2Ov/2iQ6cLoS/2xf7X+9euPlaRRtmx
# SW9/x2XJcplTJ3k9p7MYMIvtPlkIQS43oovWNiLxfMmColC0ze8CkInk85gZbrs8
# DqYyrXrQU+oxB5aumZZHRKoB1U7iSbxfDyp6GDa7dGxrkOMthWEUaXSXYJMPj/Gd
# oQ2hghLlMIIS4QYKKwYBBAGCNwMDATGCEtEwghLNBgkqhkiG9w0BBwKgghK+MIIS
# ugIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYLKoZIhvcNAQkQAQSgggFABIIBPDCC
# ATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQgHKAzH/DdsAxE3QhJ
# 0vHNMLKkv68vU0x4IFUzSr3nWbUCBl9ieoCIDxgTMjAyMDA5MjIxMzU0MjMuMDQ0
# WjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTAr
# BgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQG
# A1UECxMdVGhhbGVzIFRTUyBFU046OEQ0MS00QkY3LUIzQjcxJTAjBgNVBAMTHE1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wggg48MIIE8TCCA9mgAwIBAgITMwAA
# AQpSyDkBUtFwSwAAAAABCjANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDAeFw0xOTEwMjMyMzE5MTVaFw0yMTAxMjEyMzE5MTVaMIHK
# MQswCQYDVQQGEwJVUzELMAkGA1UECBMCV0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0
# IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjo4RDQxLTRCRjctQjNCNzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALs+G62U
# oXDFn4Z49T9XSkyR7bXkdJfw9wtfWGNhRvIIREEWzv/ATCtvAwhl06js0OpwhSFd
# e3eTGDU6oEnG6jNVwInwnBHL9Ujv2nVl4ttK/dowzGi47Oipo0v8OZvwJP1QRyqr
# c8XXy8y/Vxl+TxmmG5VIY8zR5awm8TWR89cImxjOxm26urSMQjpcGH2Gm4pCrwpJ
# e+ioITfsRlathbLe6FEmeyt3hOrZiBizJZD9pAXbR1vvdlbAi1cbhNSXLghDSlxC
# L39Qfd+xW7Tqrz/I29zsx8hyadg5Q87IUwGHQRbnX0r+aD/FiAyG2ZmWfOa8eevm
# enMlOLBsG6GfBScCAwEAAaOCARswggEXMB0GA1UdDgQWBBT4RJSl/TpMTVDekfg6
# rQGikXGFKDAfBgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8E
# TzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBM
# MEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRz
# L01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQBUl6581BXy3dNzJarR
# K7edVhl91FxXqKxOnRmPmCMEpnxUSkTcBHvHJi7dBDsXs8k1evv33WE8qz3Dw74E
# d5OhebB3ihMaIY66nI8QGt8lUPUiWWpF2VSs2h1s27zLgPJHJs49Cf2Ov6ZOe2hb
# Kf5K/pbuWjXcOVd1oIrSWKcBOn6GULAa00zzUYSF1TB5zxJOrNvu5wuk8vWSyCYW
# HjMqi7orSRirxIkYQ/D2M5BiZy5I6etSAg5P9NGVWb75Vy6J7Yd9maKHmff/u+tK
# PYNpVIRfKGixwgdYvNnVAoV3c2bpVBMEOQmVofFiI0GUlLrzjtb1dBXzqnTcHA8l
# 7hXSMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWlj
# cm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAx
# MjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8
# E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3O
# CROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJY
# YEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIa
# IYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo
# 8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhac
# AQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTV
# YzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+ii
# XGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0y
# My5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNy
# dDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEW
# MWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5o
# dG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBT
# AHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbg
# mD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzt
# a1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/y
# N31aPxzymXlKkVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8
# tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpx
# Y517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4
# ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/Dh
# O3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJ
# rDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXA
# L1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8ch
# r1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQ
# NdrvCScc1bN+NR4Iuto229Nfj950iEkSoYICzjCCAjcCAQEwgfihgdCkgc0wgcox
# CzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQg
# SXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1Mg
# RVNOOjhENDEtNEJGNy1CM0I3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQA5vXalcdF/7lGtFXJFduIaaGPe+aCB
# gzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEB
# BQUAAgUA4xQ5EDAiGA8yMDIwMDkyMjE2NDkyMFoYDzIwMjAwOTIzMTY0OTIwWjB3
# MD0GCisGAQQBhFkKBAExLzAtMAoCBQDjFDkQAgEAMAoCAQACAhdkAgH/MAcCAQAC
# AhHeMAoCBQDjFYqQAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKg
# CjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAG7+IP7r+
# vDKIPmIkTgNOeJYgyVvuIG6zgw31YYkk/iaHuHI0tLRdYvGYwR3sFoimk2uGatk0
# G6SQmsqoiPi/x1WrHoAzpQ2ZR1wsNbTeW6YX02iYYWNJb6Q3xWgnzcS1fODv27z/
# 7As01qwAb+8dL4K6ShN+rycc68AfBGeaje8xggMNMIIDCQIBATCBkzB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAQpSyDkBUtFwSwAAAAABCjANBglg
# hkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqG
# SIb3DQEJBDEiBCD9/LxTutBmFoxEOPbxdWh/n8qfBZ1uonlZvCYnrVHpajCB+gYL
# KoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIFcDNiQzuqEMKA3oRvFdtm1Hcc2Q1loZ
# IxgfN8vk0qyqMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAAEKUsg5AVLRcEsAAAAAAQowIgQgvFtjukRmRLnx0grJSP69g5b0AsY2Ifkj
# ZKH/lheMI2gwDQYJKoZIhvcNAQELBQAEggEAOgfpVUE07csY2gh1036Oo+M8MLva
# tFEvM5aY2F21TJ+aF1Qf4Zk6+nyCf4TSHjNqUXsN9C37v/GCFBl4CbNNuvIFJ7O3
# TcU3KrEuhzvGx+Mt+nmVI+bxNox1Ey54wXv+KgzF3Up7KR5SZSfx1BgU73xnaOYr
# yl+alorXfaLJ3iXFrTMRq3VI5QKqTSyh49DW2cbgTlpU5VQzzaty0+rGW3n2yQQ3
# UZzJ9ZznOUGTjqcv/c7LrdVLzkmuCeCMkS6le2K3bWo9w+d/UttGet6lJY5hkHr/
# 4lRN9ZOG1Eku9a3jzGj1F3INRK3r7TZj0kvSHf6mOuTCfcNBprCboGwYVQ==
# SIG # End signature block
